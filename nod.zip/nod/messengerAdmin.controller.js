const dbconfig = require("../../config/database.config.js");
const myObj = require("../utility/connect.mysql.js");
const { parse_str } = require("../utility/helperFunc.js");
var MongoClient = require("mongodb").MongoClient;

const envObj = require("../../config/env.conf.js");
const helperFunc = require("../utility/helperFunc.js");
const budgetAdminLogModel = require("../models/budgetAdminLog.model.js");
const { MAINCITIES, mongodb } = require("../../config/geniosales.db.config");
const curlObj = require("../utility/curlRequest.js");
const paths = require("../../config/paths.js");
const ObjectId = require('mongodb').ObjectId;
const md5 = require("md5");
const axios = require('axios');
const moment = require("moment");


const dataservers = [
  "mumbai",
  "delhi",
  "pune",
  "bangalore",
  "ahmedabad",
  "hyderabad",
  "chennai",
  "kolkata",
  "remote",
];
const mains11cities = [
  "mumbai",
  "delhi",
  "kolkata",
  "bangalore",
  "chennai",
  "pune",
  "hyderabad",
  "ahmedabad",
  "chandigarh",
  "coimbatore",
  "jaipur",
];

class MessengerAdminClass {
  // server setb for mysql
  async setServerIdc() {
    try {
      this.mysqlObjIdc = new myObj(this.conn_idc);
    } catch (error) {
      console.log("function setServerIdc():", error);
    }
  }
  async fetch11MainsCities(req, res) {
    try {
      return res
        .status(200)
        .json({ errorCode: 0, data: mains11cities, message: "Success" });
    } catch (err) {
      return res
        .status(500)
        .json({ errorCode: 1, errorStatus: "Some Error Occured" + e.message });
    }
  }
  async setServers() {
    try {
      this.conn_city =
        dataservers.indexOf(this.data_city) > -1 ? this.data_city : "remote";
      this.conn_local = dbconfig["local"][this.conn_city];

      this.mysqlObjLocal = new myObj(this.conn_local);
      this.conn_idc = dbconfig["idc"][this.conn_city];
      this.mysqlObjIdc = new myObj(this.conn_idc);
      this.conn_fin = dbconfig["finance"][this.conn_city];
      this.mysqlObjFin = new myObj(this.conn_fin);
    } catch (error) {
      //console.log("function setServers():", error);
    }
  }
  async setConnection() {
    let url = urlDev;
    if (envObj.env != "dev") {
      url = urlLive;
    }
    this.db = await MongoClient.connect(url);
    this.dbo = this.db.db("db_genio");
  }


  async fetchMessageCampaignList(req, res) {
   // console.log("fetchMessageCampaignList", req.body)
    try {
      let params = JSON.parse(JSON.stringify(req.body));
      let campaign_id = parseInt(params.variant);
      let city = params.data_city;
      await this.setConnection();
      let campaignMsgArr = await this.dbo
        .collection("col_messenger_data")
        .find({})
        .toArray();
      if (campaignMsgArr.length > 0) {

        const arrayUniqueByKey = [...new Map(campaignMsgArr.map(item =>
          [item['campaignId'], item])).values()]
        let retObj = {
          errorCode: 0,
          errorStatus: "",
          data: arrayUniqueByKey,
        };
        return res.status(200).send(retObj);
      } else {
        let retObj = {
          errorCode: 0,
          errorStatus: "No Data Found",
          data: {},
        };
        return res.status(200).send(retObj);
      }
    } catch (error) {
      console.log(error);
    }
  }
  async fetchGenioMessageCampaignList(req, res) {
    //console.log("fetchMessageCampaignList", req.body)
    try {
      let params = JSON.parse(JSON.stringify(req.body));
      let city = params.data_city;
      await this.setConnection();
      let campaignMsgArr = await this.dbo
        .collection("col_messenger_data")
        .find({ "isActive": true })
        .toArray();
      if (campaignMsgArr.length > 0) {

        const arrayUniqueByKey = [...new Map(campaignMsgArr.map(item =>
          [item['campaignId'], item])).values()]
        let retObj = {
          errorCode: 0,
          errorStatus: "",
          data: arrayUniqueByKey,
        };
        return res.status(200).send(retObj);
      } else {
        let retObj = {
          errorCode: 0,
          errorStatus: "No Data Found",
          data: {},
        };
        return res.status(200).send(retObj);
      }
    } catch (error) {
      console.log(error);
    }
  }
  async fetchMessageTemplateList(req, res) {
   // console.log("fetchMessageTemplateList", req.body)
    try {
      let params = JSON.parse(JSON.stringify(req.body));
      let campaignId = parseInt(params.campaignId);
      let city = params.data_city;
      await this.setConnection();
      let campaignMsgArr = await this.dbo
        .collection("col_messenger_data")
        .find({ campaignId: campaignId, isDeleted: false })
        .toArray();
      if (campaignMsgArr.length > 0) {
        let retObj = {
          errorCode: 0,
          errorStatus: "",
          data: campaignMsgArr,
        };
        return res.status(200).send(retObj);
      } else {
        let retObj = {
          errorCode: 0,
          errorStatus: "No Data Found",
          data: {},
        };
        return res.status(200).send(retObj);
      }
    } catch (error) {
      console.log(error);
    }
  }
  async getTemplateDetailsById(req, res) {
  //  console.log("getTemplateDetailsById", req.body)
    try {
      let params = JSON.parse(JSON.stringify(req.body));
      let campaignId = parseInt(params.campaignId);
      let city = params.data_city;
      await this.setConnection();
      let campaignMsgArr = await this.dbo
        .collection("col_messenger_data")
        .findOne({ _id: ObjectId(params.objectId), isDeleted: false })

      if (campaignMsgArr) {
        let retObj = {
          errorCode: 0,
          errorStatus: "",
          data: campaignMsgArr,
        };
        return res.status(200).send(retObj);
      } else {
        let retObj = {
          errorCode: 0,
          errorStatus: "No Data Found",
          data: {},
        };
        return res.status(200).send(retObj);
      }
    } catch (error) {
      console.log(error);
    }
  }

  async getGenioTemplateDetailsById(req, res) {
    //  console.log("getTemplateDetailsById", req.body)
    try {
      let params = JSON.parse(JSON.stringify(req.body));
      let campaignId = parseInt(params.campaignId);
      let city = params.data_city;
      let empcode = parseInt(req.body.empcode)
      let empType = req.body.typeofemployee
      await this.setConnection();
      let campaignMsgArrGeneric;
      // for conditions -- like EMPCODE, EMPTYPE, Multiple City , Category
      let findReqAll = {
        campaignId: params.campaignId,
        ["template." + "isActive"]: true,
        isDeleted: false,
        ["template.isGeneric"]: false,
        ["template.employeeId"]: { $elemMatch: { $elemMatch: { $in: [empcode] } } },
        ["template.employeeType"]: { $in: [empType] }
      }
      if (params.categoryAbbr != "" && params.isGeneric == false) {
        findReqAll["template.categoryAbbr"] = params.categoryAbbr
        findReqAll["template.isGeneric"] = false
      }
      if (params.categoryAbbr == "" && params.isGeneric == true) {
        findReqAll["template.isGeneric"] = true
      }
      if (params.data_city != "") {
        findReqAll["template.citySelected"] = { $in: [params.data_city] }
      }
      let campaignMsgArrAll = await this.dbo
        .collection("col_messenger_data")
        .find(findReqAll).toArray();

      if (campaignMsgArrAll.length > 0) {
        let retObj = {
          errorCode: 0,
          errorStatus: "",
          data: campaignMsgArrAll,
        };
        return res.status(200).send(retObj);
      }


      // for conditions -- like EMPCODE, EMPTYPE, all City , Category
      let findReqAllCity = {
        campaignId: params.campaignId,
        ["template." + "isActive"]: true,
        isDeleted: false,
        ["template.isGeneric"]: false,
        ["template.employeeId"]: { $elemMatch: { $elemMatch: { $in: [empcode] } } },
        ["template.employeeType"]: { $in: [empType] }
      }
      if (params.categoryAbbr != "" && params.isGeneric == false) {
        findReqAllCity["template.categoryAbbr"] = params.categoryAbbr
        findReqAllCity["template.isGeneric"] = false
      }
      if (params.categoryAbbr == "" && params.isGeneric == true) {
        findReqAllCity["template.isGeneric"] = true
      }
      let campaignMsgArrAllCity = await this.dbo
        .collection("col_messenger_data")
        .find(findReqAllCity).toArray();

      if (campaignMsgArrAll.length == 0 && campaignMsgArrAllCity.length > 0) {
        let retObj = {
          errorCode: 0,
          errorStatus: "",
          data: campaignMsgArrAllCity,
        };
        return res.status(200).send(retObj);
      }

      // for conditions -- like all EMPCODE, Multiple EMPTYPE, all City , Category
      let findReqALLEMP = {
        campaignId: params.campaignId,
        ["template." + "isActive"]: true,
        isDeleted: false,
        ["template.isGeneric"]: false,
        ["template.employeeType"]: { $in: [empType] }
      }
      if (params.categoryAbbr != "" && params.isGeneric == false) {
        findReqALLEMP["template.categoryAbbr"] = params.categoryAbbr
        findReqALLEMP["template.isGeneric"] = false
      }
      if (params.categoryAbbr == "" && params.isGeneric == true) {
        findReqALLEMP["template.isGeneric"] = true
      }
      let campaignMsgArrALLEMP = await this.dbo
        .collection("col_messenger_data")
        .find(findReqALLEMP).toArray();
      //console.log(findReq)

      if (campaignMsgArrAll.length == 0 && campaignMsgArrAllCity.length == 0 && campaignMsgArrALLEMP.length > 0) {
        let retObj = {
          errorCode: 0,
          errorStatus: "",
          data: campaignMsgArrALLEMP,
        };
        return res.status(200).send(retObj);
      }

      //  for conditions -- like multiple EMPCODE, all EMPTYPE, all City , Category
      let findReqALLEMPC = {
        campaignId: params.campaignId,
        ["template." + "isActive"]: true,
        isDeleted: false,
        ["template.isGeneric"]: false,
        ["template.employeeId"]: { $elemMatch: { $elemMatch: { $in: [empcode] } } }
      }
      if (params.categoryAbbr != "" && params.isGeneric == false) {
        findReqALLEMPC["template.categoryAbbr"] = params.categoryAbbr
        findReqALLEMPC["template.isGeneric"] = false
      }
      if (params.categoryAbbr == "" && params.isGeneric == true) {
        findReqALLEMPC["template.isGeneric"] = true
      }
      let campaignMsgArrALLEMPC = await this.dbo
        .collection("col_messenger_data")
        .find(findReqALLEMPC).toArray();
      //console.log(findReq)

      if (campaignMsgArrAll.length == 0 && campaignMsgArrAllCity.length == 0 && campaignMsgArrALLEMP.length == 0 && campaignMsgArrALLEMPC.length > 0) {
        let retObj = {
          errorCode: 0,
          errorStatus: "",
          data: campaignMsgArrALLEMPC,
        };
        return res.status(200).send(retObj);
      }



      // console.log("campaignMsgArr==",campaignMsgArr)
      if (campaignMsgArrAll.length == 0 && campaignMsgArrALLEMP.length == 0 && campaignMsgArrALLEMPC.length == 0 && campaignMsgArrAllCity.length == 0) {
        campaignMsgArrGeneric = await this.dbo
          .collection("col_messenger_data")
          .find({
            campaignId: params.campaignId,
            ["template." + "isActive"]: true,
            ["template." + "isGeneric"]: true,
            isDeleted: false
          }).toArray();
      }

      if (campaignMsgArrAll.length == 0 && campaignMsgArrALLEMP.length == 0 && campaignMsgArrAllCity.length == 0 && campaignMsgArrALLEMPC.length == 0 && campaignMsgArrGeneric.length > 0) {
        let retObj = {
          errorCode: 0,
          errorStatus: "",
          data: campaignMsgArrGeneric,
        };
        return res.status(200).send(retObj);
      }

      //  for conditions -- like multiple EMPCODE, all EMPTYPE, all City , all Category
      let findReqALLEMPCat = {
        campaignId: params.campaignId,
        ["template." + "isActive"]: true,
        isDeleted: false,
        ["template.isGeneric"]: false,
        ["template.employeeId"]: { $elemMatch: { $elemMatch: { $in: [empcode] } } }
      }
      let campaignMsgArrALLEMPCat = await this.dbo
        .collection("col_messenger_data")
        .find(findReqALLEMPCat).toArray();
      //console.log(findReq)

      if (campaignMsgArrAll.length == 0 && campaignMsgArrAllCity.length == 0 && campaignMsgArrGeneric.length == 0 && campaignMsgArrALLEMP.length == 0 && campaignMsgArrALLEMPC.length == 0 && campaignMsgArrALLEMPCat.length > 0) {
        let retObj = {
          errorCode: 0,
          errorStatus: "",
          data: campaignMsgArrALLEMPCat,
        };
        return res.status(200).send(retObj);
      }
      //  for conditions -- like all EMPCODE, multiple EMPTYPE, all City , all Category
      let findReqALLEMPCatEMPT = {
        campaignId: params.campaignId,
        ["template." + "isActive"]: true,
        isDeleted: false,
        ["template.isGeneric"]: false,
        ["template.employeeType"]: { $in: [empType] }
      }
      let campaignMsgArrALLEMPCatEMPT = await this.dbo
        .collection("col_messenger_data")
        .find(findReqALLEMPCatEMPT).toArray();
      //console.log(findReq)

      if (campaignMsgArrAll.length == 0 && campaignMsgArrAllCity.length == 0 && campaignMsgArrGeneric.length == 0 && campaignMsgArrALLEMP.length == 0 && campaignMsgArrALLEMPC.length == 0 && campaignMsgArrALLEMPCat.length == 0 && campaignMsgArrALLEMPCatEMPT.length > 0) {
        let retObj = {
          errorCode: 0,
          errorStatus: "",
          data: campaignMsgArrALLEMPCatEMPT,
        };
        return res.status(200).send(retObj);
      }

      let campaignMsgArrGenericRemoved = await this.dbo
        .collection("col_messenger_data")
        .find({
          campaignId: params.campaignId,
          ["template." + "isActive"]: true,
          ["template." + "isGeneric"]: false,
          isDeleted: false
        }).toArray();


      if (campaignMsgArrAll.length == 0 && campaignMsgArrALLEMP.length == 0 && campaignMsgArrAllCity.length == 0 && campaignMsgArrALLEMPCatEMPT.length == 0 && campaignMsgArrALLEMPC.length == 0 && campaignMsgArrALLEMPCat.length == 0 && campaignMsgArrGeneric.length == 0 && campaignMsgArrGenericRemoved.length > 0) {
        let retObj = {
          errorCode: 0,
          errorStatus: "",
          data: campaignMsgArrGenericRemoved,
        };
        return res.status(200).send(retObj);
      } else {
        let retObj = {
          errorCode: 0,
          errorStatus: "No Data Found",
          data: {},
        };
        return res.status(200).send(retObj);
      }
    } catch (error) {
      console.log(error);
    }
  }

  async activeInactiveMessageCampaign(req, res) {
  //  console.log("activeInactiveMessageCampaign", req.body)
    try {
      let params = JSON.parse(JSON.stringify(req.body));
      let campaignId = params.campaignId ? parseInt(params.campaignId) : "";
      let city = params.data_city;
      await this.setConnection();
      let campaignMsgArr;
      if (params.type == "template") {
        //console.log(params)
        campaignMsgArr = await this.dbo
          .collection("col_messenger_data")
          .findOneAndUpdate({ _id: ObjectId(params.objectId) }, { $set: { ["template." + "isActive"]: params.isActive } })
      }
      if (params.type == "message") {
        campaignMsgArr = await this.dbo
          .collection("col_messenger_data")
          .updateMany({ campaignId: campaignId }, { $set: { isActive: params.isActive } })
      }
      if (campaignMsgArr) {
        let retObj = {
          errorCode: 0,
          errorStatus: "Success",
          data: {},
        };
        return res.status(200).send(retObj);
      } else {
        let retObj = {
          errorCode: 0,
          errorStatus: "No Data Found",
          data: {},
        };
        return res.status(200).send(retObj);
      }
    } catch (error) {
      console.log(error);
    }
  }

  async deleteTemplate(req, res) {
    console.log("deleteTemplate", req.body)
    try {
      let params = JSON.parse(JSON.stringify(req.body));
      let campaignId = params.campaignId ? parseInt(params.campaignId) : "";
      let city = params.data_city;
      await this.setConnection();
      let templateDeleted;

      console.log(params)

      templateDeleted = await this.dbo
        .collection("col_messenger_data")
        .findOneAndUpdate({ _id: ObjectId(params.objectId) }, { $set: { isDeleted: true } })


      if (templateDeleted) {
        let retObj = {
          errorCode: 0,
          errorStatus: "Success",
          data: {},
        };
        return res.status(200).send(retObj);
      } else {
        let retObj = {
          errorCode: 0,
          errorStatus: "No Data Found",
          data: {},
        };
        return res.status(200).send(retObj);
      }
    } catch (error) {
      console.log(error);
    }
  }

  async fetchEmployeeForMessanger(req, res) {
    console.log("fetchEmployeeForMessanger", req.body)
    try {
      let params = JSON.parse(JSON.stringify(req.body));

      // auth_token=Z2E%25%27%3Ej0~%27z%5D%26w7bR64%7Bs1EMSE%7CxN%7DHctbWJoXjBz&isJson=1&textSearch=4&textSearch=1&sSearch=10077614
       let curlUrl = paths.ssoapiurl + "api/getEmployee_xhr.php";
      //let curlUrl = "http://192.168.20.237:8080/api/getEmployee_xhr.php"
      let auth_token_obj = {
        auth_token: md5("Q-ZedAP^I76A%'>j0~'z]&w7bR64{s")
      };
      let postData = {};
      let empData = {};
      // postData["empcode"] = params.empcode;
      postData["sSearch"] = params.searchEmp
      postData["textSearch"] = 4;
      postData["textSearch"] = 1;
      postData["isJson"] = 1;
      postData["limit"] = "5";
      console.log(postData)
      let curlResp = await curlObj.curlCall(
        "xxx",
        curlUrl,
        postData,
        "json",
        auth_token_obj,
        { timeout: 1000 }
      );
      let result = JSON.parse(curlResp);
      // console.log("result",result)


      if (result) {
        let retObj = {
          errorCode: 0,
          errorStatus: "Success",
          data: result["data"],
        };
        return res.status(200).send(retObj);
      } else {
        let retObj = {
          errorCode: 0,
          errorStatus: "No Data Found",
          data: {},
        };
        return res.status(200).send(retObj);
      }
    } catch (error) {
      console.log(error);
    }
  }

  async updateTemplateDetails(req, res) {
    //console.log("updateTemplateDetails", req.body)
    try {
      let params = JSON.parse(JSON.stringify(req.body));
      let campaignId = params.campaignId ? parseInt(params.campaignId) : "";
      let city = params.data_city;
      await this.setConnection();
      let templateUpdate;

      console.log(params)
      if (params.updateType == "content") {
        let imageUpdate = await this.dbo
          .collection("col_messenger_data")
          .findOneAndUpdate({ _id: ObjectId(params.objectId) }, { $set: { ["template.imagePath"]: params.imageData } })
      }
      templateUpdate = await this.dbo
        .collection("col_messenger_data")
        .findOneAndUpdate({ _id: ObjectId(params.objectId) }, { $set: { ["template." + params.updateType]: params.updateData } })

      if (templateUpdate) {
        let retObj = {
          errorCode: 0,
          errorStatus: "Success",
          data: {},
        };
        return res.status(200).send(retObj);
      } else {
        let retObj = {
          errorCode: 0,
          errorStatus: "No Data Found",
          data: {},
        };
        return res.status(200).send(retObj);
      }
    } catch (error) {
      console.log(error);
    }
  }

  async createNewTemplate(req, res) {
    //console.log("createNewTemplate", req.body)
    try {
      let params = JSON.parse(JSON.stringify(req.body));
      let campaignId = params.campaignId ? parseInt(params.campaignId) : "";
      let city = params.data_city;
      await this.setConnection();
      let templateSave;

      console.log(params)
      let obj = {
        "campaignId": campaignId,
        "campaignName": params.campaignName,
        "campaignTitle": params.campaignName.replace(/\s+/g, ''),
        "template": {

          "title": "",
          "isActive": true,
          "categoryAbbr": "",
          "imagePath": "",
          "content": [
            {
              "language": "english",
              "title": "Eng",
              "content": ""
            },
            {
              "language": "hindi",
              "title": "हिंदी",
              "content": ""
            },
            {
              "language": "marathi",
              "title": "मराठी",
              "content": ""
            },
            {
              "language": "tamil",
              "title": "தமிழ்",
              "content": ""
            },
            {
              "language": "telgu",
              "title": "telgu",
              "content": ""
            },
            {
              "language": "kannad",
              "title": "Kannad",
              "content": ""
            },
            {
              "language": "malaya",
              "title": "മലയാളം",
              "content": ""
            },
            {
              "language": "punjabi",
              "title": "ਪੰਜਾਬੀ",
              "content": ""
            },
            {
              "language": "bengali",
              "title": "বাংলা",
              "content": ""
            },
            {
              "language": "gujarati",
              "title": "ગુજરાતી",
              "content": ""
            }
          ],
          "communicationMedium": [
          ],
          "employeeType": [],
          "employeeId": [],
          "citySelected": [],
          "isGeneric": false
        },
        "isActive": true,
        "createdAt": new Date(),
        "updatedAt": new Date(),
        "createdBy": "10100392",
        "updatedBy": "10015427",
        "isDeleted": false
      }

      templateSave = await this.dbo
        .collection("col_messenger_data")
        .insert(obj)


      if (templateSave) {
        let retObj = {
          errorCode: 0,
          errorStatus: "Success",
          data: templateSave,
        };
        return res.status(200).send(retObj);
      } else {
        let retObj = {
          errorCode: 0,
          errorStatus: "No Data Found",
          data: {},
        };
        return res.status(200).send(retObj);
      }
    } catch (error) {
      console.log(error);
    }
  }

  async sendCombineMessage(req, res) {
    try {
      let params = JSON.parse(JSON.stringify(req.body));
      let campaignId = params.campaignId ? parseInt(params.campaignId) : "";
      if (MAINCITIES.indexOf(params.data_city.toLowerCase()) != -1) {
        params.server_city = params.data_city.toLowerCase();
      } else {
        params.server_city = "remote";
      }
      await this.setConnection();
      let whatsAppReq = {};
      let EmailReq = {};
      let SMSReq = {};
      let smsloggingObj = {};
      let emailloggingObj = {};
      let whatsApploggingObj = {};

      let curlUrlWhatsApp = "http://192.168.20.116/insert_wa_sms.php";
      let curlUrlEmailSms = "http://192.168.20.116/insert.php";
      let emailResponse;
      let smsResponse;
      let whatsAppResponse;
      if (params.communicationMedium.includes('sms') && params['mobile']) {
        console.log("sms---send")
        smsloggingObj.empName = params["empName"]
        smsloggingObj.empCode = params["empCode"]
        smsloggingObj.parentid = params["parentid"]
        smsloggingObj.msgVia = params['mobile']
        smsloggingObj.empType = params['empType']
        smsloggingObj.companyName = params['companyName']
        smsloggingObj.msgType = "sms"
        smsloggingObj.insertDate =  new Date()
        smsloggingObj.source = 'GENIO_LITE'
        smsloggingObj.city = params.server_city
        smsloggingObj.language = params["language"]
        smsloggingObj.campaignName = params["campaignName"]
        SMSReq['source'] = 'Digicatemailcampaign';
        SMSReq['mod'] = 'common_panindia'
        SMSReq['email_id'] = ''
        SMSReq['email_subject'] = '';
        SMSReq['email_text'] = ""
        SMSReq['sender_email'] = '';
        SMSReq['sender_name'] = '';
        SMSReq['email_id_cc'] = '';
        SMSReq['email_id_bcc'] = '';
        SMSReq['reply_to'] = '';
        SMSReq['attachment'] = '';
        SMSReq['mobile'] = params['mobile'];
        SMSReq['sms_text'] = "Hi " + params['contactperson'] + "\n" + params['message'];
        SMSReq['parentid'] = "";
        smsResponse = await curlObj.curlCall(
          "xxx",
          curlUrlEmailSms,
          { data: SMSReq },
          "post",
          {}
        );
        await this.saveMessengerTracking(smsloggingObj);
      }
      if (params.communicationMedium.includes('email') && params['emailId']) {
        console.log("email---send")
        let emlTxt;
        emailloggingObj.empName = params["empName"]
        emailloggingObj.empCode = params["empCode"]
        emailloggingObj.parentid = params["parentid"]
        emailloggingObj.msgVia = params['emailId']
        emailloggingObj.empType = params['empType']
        emailloggingObj.companyName = params['companyName']
        emailloggingObj.msgType = "email"
        emailloggingObj.insertDate =  new Date()
        emailloggingObj.source = 'GENIO_LITE'
        emailloggingObj.city = params.server_city
        emailloggingObj.language = params["language"]
        emailloggingObj.campaignName = params["campaignName"]
        emlTxt = "Hi " + params['contactperson'] + ",<br /> <br />" + params['message'];
        emlTxt = emlTxt + "<br /> <br />-Justdial";
        while (emlTxt.includes("\n")) {
          emlTxt = emlTxt.replace("\n", "<br /> <br />");
        }
        //emlTxt = emlTxt.replace("\n", "<br /> <br />")
        EmailReq['source'] = 'Digicatemailcampaign';
        EmailReq['mod'] = 'common_panindia'
        EmailReq['email_id'] = params['emailId']
        EmailReq['email_subject'] = 'Justdial Message for Your Business';
        EmailReq['email_text'] = emlTxt;
        EmailReq['sender_email'] = 'notifications@justdial.com';
        EmailReq['sender_name'] = '';
        EmailReq['email_id_cc'] = '';
        EmailReq['email_id_bcc'] = '';
        EmailReq['reply_to'] = '';
        EmailReq['attachment'] = '';
        EmailReq['mobile'] = "";
        EmailReq['sms_text'] = "";
        EmailReq['parentid'] = "";
        emailResponse = await curlObj.curlCall(
          "xxx",
          curlUrlEmailSms,
          { data: EmailReq },
          "post",
          {}
        );
        await this.saveMessengerTracking(emailloggingObj);
      }
      if (params.communicationMedium.includes('whatsapp') && params['mobile']) {
        whatsApploggingObj.empName = params["empName"]
        whatsApploggingObj.empCode = params["empCode"]
        whatsApploggingObj.parentid = params["parentid"]
        whatsApploggingObj.msgVia = params['mobile']
        whatsApploggingObj.empType =  params['empType']
        whatsApploggingObj.companyName = params['companyName']
        whatsApploggingObj.msgType = "whatsapp"
        whatsApploggingObj.insertDate =  new Date()
        whatsApploggingObj.source = 'GENIO_LITE'
        whatsApploggingObj.city = params.server_city
        whatsApploggingObj.language = params["language"]
        whatsApploggingObj.campaignName = params["campaignName"]
        console.log("whatsapp---send")
        whatsAppReq['source'] = 'Digicatemailcampaign';
        whatsAppReq['wa_flag'] = 1;
        whatsAppReq['uname'] = params['contactperson'];
        whatsAppReq['mobile'] = params['mobile'];
        whatsAppReq['sms_text'] = params['message'];
        whatsAppReq["urlFlag"] = 1;
        whatsAppResponse = await curlObj.curlCall(
          "xxx",
          curlUrlWhatsApp,
          { data: whatsAppReq },
          "post",
          {}
        );
        await this.saveMessengerTracking(whatsApploggingObj);
      }
      console.log("emailResponse==", emailResponse)
      console.log("whatsAppResponse==", whatsAppResponse)
      console.log("smsResponse===", smsResponse)
      if (emailResponse || whatsAppResponse || smsResponse) {
        let retObj = {
          errorCode: 0,
          errorStatus: "Message sent successfully",
          data: {},
        };
        return res.status(200).send(retObj);
      } else {
        let retObj = {
          errorCode: 0,
          errorStatus: "No Data Found",
          data: {},
        };
        return res.status(200).send(retObj);
      }
    } catch (error) {
      console.log(error);
    }
  }

  async getContractAbbr(req, res) {
    try {
      let { contractCats } = req.body;
      let catData = [];
      let totalCatCount = 0;
      let passingAbbrCount = 0;
      let categoryAbbrArr = [];
      let categoryAbbrObj = {};
      let isGeneric = false;
      let finalAbbr = '';
      retObj = {};
      //console.log("req.body==", req.body)
      // contractCats = '11947094,10427686,10356131,10159446,10049261,10000395';
      var result = await axios.get(paths.categoryurl + 'services/category_data_api.php' + '?city=' + encodeURI(req.body.data_city) + '&module=' + req.body.module + '&callsrc=genio&q_type=localinfo&where={"national_catid":"' + contractCats + '"}&return=national_catid,campaign_type_abbr,display_product_abbr&orderby=callcount desc');

      if (result && result.data && result.data) {
        var response = result.data;
        if (response.errorcode == 0) {
          catData = response.results;
        }
      }
      //console.log("result", result.data)
      totalCatCount = catData.length;
      passingAbbrCount = totalCatCount * 0.51;
      //console.log("catData", catData)
      if (totalCatCount > 0) {
        catData.forEach(element => {
          var tmpAbbr = [];
          tmpAbbr = element.campaign_type_abbr.split('|');
          tmpAbbr.shift();
          tmpAbbr.pop();
          tmpAbbr.forEach(childElement => {
            categoryAbbrArr.push(childElement);
          });
        });
      }

      categoryAbbrArr.forEach(element => {
        categoryAbbrObj[element] = categoryAbbrObj[element] ? categoryAbbrObj[element] + 1 : 1;
        if (categoryAbbrObj[element] >= passingAbbrCount) {
          finalAbbr = element;
        }
      });

      if (!finalAbbr) {
        isGeneric = true;
      }

      retObj = {
        errorCode: 0,
        data: {
          isGeneric,
          categoryAbbr: finalAbbr
        }
      }

      return res.status(200).send(retObj);
    } catch (err) {
      var retObj = {};
      // console.log(err);
      retObj = {
        errorCode: 1,
        errorStatus: err.message
      }
      return res.status(500).send(retObj);
    }
  }
  async getExistingAbbr(req,res){
   // console.log("getTemplateDetailsById", req.body)
    try {
      let params = JSON.parse(JSON.stringify(req.body));
      let campaignId = parseInt(params.campaignId);
      let city = params.data_city;
      let existAbbr = req.body.existAbbr
      await this.setConnection();
      let findReq = { 
        campaignId: params.campaignId, 
        ["template." + "isActive"]: true, 
        isDeleted: false, 
        ["template.categoryAbbr"] : existAbbr,
        _id:{$ne:  ObjectId(params.objectId)}
      }

      //console.log(findReq)
      let campaignMsgArr = await this.dbo
        .collection("col_messenger_data")
        .find(findReq).toArray();
       // console.log("campaignMsgArr==",campaignMsgArr)

      if (campaignMsgArr) {
        let retObj = {
          errorCode: 0,
          errorStatus: "",
          data: campaignMsgArr,
        };
        return res.status(200).send(retObj);
      } else {
        let retObj = {
          errorCode: 0,
          errorStatus: "No Data Found",
          data: {},
        };
        return res.status(200).send(retObj);
      }
    } catch (error) {
      console.log(error);
    }
  }

  async saveMessengerTracking(reqObj) {
    //console.log("saveLogs--", reqObj)
    console.log("reqObj",reqObj)
    await this.setConnection();
    try {
      let getMainData = await this.dbo
        .collection("col_messenger_traking_log")
        .save(reqObj);
    } catch (error) {
      //console.log("Budget class", error);
    }
  }

  async getMessengerTracking(req, res) {
     console.log("fetchMessageTemplateList---", req.body)
     try {
       let params = JSON.parse(JSON.stringify(req.body));
       let campaignId = parseInt(params.campaignId);
       let city = params.data_city;
       let condition = {};
       if(req.body.type){
        condition.campaignName = req.body.type
       }
       condition.insertDate =  { $gte: new Date(req.body.from), $lte: new Date(req.body.to) }
       await this.setConnection();
       let campaignMsgArr = await this.dbo
         .collection("col_messenger_traking_log")
         .find(condition,{ _id: 0 , empName: 1, empCode: 1,parentid:1, msgVia:1, empType:1, companyName:1, msgType:1, insertDate:1, source:1, city:1, language:1, campaignName:1 })
         .toArray();
       if (campaignMsgArr.length > 0) {
         let retObj = {
           errorCode: 0,
           errorStatus: "",
           data: campaignMsgArr,
         };
         return res.status(200).send(retObj);
       } else {
         let retObj = {
           errorCode: 0,
           errorStatus: "No Data Found",
           data: {},
         };
         return res.status(200).send(retObj);
       }
     } catch (error) {
       console.log(error);
     }
   }




  //end 

}
module.exports = MessengerAdminClass;
