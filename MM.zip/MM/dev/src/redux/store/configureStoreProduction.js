import { createStore, compose, applyMiddleware } from "redux";
import { createLogger } from "redux-logger";
//import { composeWithDevTools } from "redux-devtools-extension";
import thunkMiddleware from "redux-thunk";
import rootReducer from "../reducers";

//const loggerMiddleware = createLogger();
const middleWare = [];

middleWare.push(thunkMiddleware);
const loggerMiddleware = createLogger({
	predicate: () => process.env.NODE_ENV === "development",
});
middleWare.push(loggerMiddleware);

const store = createStore(
	rootReducer,
	//composeEnhancers(
	//applyMiddleware(thunkMiddleware, loggerMiddleware)
	//)
	{},
	compose(applyMiddleware(...middleWare)),
);

export default store;
