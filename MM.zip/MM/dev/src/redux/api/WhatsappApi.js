import axios from "axios";
import { getLocalStorage, setLocalStorage } from "./../../utilities/localStorage";

require("babel-polyfill");
//var CryptoJS = require("crypto-js");
//var API_PATH_2 = "http://172.29.86.26:7200/jdboxNode";
if (API_PATH_INFO != "" && API_PATH_INFO == "dev") {
	var API_PATH = "/jdboxNode";
} else {
	var API_PATH = "http://192.168.20.17:8082/jdboxNode";
}
//var API_PATH = "http://192.168.20.17:8082/jdboxNode";
//var API_PATH = "http://192.168.8.121:8082";

export default class WhatsappApi {
	constructor() {
		let token = getLocalStorage("token") || "";
		if (token != "") {
			console.log(token);
			// axios.defaults.headers.common = {
			// 	Authorization: `Bearer ${token}`,
			// };
		}
	}

	static getAccessToken = async (params) => {
		try {
			//let res = await axios.post(API_PATH + "/geniosales/auth", params).then((response) => {
			//	let resp = response.data;
			// axios.defaults.headers.common = {
			// 	Authorization: `Bearer ${resp.data.token}`,
			// };
			//return resp.data.token;
			return 1;
			//});
			//return res;
		} catch (e) {
			return { error: e };
		}
	};

	resetAccessToken = async (token) => {
		try {
			axios.defaults.headers.common = {
				Authorization: `Bearer ${token}`,
			};
			setLocalStorage("token", res);
			return token;
		} catch (e) {
			return { error: e };
		}
	};

	getLocData = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/" + params.data_city.toLowerCase() + "/bform/get-loc-data", params);

			//  let res = {
			//  	data: { error: { code: 0, msg: "Success" }, data: { country_id: 98, country_name: "India", state_id: 1, state_name: "Maharashtra", city_id: 29, ct_name: "Mumbai", stdcode: "022", dialer_mapped_cityname: "Mumbai" } },
			//  	status: "200",
			//  };
			let isError = res.data.error.code != undefined && res.data.error.code != "" && res.data.error.code == 1 ? true : false;

			if (res.status == "200" && isError) {
				return { component_error: "something goes wrong" };
			} else if (res.status == "200" && !isError) {
				return res.data;
			} else {
				return res.data;
			}
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};

	fetchLiveData = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/fetchLiveDataBeta", params);
			let isError = res.data.errorCode != undefined && res.data.errorCode != "" && res.data.errorCode == 1 ? true : false;
			if (res.status == "200" && isError) {
				return { component_error: errorStatus };
			} else {
				return res.data;
			}
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};

	checkLiveContract = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/checkLiveContractBeta", params);
			//let res = { status: "200", data: { errorCode: "0", errormsg: "test" } };

			let isError = false;
			//res.data.errorCode != undefined && res.data.errorCode != "" && res.data.errorCode == 1 ? true : false;

			if (res.status == "200" && isError) {
				return { component_error: res.data.errormsg };
			} else {
				//let res = { data: true };
				return res.data;
			}
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};

	getShadowTabData = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/contract/getShadowTabData", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};

	getPopCatsNdActiveCamps = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/campaignInfo/getPopCatsNdActiveCamps", params);
			let isError = res.data.errorCode != undefined && res.data.errorCode != "" && res.data.errorCode == 1 ? true : false;
			let errorStatus = res.data.errorStatus != undefined && res.data.errorStatus != "" && res.data.errorStatus != null ? res.data.errorStatus : "";
			let successMsg = res.data.successMsg != undefined && res.data.successMsg != "" && res.data.successMsg != null ? res.data.successMsg : "";

			if (res.status == "200" && isError && errorStatus != "") {
				return { component_error: errorStatus };
			} else if (res.status == "200" && !isError && successMsg != "") {
				return { component_success: successMsg };
			} else {
				return res.data;
			}
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};

	getWhatsappMsg = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/getWhatsappMsgBeta", params);
			let isError = res.data.errorCode != undefined && res.data.errorCode != "" && res.data.errorCode == 1 ? true : false;
			let errorStatus = res.data.errorStatus != undefined && res.data.errorStatus != "" && res.data.errorStatus != null ? res.data.errorStatus : "";
			let successMsg = res.data.successMsg != undefined && res.data.successMsg != "" && res.data.successMsg != null ? res.data.successMsg : "";

			if (res.status == "200" && isError && errorStatus != "") {
				return { component_error: errorStatus };
			} else if (res.status == "200" && !isError && successMsg != "") {
				return { component_success: successMsg };
			} else {
				//return res.data;
				//console.log(res.data.data)
				return res.data.data;
			}
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};

	getRatingsAPI = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/contract/getRatingsAPI", params);
			let isError = res.data.errorCode != undefined && res.data.errorCode != "" && res.data.errorCode == 1 ? true : false;
			let errorStatus = res.data.errorStatus != undefined && res.data.errorStatus != "" && res.data.errorStatus != null ? res.data.errorStatus : "";
			let successMsg = res.data.successMsg != undefined && res.data.successMsg != "" && res.data.successMsg != null ? res.data.successMsg : "";

			if (res.status == "200" && isError && errorStatus != "") {
				return { component_error: errorStatus };
			} else if (res.status == "200" && !isError && successMsg != "") {
				return { component_success: successMsg };
			} else {
				return res.data;
			}
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};

	editListingURL = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/editListingURLBeta", params);

			let isError = res.data.error.code != undefined && res.data.error.code != "" && res.data.error.code == 1 ? true : false;
			let errorStatus = res.data.errorStatus != undefined && res.data.errorStatus != "" && res.data.errorStatus != null ? res.data.errorStatus : "";
			let successMsg = res.data.successMsg != undefined && res.data.successMsg != "" && res.data.successMsg != null ? res.data.successMsg : "";

			if (res.status == "200" && isError && errorStatus != "") {
				return { component_error: errorStatus };
			} else if (res.status == "200" && !isError && successMsg != "") {
				return { component_success: successMsg };
			} else {
				//return res.data.results;
				return res.data;
			}
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};

	getMinimumBudget = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/getMinimumBudgetBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};
	getExistingCats = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/getExistingCatsBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};
	getGstLink = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/contract/getGstLink", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};
	getECSBouncePromoData = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/contract/getECSBouncePromoData", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};
	sendProductLink = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/sendProductLinkBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};
	getProductLinkNew = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/getProductLinkNewBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};
	getProductLink = async (params) => {
		try {
			//let res = { status: "200", data: { urlList: { "022PW002162": { status: 1, shortUrl: "https://jdb2b.co/qm8N9", msg: "", token: "" } } } };
			let res = await axios.post(API_PATH + "/geniosales/getProductLinkBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};
	getEvoucherLink = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/contract/getEvoucherLink", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};
	getdigicatonlyemailContent = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/getdigicatonlyemailContentBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};
	getimagePathWhatsapp = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/getImagePathWhatsappBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};
	getWhatsappShortURL = async (params) => {
		try {
			//let res = { status: "200", data: { success: true, message: "", results: { jdweburl: "https://smenterprisemumbaimasjidbunder1.justdial.com/offer-43YWUEKX123-12354ceT" } } };
			let res = await axios.post(API_PATH + "/geniosales/getWhatsappShortURLBeta", params);

			return res.data.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};
	insertWhatsapp = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/insertWhatsappBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};
	insertWhatsappData = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/insertWhatsappDataBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};

	senddigiemailsms = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/senddigiemailsmsBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};
	senddigiwhatsapp = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/sendDigiWhatsappBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};
	insertWhatsappSendMsg = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/insertWhatsappSendMsgBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};
	sendOfficialWhatsapp = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/sendOfficialWhatsappBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};
	insertOnboardingValidation = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/insertOnboardingValidationBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};

	checkWebsiteLive = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/checkWebsiteLiveBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};

	getBToCUrlLink = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/getBToCUrlLinkBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};

	chkJdMartCatType = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/chkJdMartCatTypeBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};

	catalogueKycUrl = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/catalogueKycUrlBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};
	sendCombinedMsg = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/sendCombinedMsgBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};

	sendLogSmsEmail = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/sendLogSmsEmailBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};
	sendOnlyWaMsg = async (params) => {
		try {
			let res = await axios.post(API_PATH + "/geniosales/sendOnlyWaMsgBeta", params);
			return res.data;
		} catch (e) {
			//console.log(e);
			return { error: e };
		}
	};
}
