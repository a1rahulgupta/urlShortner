import GenioApi from "./../api/GenioApi";
//import * as dispatchActions from "./dispatchActions";
import ActionUtility from "./ActionUtility";
import * as types from "./../actions/actionTypes";
require("babel-polyfill");

const genioApi = new GenioApi();

export function fetchUser(userid) {
	console.log("user")
	return async (dispatch) => {
		//call Normal Action
		//await ActionUtility.normalDispatch(dispatch, types.SET_USER);

		//call Thunk Action
		await ActionUtility.thunkDispatch(dispatch, types.SET_USER, genioApi.getUserDeta, userid);

		//call Normal API
		//await ActionUtility.normalApiCall(dispatch, types.SET_USER);
	};
}

export function getAhdLineage(userid) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatch(dispatch, types.FETCH_LINEAGE, genioApi.getAhdLineage, userid);
	};
}

export function searchBusiness(params) {
	return async (dispatch) => {
		//call Normal Action
		//await ActionUtility.normalDispatch(dispatch, types.SET_USER);
		if (params["clearFlag"] == true) {
			await ActionUtility.normalDispatch(dispatch, "CLEAR_SUGGESTION");
		} else {
			//call Thunk Action
			await ActionUtility.thunkDispatch(dispatch, types.SEARCH_SUGGESTION, genioApi.searchBusiness, params);
		}

		//call Normal API
		//await ActionUtility.normalApiCall(dispatch, types.SET_USER);
	};
}
export function LHSToggle() {
	return async (dispatch) => {
		await ActionUtility.normalDispatch(dispatch, "LHS_TOGGLE");
	};
}
export function filterToggle() {
	return async (dispatch) => {
		await ActionUtility.normalDispatch(dispatch, "FILTER_TOGGLE");
	};
}
export function setRecentSearch() {
	return async (dispatch) => {
		await ActionUtility.normalDispatch(dispatch, "RECENT_SEARCH");
	};
}
export function applyFilters(params) {
	return async (dispatch) => {
		//await ActionUtility.thunkDispatch(dispatch, types.APPLY_FILTERS, GenioApi.applyFilters, params);
		await ActionUtility.normalDispatch(dispatch, types.APPLY_FILTERS, params);
	};
}
export function applyOnbFilters(params) {
	return async (dispatch) => {
		await ActionUtility.normalDispatch(dispatch, types.APPLY_ONB_FILTERS, params);
		// await ActionUtility.normalDispatch(dispatch, types.APPLY_ONB_FILTERS, params);
	};
}
export function clearOnbFilters() {
	return async (dispatch) => {
		await ActionUtility.normalDispatch(dispatch, "CLEAR_ONB_DATA");
	};
}
export function applySalesFilters(params) {
	return async (dispatch) => {
		//await ActionUtility.thunkDispatch(dispatch, types.APPLY_FILTERS, GenioApi.applyFilters, params);
		await ActionUtility.normalDispatch(dispatch, types.APPLY_SALES_FILTERS, params);
	};
}
export function applySalesEcsFilters(params) {
	return async (dispatch) => {
		//await ActionUtility.thunkDispatch(dispatch, types.APPLY_FILTERS, GenioApi.applyFilters, params);
		await ActionUtility.normalDispatch(dispatch, types.APPLY_SALES_ECS_FILTERS, params);
	};
}
export function applyEcsFilters(params) {
	return async (dispatch) => {
		//await ActionUtility.thunkDispatch(dispatch, types.APPLY_FILTERS, GenioApi.applyFilters, params);
		await ActionUtility.normalDispatch(dispatch, types.APPLY_ECS_FILTERS, params);
	};
}
export function applyDigiPaymentFilter(params) {
	return async (dispatch) => {
		//await ActionUtility.thunkDispatch(dispatch, types.APPLY_FILTERS, GenioApi.applyFilters, params);
		await ActionUtility.normalDispatch(dispatch, types.DIGITAL_PAYMENT_STATS_FILTER, params);
	};
}
export function resetError(params) {
	return async (dispatch) => {
		//await ActionUtility.thunkDispatch(dispatch, types.APPLY_FILTERS, GenioApi.applyFilters, params);
		await ActionUtility.normalDispatch(dispatch, types.RESET_ERROR);
	};
}

export function citySelection(params) {
	return async (dispatch) => {
		//call Normal Action
		//await ActionUtility.normalDispatch(dispatch, types.SET_USER);
		if (params["clearFlag"] == true) {
			await ActionUtility.normalDispatch(dispatch, "CLEAR_CITIES");
		} else {
			//call Thunk Action
			await ActionUtility.thunkDispatch(dispatch, types.FETCH_CITIES, genioApi.selectCity, params);
		}

		//call Normal API
		//await ActionUtility.normalApiCall(dispatch, types.SET_USER);
	};
}

export function setRecentSearches(params) {
	//alert(params,"")
	return async (dispatch) => {
		//call Normal Action
		//await ActionUtility.normalDispatch(dispatch, types.SET_USER);
		// if (params["clearFlag"] == true) {
		// 	await ActionUtility.normalDispatch(dispatch, "CLEAR");
		// } else {
		//call Thunk Action
		// console.log("params ",params,types)
		await ActionUtility.normalDispatch(dispatch, types.SET_RECENT_CITIES, params);
		// }

		//call Normal API
		//await ActionUtility.normalApiCall(dispatch, types.SET_USER);
	};
}
export function setDataCity(params) {
	return async (dispatch) => {
		//call Normal Action
		await ActionUtility.normalDispatch(dispatch, types.SET_DATACITY, params);
	};
}

export function getAppointments(params) {
	return async (dispatch) => {
		//call Normal Action
		//await ActionUtility.normalDispatch(dispatch, types.SET_USER);

		//call Thunk Action
		await ActionUtility.thunkDispatch(dispatch, types.GET_APPOINTMENTS, genioApi.getAppointments, params);
		//call Normal API
		//await ActionUtility.normalApiCall(dispatch, types.SET_USER);
	};
}
export function getTodaysAppointments(params) {
	return async (dispatch) => {
		//call Normal Action
		//await ActionUtility.normalDispatch(dispatch, types.SET_USER);

		//call Thunk Action
		await ActionUtility.thunkDispatch(dispatch, types.GET_TODAYS_APPOINTMENTS, genioApi.getTodaysAppointments, params);
		//call Normal API
		//await ActionUtility.normalApiCall(dispatch, types.SET_USER);
	};
}
export function getLastDisposition(params) {
	return async (dispatch) => {
		//call Normal Action
		//await ActionUtility.normalDispatch(dispatch, types.SET_USER);

		//call Thunk Action
		await ActionUtility.thunkDispatch(dispatch, types.GET_LAST_DISPOSITION, genioApi.getLastDisposition, params);
		//call Normal API
		//await ActionUtility.normalApiCall(dispatch, types.SET_USER);
	};
}

export function getNewBusiness(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatch(dispatch, types.GET_NEW_BUSINESS, genioApi.getNewBusiness, params);
		//call Normal API
		//await ActionUtility.normalApiCall(dispatch, types.SET_USER);
	};
}
export function getAssignmentData(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatch(dispatch, types.GET_ASSIGNMENTDATA, genioApi.getAssignmentData, params);
		//call Normal API
		//await ActionUtility.normalApiCall(dispatch, types.SET_USER);
	};
}
export function fetchGenioGraph(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatch(dispatch, types.FETCH_GENIO_GRAPH, genioApi.fetchGenioGraph, params);
		//call Normal API
		//await ActionUtility.normalApiCall(dispatch, types.SET_USER);
	};
}

export function getDealsPending(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatch(dispatch, types.GET_DEALS_PENDING, genioApi.getDealsPending, params);
		//call Normal API
		//await ActionUtility.normalApiCall(dispatch, types.SET_USER);
	};
}

export function getDealsClosed(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatch(dispatch, types.GET_DEALS_CLOSED, genioApi.getDealsClosed, params);
		//call Normal API
		//await ActionUtility.normalApiCall(dispatch, types.SET_USER);
	};
}

export function getFAQDetails(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatch(dispatch, types.GET_FAQ_DETAILS, genioApi.getFAQDetails, params);
		//call Normal API
		//await ActionUtility.normalApiCall(dispatch, types.SET_USER);
	};
}
export function fetchMenuLinks(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatch(dispatch, types.FETCH_MENU_LINKS, genioApi.fetchMenuLinks, params);
		//call Normal API
		//await ActionUtility.normalApiCall(dispatch, types.SET_USER);
	};
}

export const getMenuLinks = async (params) => {
	let res = await genioApi.fetchMenuLinks(params);
	return res.data;
};

export function getActionData(params, type, apiUrl) {
	//console.log("-apiUrlapiUrl----", apiUrl, type);
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, type, genioApi.getActionData, apiUrl, params);
	};
}
export function downsellReport(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.GET_DOWNSELL_REPORT, genioApi.downsellReport, params);
	};
}

export function getMobileNumber(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.GET_MOBILE_NUMBER, genioApi.getMobileNumber, params);
	};
}
export function getDigitalPaymentStats(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.DIGITAL_PAYMENT_STATS, genioApi.getDigitalPaymentStats, params);
	};
}
export function getMyPoints(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.GET_MY_POINTS, genioApi.getMyPoints, params);
	};
}
export function getPaymentDetails(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.GET_PAYMENT_DETAILS, genioApi.getPaymentDetails, params);
	};
}
export function getMyRatings(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.MY_RATINGS, genioApi.getMyRatings, params);
	};
}
export function getHotKeywords(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.HOT_KEYWORD_DATA, genioApi.getHotDataKeyword, params);
	};
}
export function cancelDownsellRequest(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.CANCEL_DOWNSELL, genioApi.cancelDownsellRequest, params);
	};
}

export function getMyRecordings(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.GET_MY_RECORDINGS, genioApi.getMyRecordings, params);
	};
}
export function toggleHistory(params) {
	return async (dispatch) => {
		await ActionUtility.normalDispatch(dispatch, types.SHOW_RECORDING_HISTORY, params);
	};
}

export function toggleComponentLoader(params) {
	return async (dispatch) => {
		await ActionUtility.normalDispatch(dispatch, types.SHOW_COMPONENT_LOADER, params);
	};
}

export function getBounceReport(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.GET_BOUNCE_REPORT, genioApi.getBounceReport, params);
	};
}

export function getShadowData(shadowParams) {
	return genioApi.getShadowData(shadowParams);
}

export function fetchLiveData(liveParams) {
	return genioApi.fetchLiveData(liveParams);
}

export function getWebRedirectToken(params) {
	return genioApi.getWebRedirectToken(params);
}
export function fetchOnboardingLiveStatus(params) {
	return genioApi.fetchOnboardingLiveStatus(params);
}
export function insertOnboardingData(params) {
	return genioApi.insertOnboardingData(params);
}
export function chkContractEditAccess(params) {
	return genioApi.chkContractEditAccess(params);
}

export function bformValidation(params) {
	return genioApi.bformValidation(params);
}

export function checkDuplicateCont(params) {
	return genioApi.checkDuplicateCont(params);
}

export function submitNewBusiness(params) {
	return genioApi.submitNewBusiness(params);
}

export function newBusinessCreation(params) {
	return async (dispatch) => {
		await ActionUtility.normalDispatch(dispatch, "CREATE_NEW_BUSINESS", params);
	};
}

export function getAreaXhr(params) {
	return genioApi.getAreaXhr(params);
}

export function getPincodeXhr(params) {
	return genioApi.getPincodeXhr(params);
}

export function getPincodesBeta(params) {
	return genioApi.getPincodesBeta(params);
}
export function financeECSHits(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.ECS_HITS, genioApi.financeECSHits, params);
	};
}
export function financeECSWithPid(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.ECS_HITS_PID, genioApi.financeECSWithPid, params);
	};
}
export function financeShowPayment(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.FINANCE_SHOW_PAYMENT, genioApi.financeShowPayment, params);
	};
}
export function financeEcsSi(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.FINANCE_ECS_SI, genioApi.financeEcsSi, params);
	};
}
export function financeMandateStatus(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.FINANCE_MANDATE_STATUS, genioApi.financeMandateStatus, params);
	};
}
export function financeSalesReport(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.FINANCE_SALES_REPORT, genioApi.financeSalesReport, params);
	};
}
export function financeECSSalesReport(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.FINANCE_ECSSALES_REPORT, genioApi.financeECSSalesReport, params);
	};
}
export function financeGenerateInvoice(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.FINANCE_GENERATE_INVOICE, genioApi.financeGenerateInvoice, params);
	};
}
export function generateInvoiceAutosuggest(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.GENERATE_INVOICE_AUTOSUGGEST, genioApi.generateInvoiceAutosuggest, params);
	};
}
export function fetchReceipHTMLtDataBeta(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.FINANCE_FETCH_HTML_DATA, genioApi.fetchReceipHTMLtDataBeta, params);
	};
}
export function sendInvoiceEmail(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.SEND_INVOICE_EMAIL, genioApi.sendInvoiceEmail, params);
	};
}
export function JDAppdownloadstatus(params) {
	return async (dispatch) => {
		//call Normal Action
		//await ActionUtility.normalDispatch(dispatch, types.SET_USER);

		//call Thunk Action
		await ActionUtility.thunkDispatch(dispatch, types.JD_APP_DOWNLOAD_STATUS, genioApi.JDAppdownloadstatus, params);
		//call Normal API
		//await ActionUtility.normalApiCall(dispatch, types.SET_USER);
	};
}
export function JDMartdownloadstatus(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatch(dispatch, types.JD_MART_DOWNLOAD_STATUS, genioApi.JDMartdownloadstatus, params);
	};
}
export function fetchAppointmentInfo(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatch(dispatch, types.GET_APPOINTMENTS_INFO, genioApi.fetchAppointmentInfo, params);
	};
}
export function fetchOnboardingdata(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.GET_ONB_DATA, genioApi.fetchOnboardingdata, params);
	};
}
export function updateDisposition(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatch(dispatch, types.UPDATE_DISPOSITION, genioApi.updateDisposition, params);
	};
}
export function fetchPaymentSummary(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatch(dispatch, types.FETCH_PAYMENT_SUMMARY, genioApi.fetchPaymentSummary, params);
	};
}
export function closePaymentPopUp() {
	return async (dispatch) => {
		await ActionUtility.normalDispatch(dispatch, "CLOSE_PAYMENT");
	};
}
export function closeMustReadInstructions() {
	return async (dispatch) => {
		await ActionUtility.normalDispatch(dispatch, "MUST_READ_INSTRUCTIONS");
	};
}
export function clearFinanceData() {
	return async (dispatch) => {
		await ActionUtility.normalDispatch(dispatch, "CLEAR_FINANCE_DATA");
	};
}

export function getFeedbackReport(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.GET_FEEDBACK_REPORT, genioApi.getFeedbackReport, params);
	};
}
export function sendFeedbackReport(params) {
	return async (dispatch) => {
		console.log("in action....");
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.SEND_FEEDBACK_REPORT, genioApi.sendFeedbackReport, params);
	};
}
export function submitHelpDeskQuery(params) {
	return async (dispatch) => {
		console.log("in action....");
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.SEND_HELP_DESK_QUERY, genioApi.submitHelpDeskQuery, params);
	};
}
export function resendJdpayLink(params) {
	return async (dispatch) => {
		console.log("in action....");
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.RESEND_JDPAY_LINK, genioApi.resendJdpayLink, params);
	};
}
export function deleteJdpayLink(params) {
	return async (dispatch) => {
		console.log("in action....");
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.DELETE_JDPAY_LINK, genioApi.deleteJdpayLink, params);
	};
}
export function updateDealPending(payload) {
	return async (dispatch) => {
		dispatch({ type: types.UPDATE_DEALS_PENDING, payload });
	};
}
export function getreportmessengerData(params) {
	return genioApi.getreportmessengerData(params);
}
export function insertmessengerdata(params) {
	return genioApi.insertmessengerdata(params);
}

export const loggedByCS = async (params) => {
	let res = await genioApi.loggedbycs(params);
	return res.data;
};
export function getCategoryDetails(params) {
	return genioApi.getCategoryDetails(params);
}
export function getExistingCats(params) {
	return genioApi.getExistingCats(params);
}

export function submitKeywords(params) {
	return genioApi.submitKeywords(params);
}
export function getShadowTabData(params) {
	return genioApi.getShadowTabData(params);
}

export function fetchGSTN(params) {
	return genioApi.fetchGSTN(params);
}
export function fetchGSTNstateCode(params) {
	return genioApi.fetchGSTNstateCode(params);
}
export function getAllCities(params) {
	return genioApi.selectCity(params);
}
export function addGSTNDetails(params) {
	return genioApi.addGSTNDetails(params);
}

export function clearTaxApiForGST(params) {
	return genioApi.clearTaxApiForGST(params);
}

export function fetchMessageCampaignList(params) {
	return genioApi.fetchMessageCampaignList(params);
}

export function fetchMessageTemplateList(params){
	return genioApi.fetchMessageTemplateList(params)
}
export function activeInactiveMessageCampaign(params){
	return genioApi.activeInactiveMessageCampaign(params)
}
export function deleteTemplate(params){
	return genioApi.deleteTemplate(params)
}
export function getTemplateDetailsById(params){
	return genioApi.getTemplateDetailsById(params)
}
export function updateTemplateDetails(params){
	return genioApi.updateTemplateDetails(params)
}
export function createNewTemplate(params){
	return genioApi.createNewTemplate(params)
}
export function fetchMainCities(params){
	return genioApi.fetchMainCities(params)
}
export function fetchRemoteCities(params){
	return genioApi.fetchRemoteCities(params)
}
export function fetchTierCities(params){
	return genioApi.fetchTierCities(params)
}

export function fetchEmployeeForMessanger(params){
	return genioApi.fetchEmployeeForMessanger(params)
}
export function getPresentationAutoSuggest(params){
	return genioApi.getPresentationAutoSuggest(params)
}
export function getMessengerTracking(params){
	return genioApi.getMessengerTracking(params)
}

export function getExistingAbbr(params){
	return genioApi.getExistingAbbr(params)
}
export function downloadMessengerXls(params){
	return genioApi.downloadMessengerXls(params)
}






export function selectCamp(params) {
	return async dispatch => {
	  await ActionUtility.normalDispatch(dispatch, "SELECT_CAMP", params);
	};
  }


export function getCategoryAuto(params) {
	return async (dispatch) => {
		console.log("in action....");
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.CATEGORY_AUTO, genioApi.getCategoryAuto, params);
	};
}
export function setLoggerCompanyParentid(params) {
	return async (dispatch) => {
		//await ActionUtility.thunkDispatch(dispatch, types.APPLY_FILTERS, GenioApi.applyFilters, params);
		await ActionUtility.normalDispatch(dispatch, types.LOGGER_COMPANY_PARENTID, params);
	};
}
export function getTrafficData(params) {
	return async (dispatch) => {
		//await ActionUtility.normalDispatch(dispatch, types.TRAFFIC_DATA, params);
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.TRAFFIC_DATA, genioApi.getTrafficData, params);
	};
}
export function setCategoryNaming(params) {
	return async (dispatch) => {
		await ActionUtility.normalDispatch(dispatch, types.SETCATEGORYNAMING, params);
	};
}
export function getCatBidders(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.GET_CATBIDDERS, genioApi.getCatBidders, params);
	}
}
export function submitMultiParetage(params){
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.SUBMITMULTIPARENTAGE, genioApi.submitMultiParetage, params);
	}
}
export function submitCatPreviewBeta(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.SUBMITCATPREVIEWBETA, genioApi.submitCatPreviewBeta, params);
	}
}
export function submitKeywordsBeta(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.SUBMITKEYWORDSBETA, genioApi.submitKeywordsBeta, params);
	}
}
export function existingcatsBeta(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.EXISTINGCATSBETA, genioApi.getExistingCatsBeta, params);
	}
}
export function submitCatsModerationBeta(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.SUBMITCATSMODERATIONBETA, genioApi.submitCatsModerationBeta, params);
	}
}
export function getB2bCompetitorCount(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.B2BCOMPETITORCOUNT, genioApi.getB2bCompetitorCount, params);
	}
}
export function updateLiveCategories(params) {
	return async (dispatch) => {
		await ActionUtility.thunkDispatchWithUrl(dispatch, types.UPDATELIVECATEGORIES, genioApi.updateLiveCategories, params);
	}
}
