import WhatsappApi from "./../api/WhatsappApi";
//import * as dispatchActions from "./dispatchActions";
import ActionUtility from "./ActionUtility";
import * as types from "./../actions/actionTypes";
require("babel-polyfill");

const whatsappApi = new WhatsappApi();

// export function getLocData(params) {
// 	return async (dispatch) => {
// 		//call Thunk Action
// 		await ActionUtility.thunkDispatch(dispatch, types.WHATSAPP_GET_LOC_DATA, whatsappApi.getLocData, params);
// 	};
// }
// export function fetchLiveData(params) {
// 	return async (dispatch) => {
// 		//call Thunk Action
// 		await ActionUtility.thunkDispatch(dispatch, types.WHATSAPP_FETCH_LIVE_DATA, whatsappApi.fetchLiveData, params);
// 	};
// }
// export function checkLiveContract(params) {
// 	return async (dispatch) => {
// 		//call Thunk Action
// 		await ActionUtility.thunkDispatch(dispatch, types.WHATSAPP_CHECK_LIVE_DATA, whatsappApi.checkLiveContract, params);
// 	};
// }
// export function getShadowTabData(params) {
// 	return async (dispatch) => {
// 		//call Thunk Action
// 		await ActionUtility.thunkDispatch(dispatch, types.WHATSAPP_GET_SHADOW_TAB_DATA, whatsappApi.getShadowTabData, params);
// 	};
// }
// export function getPopCatsNdActiveCamps(params) {
// 	return async (dispatch) => {
// 		//call Thunk Action
// 		await ActionUtility.thunkDispatch(dispatch, types.WHATSAPP_GET_POP_CAT_AND_ACTIVE_CAMPS, whatsappApi.getPopCatsNdActiveCamps, params);
// 	};
// }
// export function getWhatsappMsg(params) {
// 	return async (dispatch) => {
// 		//call Thunk Action
// 		await ActionUtility.thunkDispatch(dispatch, types.WHATSAPP_GET_WHATSAPP_MSG, whatsappApi.getWhatsappMsg, params);
// 	};
// }
// export function JDAppdownloadstatus(params) {
// 	return async (dispatch) => {
// 		//call Thunk Action
// 		await ActionUtility.thunkDispatch(dispatch, types.WHATSAPP_JD_APP_DOWNLOAD_STATUS, whatsappApi.JDAppdownloadstatus, params);
// 	};
// }
// export function getRatingsAPI(params) {
// 	return async (dispatch) => {
// 		//call Thunk Action
// 		await ActionUtility.thunkDispatch(dispatch, types.WHATSAPP_RATING, whatsappApi.getRatingsAPI, params);
// 	};
// }
// export function editListingURL(params) {
// 	return async (dispatch) => {
// 		//call Thunk Action
// 		await ActionUtility.thunkDispatch(dispatch, types.WHATSAPP_EDIT_LISTING, whatsappApi.editListingURL, params);
// 	};
// }

export function whatsappLangToggle(params) {
	return async (dispatch) => {
		await ActionUtility.normalDispatch(dispatch, types.WHATSAPP_LANG_TOGGLE, params);
	};
}

export function whatsappLangReset(params) {
	return async (dispatch) => {
		await ActionUtility.normalDispatch(dispatch, types.WHATSAPP_LANG_RESET, params);
	};
}

export const getLocData = async (params) => {
	return await whatsappApi.getLocData(params);
};
export const fetchLiveData = async (params) => {
	return await whatsappApi.fetchLiveData(params);
};
export const checkLiveContract = async (params) => {
	return await whatsappApi.checkLiveContract(params);
};
export const getShadowTabData = async (params) => {
	return await whatsappApi.getShadowTabData(params);
};
export const getPopCatsNdActiveCamps = async (params) => {
	return await whatsappApi.getPopCatsNdActiveCamps(params);
};
export const getWhatsappMsg = async (params) => {
	return await whatsappApi.getWhatsappMsg(params);
};

export const getRatingsAPI = async (params) => {
	return await whatsappApi.getRatingsAPI(params);
};
export const editListingURL = async (params) => {
	return await whatsappApi.editListingURL(params);
};

export const getMinimumBudget = async (params) => {
	let res = await whatsappApi.getMinimumBudget(params);
	return res.data;
};

export const getExistingCats = async (params) => {
	return await whatsappApi.getExistingCats(params);
};

export const getGstLink = async (params) => {
	return await whatsappApi.getGstLink(params);
};

export const getECSBouncePromoData = async (params) => {
	return await whatsappApi.getECSBouncePromoData(params);
};

export const sendProductLink = async (params) => {
	return await whatsappApi.sendProductLink(params);
};

export const getProductLinkNew = async (params) => {
	return await whatsappApi.getProductLinkNew(params);
};

export const getProductLink = async (params) => {
	return await whatsappApi.getProductLink(params);
};

export const getEvoucherLink = async (params) => {
	return await whatsappApi.getEvoucherLink(params);
};

export const getdigicatonlyemailCo = async (params) => {
	return await whatsappApi.getdigicatonlyemailCo(params);
};

export const getimagePathWhatsapp = async (params) => {
	return await whatsappApi.getimagePathWhatsapp(params);
};

export const getWhatsappShortURL = async (params) => {
	return await whatsappApi.getWhatsappShortURL(params);
};

export const getdigicatonlyemailContent = async (params) => {
	return await whatsappApi.getdigicatonlyemailContent(params);
};

export const insertWhatsapp = async (params) => {
	return await whatsappApi.insertWhatsapp(params);
};

export const insertWhatsappData = async (params) => {
	return await whatsappApi.insertWhatsappData(params);
};

export const sendingemailsms = async (params) => {
	return await whatsappApi.senddigiemailsms(params);
};
export const senddigiwhatsapp = async (params) => {
	return await whatsappApi.senddigiwhatsapp(params);
};
export const insertWhatsappSendMsg = async (params) => {
	return await whatsappApi.insertWhatsappSendMsg(params);
};
export const sendOfficialWhatsapp = async (params) => {
	return await whatsappApi.sendOfficialWhatsapp(params);
};
export const insertOnboardingValidation = async (params) => {
	return await whatsappApi.insertOnboardingValidation(params);
};

export const checkWebsiteLive = async (params) => {
	return await whatsappApi.checkWebsiteLive(params);
};
export const getBToCUrlLink = async (params) => {
	return await whatsappApi.getBToCUrlLink(params);
};
export const chkJdMartCatType = async (params) => {
	return await whatsappApi.chkJdMartCatType(params);
};
export const catalogueKycUrl = async (params) => {
	return await whatsappApi.catalogueKycUrl(params);
};
export const sendCombinedMsg = async (params) => {
	return await whatsappApi.sendCombinedMsg(params);
};

export const sendLogSmsEmail = async (params) => {
	return await whatsappApi.sendLogSmsEmail(params);
};

export const sendOnlyWaMsg = async (params) => {
	return await whatsappApi.sendOnlyWaMsg(params);
};
