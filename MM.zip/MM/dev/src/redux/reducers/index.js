import { combineReducers } from "redux";
import jd_store from "./userReducer";
import whatsappReducer from "./whatsappReducer";

const rootReducer = combineReducers({
	jd_store,
	whatsappReducer,
});
export default rootReducer;
