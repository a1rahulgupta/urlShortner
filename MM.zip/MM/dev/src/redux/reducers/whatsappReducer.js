import * as types from "../actions/actionTypes";
import initialState from "./initialState";

const whatsappReducer = (state = initialState.whatsappMsg, action) => {
	// eslint-disable-next-line default-case
	switch (action.type) {
		// case types.WHATSAPP_GET_LOC_DATA:
		// 	return {
		// 		...state,
		// 		error: state.error,
		// 		getLocData: action.payload.data || {},
		// 		component_success: null,
		// 		component_error: null,
		// 	};
		// case types.WHATSAPP_FETCH_LIVE_DATA:
		// 	return {
		// 		...state,
		// 		error: state.error,
		// 		fetchLiveData: action.payload.data || {},
		// 		component_success: null,
		// 		component_error: null,
		// 	};
		// case types.WHATSAPP_CHECK_LIVE_DATA:
		// 	return {
		// 		...state,
		// 		error: state.error,
		// 		checkLiveContract: action.payload.data || {},
		// 		component_success: null,
		// 		component_error: null,
		// 	};
		// case types.WHATSAPP_GET_SHADOW_TAB_DATA:
		// 	return {
		// 		...state,
		// 		error: state.error,
		// 		getShadowTabData: action.payload.data || {},
		// 		component_success: null,
		// 		component_error: null,
		// 	};
		// case types.WHATSAPP_GET_POP_CAT_AND_ACTIVE_CAMPS:
		// 	return {
		// 		...state,
		// 		error: state.error,
		// 		getPopCatNdActiveCamps: action.payload.data || {},
		// 		component_success: null,
		// 		component_error: null,
		// 	};
		// case types.WHATSAPP_JD_APP_DOWNLOAD_STATUS:
		// 	return {
		// 		...state,
		// 		error: state.error,
		// 		JDAppDownloadStatus: action.payload.data || {},
		// 		component_success: null,
		// 		component_error: null,
		// 	};
		// case types.WHATSAPP_RATING:
		// 	return {
		// 		...state,
		// 		error: state.error,
		// 		getRating: action.payload || {},
		// 		component_success: null,
		// 		component_error: null,
		// 	};
		// case types.WHATSAPP_EDIT_LISTING:
		// 	return {
		// 		...state,
		// 		error: state.error,
		// 		editListing: action.payload.data || {},
		// 		component_success: null,
		// 		component_error: null,
		// 	};

		// case types.WHATSAPP_GET_WHATSAPP_MSG:
		// 	return {
		// 		...state,
		// 		error: state.error,
		// 		getWhatsappMsg: action.payload.data || {},
		// 		component_success: null,
		// 		component_error: null,
		// 	};

		case types.WHATSAPP_LANG_TOGGLE:
			//console.log(state);
			return {
				...state,
				rdx_whatsappLangToggle: !state.rdx_whatsappLangToggle,
				rdx_whatsappLangage: action.payload.data || "English",
			};
		case types.WHATSAPP_LANG_RESET:
			//console.log(state);
			return {
				...state,
				rdx_whatsappLangToggle: false,
				rdx_whatsappLangage: "English",
			};
		default:
			return state;
	}
	return state;
};
export default whatsappReducer;
