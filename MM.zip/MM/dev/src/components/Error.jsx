import React, { Fragment } from "react";

const Error = props => {
  let errorMsg = typeof props.errMsg !== "undefined" ? props.errMsg : "";
  return (
    <Fragment>
      <div className="subheader">
        <div className="mngcampgntitle">
          <div className="campgnsubtext font14">
            Error - Unauthorised or Invalid data
          </div>
          <div className="campgnsubtext font12">{errorMsg}</div>
        </div>
      </div>
    </Fragment>
  );
};

export default Error;
