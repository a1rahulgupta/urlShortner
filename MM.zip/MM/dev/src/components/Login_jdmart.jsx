import React, { Fragment, Component } from "react";
import { Redirect } from "react-router-dom";
import { ComponentLoader, ContentLoader } from "./common/ComponentLoader";

import Error from "./Error";

import GenioApi from "./../redux/api/GenioApi";
const genioApi = new GenioApi();

class Login extends Component {
  constructor(props) {
    super(props);
    localStorage.setItem("pptAuth", 0);
    localStorage.setItem("pptWebsiteImg", "");
    this.state = {
      isAuthenticated: 0,
      errMsg: "",
      flow_type: "",
      parentid: "",
    };
  }

  async componentDidMount() {
    let qsArr = this.props.location.search.split("&ppt_back_url=");
    let token = qsArr[0].replace("?token=", "");
    let ppt_back_url = qsArr[1];
    localStorage.setItem("ppt_back_url", decodeURIComponent(ppt_back_url));

    if (token != "") {
      let res = await genioApi.verifyData({ token });
      if (res.errorCode == 0) {
        localStorage.setItem("pptAuth", 1);
        localStorage.setItem("datacity", res.data.dataCity);
        localStorage.setItem("empcode", res.data.empcode);
        localStorage.setItem("parentid", res.data.parentId);
        localStorage.setItem("Module", 'ME');
        localStorage.setItem("user_type", 'ME');
        this.setState({ isAuthenticated: 1, flow_type: res.data.flow_type, parentid : res.data.parentId }, () => {
          this.redirectToJdMartSales();
        });
      } else {
        this.setState({ errMsg: res.errorStatus });
      }
    } else {
      this.setState({ errMsg: "Token missing" });
    }
  }

  redirectToJdMartSales(){
    //window.location.href = (parseInt(this.state.isAuthenticated) == 1 && flow_type == 'sales_preparation') ? ("/sales-preparation/add-gst-pan/"+parentid) : ("/presentation/business-presentation/"+parentid);
    let pathname ="#";

    if(parseInt(this.state.isAuthenticated)){
      if(this.state.flow_type == 'sales_preparation'){
        pathname = "https://sales.genio.in/sales_jdmart/#/sales-preparation/add-gst-pan/"+this.state.parentid;
      } else{
        pathname = "https://sales.genio.in/sales_jdmart/#/presentation/business-presentation/"+this.state.parentid;
      }
    } else{
      this.setState({
        errMsg: "You are not Auntenticated"
      });
    }

    window.location.href = pathname;
  }

  render() {
    let { isAuthenticated, errMsg, flow_type, parentid } = this.state;

    return <ComponentLoader LoaderName="Loader" />;
  }
}


export default Login;
