import React, { Component } from "react";
import { connect } from "react-redux";
import ErrorPage from "./common/ErrorPage.jsx";
import SearchBar from "./common/SearchBar.jsx";
import { ComponentLoader, ContentLoader } from "./common/ComponentLoader";

class Dashboard extends Component {
	constructor(props) {
		super(props);
		this.state = {
			DashboardLoader: true,
			hasError: false,
		};
	}

	componentDidMount() {
		this.setState({ DashboardLoader: false });
	}
	static getDerivedStateFromError(error) {
		// Update state so the next render will show the fallback UI.
		return { hasError: true };
	}
	searchBarHandler = () => {
		this.props.history.push("/search-business");
	};

	render() {
		if (this.state.hasError) {
			// You can render any custom fallback UI
			let errorMsg = "Something went wrong.";
			console.log(errorMsg);
			return <h1>Something went wrong.</h1>;
		}
		console.log(this.props);

		const { error, loading, user } = this.props;
		var component_error = this.props.component_error || null;
		if (error) {
			return <ErrorPage error={error} />;
		}
		if (loading || this.state.DashboardLoader == true) {
			return <ComponentLoader LoaderName="DashboardLoader" />;
		}

		var empcode = user.empcode || "";
		var that = this;
		const { history } = this.props;
		return (
			<>
				{!this.props.lhsMenu && (
					<SearchBar
						pageName="dashboard"
						placeholder="Search Business"
						value=""
						handleOnchange={() => {
							return true;
						}}
						handleClearInput={this.handleClearInput}
						searchBarHandler={() => this.searchBarHandler()}
						suggestions={[]}
						recentFlag={this.state.recentFlag}
						recentSearch={this.state.recentSearch}
					/>
				)}
			</>
		);
	}
}

function mapStateToProps(state) {
	return {
		empcode: state.jd_store.empcode,
		user: state.jd_store.user,
		lhsMenu: state.jd_store.lhsMenu,
	};
}

const mapDispatchToProps = (dispatch) => {
	return {
		// dispatching plain actions
	};
};
export default connect(mapStateToProps, {})(Dashboard);
