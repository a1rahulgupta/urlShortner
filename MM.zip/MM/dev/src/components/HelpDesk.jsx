import React, { Component } from "react";
import { connect } from "react-redux";
import ErrorPage from "./common/ErrorPage.jsx";
import { ComponentLoader, ContentLoader } from "./common/ComponentLoader";
import Minipopup from "./common/Minipopup";
import { submitHelpDeskQuery } from "../redux/actions/userActions";
import Dropzone from "react-dropzone";
const Compress = require("compress.js");

class HelpDesk extends Component {
	constructor(props) {
		super(props);
		this.state = {
			showMinipopup: false,
			miniPopupTitle: "",
			miniPopupText: "",
			Loader: true,
			hasError: false,
			helpdeskForm: {
				email: this.props.user.email_id,
				mobile: this.props.user.mobile_num,
				city: this.props.datacity,
				subject: "",
				message: "",
				photo: "",
			},
			filePath: "",
			bufferImage: "",
			filePreviewBills: [],
			filePathBills: [],
			doctypeBills: [],
			nameBills: [],
			curr: 0,
		};
	}
	popupHandleOk = () => {
		this.setState({ showMinipopup: false, miniPopupText: "" });
	};
	componentDidMount() {
		this.setState({ Loader: false });
	}
	static getDerivedStateFromError(error) {
		return { hasError: true };
	}
	formChangetHandler = (e, type) => {
		let newVals = this.state.helpdeskForm;
		switch (type) {
			case "email":
				newVals.email = e.target.value;
				this.setState({ helpdeskForm: newVals });
				break;
			case "city":
				newVals["city"] = e.target.value;
				this.setState({ helpdeskForm: newVals });
				break;
			case "mobile":
				newVals.mobile = e.target.value;
				this.setState({ helpdeskForm: newVals });
				break;
			case "subject":
				newVals.subject = e.target.value;
				this.setState({ helpdeskForm: newVals });
				break;
			case "message":
				newVals.message = e.target.value;
				this.setState({ helpdeskForm: newVals });
				break;
		}
	};
	formSubmitHandler() {
		try {
			if (!this.state.helpdeskForm.subject) {
				this.setState({ miniPopupTitle: "Error", miniPopupText: "Please enter subject", showMinipopup: true });
				return false;
			} else if (!this.state.helpdeskForm.message) {
				this.setState({ miniPopupTitle: "Error", miniPopupText: "Please enter message", showMinipopup: true });
				return false;
			}

			const { submitHelpDeskQuery, datacity } = { ...this.props };
			const { doctypeBills, filePathBills, nameBills } = this.state;
			let thisObj = this;
			let user = this.props.user;
			let queryObject = this.state.helpdeskForm;
			let params = {
				server_city: datacity,
				data_city: datacity ? datacity.toUpperCase() : "",
				parentid: "",
				companyname: "",
				empcode: EMPCODE,
				empname: user.empname,
				mobile: user.mobile_num,
				city: user.city,
				emailid: user.email_id,
				subject: queryObject.subject,
				message: queryObject.message,
				helpData: {
					email: user.email_id,
					contact: user.mobile_num,
					city: user.city,
					subject: queryObject.subject,
					helpMsg: queryObject.message,
					attachment: {
						filePath: filePathBills[0] ? filePathBills[0] : [],
						ploc: [],
						name: nameBills,
						type: doctypeBills,
					},
				},
				jwt_ucode: EMPCODE,
			};

			this.setState({ Loader: true });
			var that = this;
			Promise.all([submitHelpDeskQuery(params)]).then(() => {
				this.setState({ Loader: false, filePreviewBills: [] });
				let msg = this.props.successMsg;
				if (msg) {
					this.setState({ miniPopupTitle: "Success", miniPopupText: "Mail has been sent to Genio helpdesk successfully", showMinipopup: true }, () => {
						that.setState({
							hasError: false,
							helpdeskForm: {
								subject: "",
								message: "",
								photo: "",
							},
							filePath: "",
							bufferImage: "",
							filePreviewBills: [],
							filePathBills: [],
							doctypeBills: [],
							nameBills: [],
							curr: 0,
						});
					});
				}
			});
		} catch (e) {
			console.log("catch error:", e);
		}
	}

	handleOnDrop = (files) => {
		let that = this;
		let curr = this.state.curr;
		for (var keyImg in files) {
			if (files[keyImg]["type"] == "image/jpeg" || files[keyImg]["type"] == "image/png" || files[keyImg]["type"] == "image/pdf") {
				if (files.hasOwnProperty(keyImg) && files[keyImg] instanceof File) {
					let file = files[keyImg];
					var filename = file["name"];
					let reader = new FileReader();

					file = Object.assign(file, {
						preview: URL.createObjectURL(file),
					});

					reader.onload = function(e) {
						var newFile = that.state.filePreviewBills;
						if (newFile[curr] == undefined) {
							newFile[curr] = [];
						}
						newFile[curr].push(e.target.result);

						that.setState({
							filePreviewBills: newFile,
						});
					};
					reader.readAsDataURL(file);

					var newFilePath = that.state.filePathBills;
					if (newFilePath[curr] == undefined) {
						newFilePath[curr] = [];
					}
					newFilePath[curr].push(file);

					var doctypetripTemp = that.state.doctypeBills;
					if (doctypetripTemp[curr] == undefined) {
						doctypetripTemp[curr] = [];
					}
					doctypetripTemp[curr].push(files[keyImg]["type"]);

					var nameTemp = that.state.nameBills;
					if (nameTemp[curr] == undefined) {
						nameTemp[curr] = [];
					}
					nameTemp[curr].push(filename);

					that.setState({
						filePathBills: newFilePath,
						doctypeBills: doctypetripTemp,
						nameBills: nameTemp,
					});
				}
			} else {
				that.setState({
					openAlert: true,
					openPinPoint: false,
					msgAlert: "Please upload only JPEG/JPG/png/pdf Images",
				});
				return false;
			}
		}
	};

	removePhoto = (idx) => {
		let curr = this.state.curr;
		const newFile = this.state.filePreviewBills[curr];
		const newFilePath = this.state.filePathBills[curr];
		const newDoctypetrip = this.state.doctypeBills[curr];
		const newNametrip = this.state.nameBills[curr];

		newFile.splice(idx, 1);
		newFilePath.splice(idx, 1);
		newDoctypetrip.splice(idx, 1);
		newNametrip.splice(idx, 1);

		var filePreviewBills = this.state.filePreviewBills;
		filePreviewBills[curr] = newFile;

		var filePathBills = this.state.filePathBills;
		filePathBills[curr] = newFilePath;

		var DoctypeBills = this.state.doctypeBills;
		DoctypeBills[curr] = newDoctypetrip;

		var nameBills = this.state.nameBills;
		nameBills[curr] = newNametrip;

		this.setState({
			filePathBills: filePathBills,
			filePreviewBills: filePreviewBills,
			doctypeBills: DoctypeBills,
			nameBills: nameBills,
		});
	};

	render() {
		if (this.state.Loader == true) {
			return <ComponentLoader LoaderName="ComponentLoader" />;
		}
		let curr = this.state.curr;
		if (this.state.hasError) {
			// You can render any custom fallback UI
			return <h1>Something went wrong.</h1>;
		}

		const { error, loading, user } = this.props;
		var component_error = this.props.component_error || null;
		if (error) {
			return <ErrorPage error={error} />;
		}
		if (loading || this.state.Loader == true) {
			return <ComponentLoader LoaderName="Loader" />;
		}

		var empcode = user.empcode || "";
		var that = this;
		const { history, datacity } = this.props;
		return (
			<div>
				<div className="divider" />
				{this.state.showMinipopup && <Minipopup title={this.state.miniPopupTitle} text={this.state.miniPopupText} handleOk={this.popupHandleOk} okPopup={true} />}
				<div className="helpdeskwpr">
					<div className="helpdesktitle font14">For all your genio/geniolite related queries</div>
					<div className="helpdeskform">
						<div className="group">
							<input className="inputMaterial font16 inputdisabled" type="text" onChange={(e) => this.formChangetHandler(e, "email")} value={this.props.user.email_id} />
							<span className="bar" />
							<label className="label-wrap font16">Email (From)</label>
						</div>
						<div className="group">
							<input className="inputMaterial font16 inputdisabled" type="text" onChange={(e) => this.formChangetHandler(e, "mobile")} value={this.props.user.mobile_num} />
							<span className="bar" />
							<label className="label-wrap font16">Contact Number</label>
						</div>
						<div className="group">
							<input className="inputMaterial font16 inputdisabled" type="text" onChange={(e) => this.formChangetHandler(e, "city")} value={this.props.datacity} />
							<span className="bar" />
							<label className="label-wrap font16">City Name</label>
						</div>
						<div className="group">
							<input className="inputMaterial font16" type="text" onChange={(e) => this.formChangetHandler(e, "subject")} />
							<span className="bar" />
							<label className="label-wrap font16">Enter Subject of your message</label>
						</div>
						<div className="group">
							<input className="inputMaterial font16" type="text" onChange={(e) => this.formChangetHandler(e, "message")} />
							<span className="bar" />
							<label className="label-wrap font16">Message</label>
						</div>
						<div className="sendattachwpr">
							{this.state.filePreviewBills != undefined && this.state.filePreviewBills[curr] != undefined && this.state.filePreviewBills[curr].length != 0 && (
								<div className="uploader-class inputbox ">
									{
										<div className="file-preview">
											{this.state.filePreviewBills[curr].map((value, i) => (
												<div key={i} className="photoprnt">
													<span className="pic">
														<img src={this.state.filePreviewBills[curr][i]} alt="" title="" />
														<div />
													</span>
													<div className="close_icon" onClick={(e) => this.removePhoto(i)} aria-hidden="true" />
												</div>
											))}
										</div>
									}
								</div>
							)}
							<Dropzone maxFiles={2} onDrop={(acceptedFiles) => this.handleOnDrop(acceptedFiles)} multiple accept="image/jpeg, image/png">
								{({ getRootProps, getInputProps }) => (
									<div className="addphotowpr" {...getRootProps()}>
										<input {...getInputProps()} />
										<div>
											<div className="attachphoto">
												<label htmlFor="UploadPanCard" className="upload-lable addphoto">
													<span className="gno_camera" />
													<span className="addphototext font10">Add Photo</span>
												</label>
											</div>
										</div>
									</div>
								)}
							</Dropzone>
						</div>
					</div>
				</div>
				<div className="submitwpr" onClick={() => this.formSubmitHandler()}>
					<button className="font16">Submit</button>
				</div>
			</div>
		);
	}
}

function mapStateToProps(state) {
	return {
		empcode: state.jd_store.empcode,
		user: state.jd_store.user,
		helpdeskForm: state.jd_store.helpdeskForm,
		datacity: state.jd_store.datacity,
		successMsg: state.jd_store.component_success,
	};
}

const mapDispatchToProps = (dispatch) => {
	return {
		submitHelpDeskQuery: (params) => dispatch(submitHelpDeskQuery(params)),
	};
};
export default connect(mapStateToProps, mapDispatchToProps)(HelpDesk);
