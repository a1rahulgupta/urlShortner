import React, { Component } from "react";
import { connect } from "react-redux";
import ErrorPage from "./common/ErrorPage.jsx";
import SearchBar from "./common/SearchBar.jsx";
import { ComponentLoader, ContentLoader } from "./common/ComponentLoader";
import { ucWords, getServerCity } from "./../utilities/helperFunctions";

import { applyFilters, applyOnbFilters, clearOnbFilters } from "./../redux/actions/userActions";

class Filter extends Component {
	constructor(props) {
		super(props);
		this.state = {
			FilterLoader: true,
			hasError: false,
			filter_campaign: [],
			filter_type: [],
			filter_source: [],
			filter_disposition: [],
			filter_digicat: [],
			filter_onbType: [],
		};
	}

	componentDidMount() {
		this.setState({ FilterLoader: false });
	}
	static getDerivedStateFromError(error) {
		// Update state so the next render will show the fallback UI.
		return { hasError: true };
	}
	filterByCampaign = (type) => {
		if (this.props.OnboardingEmp == 0) var filterArray = this.state.filter_campaign;
		else var filterArray = this.state.filter_disposition;
		if (filterArray.includes(type)) {
			let index = filterArray.indexOf(type);
			filterArray.splice(index, 1);
		} else {
			filterArray.push(type);
		}
		if (this.props.OnboardingEmp == 0) this.setState({ filter_campaign: filterArray });
		else this.setState({ filter_disposition: filterArray });
	};
	filterByType = (type) => {
		if (this.props.OnboardingEmp == 0) var filterArray = this.state.filter_type;
		else var filterArray = this.state.filter_digicat;
		if (filterArray.includes(type)) {
			let index = filterArray.indexOf(type);
			filterArray.splice(index, 1);
		} else {
			filterArray.push(type);
		}
		if (this.props.OnboardingEmp == 0) this.setState({ filter_type: filterArray });
		else this.setState({ filter_digicat: filterArray });
	};
	filterBySource = (type) => {
		if (this.props.OnboardingEmp == 0) var filterArray = this.state.filter_source;
		else var filterArray = this.state.filter_onbType;
		if (filterArray.includes(type)) {
			let index = filterArray.indexOf(type);
			filterArray.splice(index, 1);
		} else {
			filterArray.push(type);
		}
		if (this.props.OnboardingEmp == 0) this.setState({ filter_source: filterArray });
		else this.setState({ filter_onbType: filterArray });
	};

	clearFilters = () => {
		const { OnboardingEmp } = this.props;
		if (OnboardingEmp == 1) {
			Promise.all([this.props.clearOnbFilters({ filter_disposition: [], filter_digicat: [], filter_onbType: [] })]).then(() => {
				this.setState({ filter_disposition: [], filter_digicat: [], filter_onbType: [] });
			});
		} else {
			Promise.all([this.props.applyFilters({ filter_campaign: [], filter_type: [], filter_source: [] })]).then(() => {
				this.setState({ filter_campaign: [], filter_type: [], filter_source: [] });
			});
		}
	};
	applyFilters = () => {
		const { datacity, typeofemployee, OnboardingEmp } = this.props;
		const servercity = getServerCity(datacity);
		var pageNumber = this.state.pageShow;
		let getfreshonb = null;
		let pathname = this.props.location.pathname;
		if (pathname == "/fresh-onboarding") {
			getfreshonb = 1;
		} else if (pathname == "/renewal-onboarding") {
			getfreshonb = 2;
		}
		if (OnboardingEmp == 1) {
			this.props.applyOnbFilters({ filter_disposition: this.state.filter_disposition, filter_digicat: this.state.filter_digicat, filter_onbType: this.state.filter_onbType });
		} else {
			this.props.applyFilters({ filter_campaign: this.state.filter_campaign, filter_type: this.state.filter_type, filter_source: this.state.filter_source });
		}
	};

	render() {
		if (this.state.hasError) {
			// You can render any custom fallback UI
			return <h1>Something went wrong.</h1>;
		}
		console.log(this.props);

		const { error, loading, user, location, history, OnboardingEmp, onBoardingDataWithFilter } = this.props;
		console.log("onbFilterData", this.props);
		var component_error = this.props.component_error || null;
		// if (error) {
		// 	return <ErrorPage error={error} />;
		// }
		// if (loading || this.state.FilterLoader == true) {
		// 	return <ComponentLoader LoaderName="FilterLoader" />;
		// }

		var empcode = user.empcode || "";
		var that = this;
		var campaignList = [
			"Fixed Position",
			"Supreme Campaigns",
			"National Listing",
			"Jd Verified",
			"Jd Trusted",
			"JDRR Certificate",
			"Banner National Listing",
			"Booster",
			"Rotaional Web banner",
			"Rotaional Mobile banner",
			"Your Own Website",
			"Android App",
			"Iphone App",
			"SMS Promo",
		];
		var filterTypes = ["mask", "freez"];
		var filterSources = { "Join Free": "joinfree_campaign", "Ad Programs": "adprograms_campaign", "Web Edit Listing": "webeditlistin_campaign", "IRO Deferred": "irodeferred_campaign", "searches SMS": "searchesSmsEm_campaign" };
		var dispositionList = [
			"All",
			"Call Back",
			"Verified",
			"Not interested to verify",
			"Need details via email",
			"No response",
			"Invalid Number",
			"Already verified - Inbound",
			"Ringing",
			"Switched Off",
			"Number Busy",
			"Not Reachable",
			"Call Drop",
			"Partially Verified",
		];
		var DigicatTagging = [
			"All",
			"Client Will Upload By Self",
			"Asked For Call Back For DC",
			"Presentaion Given",
			"Product Uploaded",
			"Uploaded By Agent, Approval Pending",
			"Digital Catalogue Approved",
			"NON B2B Contract",
			"Digital Catalogue Already Approved",
			"Not interested for DC",
		];
		var OnbFiltertype = ["All", "B2B", "Non B2B", "ECS", "Non ECS", "Disposed", "Not Disposed", "B2B product", "B2B service", "B2C product", "B2C service"];
		return (
			<div>
				<div className="divider" />
				{OnboardingEmp == 1 && (
					<div className="filterwpr">
						<div className="filterprnt">
							<div className="filtertitle font13">By Disposition</div>
							<ul className="fltrtabs font12">
								{Object.values(dispositionList).map((dispo, key) => {
									let isActive = this.state.filter_disposition.includes(dispo) ? "active" : "";
									return (
										<li className={isActive} key={"disposition_" + key} onClick={() => this.filterByCampaign(dispo)}>
											{dispo}
										</li>
									);
								})}
							</ul>
						</div>
						<div className="filterprnt">
							<div className="filtertitle font13">By Digi Cat Tagging</div>
							<ul className="fltrtabs font12">
								{Object.values(DigicatTagging).map((tag, key) => {
									let isActive = this.state.filter_digicat.includes(tag) ? "active" : "";
									return (
										<li className={isActive} key={"tag_" + key} onClick={() => this.filterByType(tag)}>
											{ucWords(tag)}
										</li>
									);
								})}
							</ul>
						</div>
						<div className="filterprnt">
							<div className="filtertitle font13">By Type</div>
							<ul className="fltrtabs font12">
								{Object.keys(OnbFiltertype).map((onbfilter, index) => {
									var type = OnbFiltertype[onbfilter];
									let isActive = this.state.filter_onbType.includes(type) ? "active" : "";
									return (
										<li className={isActive} key={"onbtype_" + index} onClick={() => this.filterBySource(type)}>
											{ucWords(type)}
										</li>
									);
								})}
							</ul>
						</div>
					</div>
				)}
				{OnboardingEmp == 0 && (
					<div className="filterwpr">
						<div className="filterprnt">
							<div className="filtertitle font13">Campaigns</div>
							<ul className="fltrtabs font12">
								{Object.values(campaignList).map((campaign, key) => {
									let isActive = this.state.filter_campaign.includes(campaign) ? "active" : "";
									return (
										<li className={isActive} key={"campaign_" + key} onClick={() => this.filterByCampaign(campaign)}>
											{campaign}
										</li>
									);
								})}
							</ul>
						</div>
						<div className="filterprnt">
							<div className="filtertitle font13">By Type</div>
							<ul className="fltrtabs font12">
								{Object.values(filterTypes).map((filterType, key) => {
									let isActive = this.state.filter_type.includes(filterType) ? "active" : "";
									return (
										<li className={isActive} key={"filtertype_" + key} onClick={() => this.filterByType(filterType)}>
											{ucWords(filterType)}
										</li>
									);
								})}
							</ul>
						</div>
						{location.pathname == "/assignments/hot-data" && (
							<div className="filterprnt">
								<div className="filtertitle font13">By Source</div>
								<ul className="fltrtabs font12">
									{Object.keys(filterSources).map((filterSourceKey, index) => {
										let filterSourceValue = filterSources[filterSourceKey];
										let isActive = this.state.filter_source.includes(filterSourceValue) ? "active" : "";
										return (
											<li className={isActive} key={"source_" + filterSourceValue} onClick={() => this.filterBySource(filterSourceValue)}>
												{ucWords(filterSourceKey)}
											</li>
										);
									})}
								</ul>
							</div>
						)}
					</div>
				)}
				<div className="fltrbtnswpr" style={{ bottom: "55px" }}>
					<button className="fltrbtns font16" onClick={() => this.clearFilters()}>
						Clear
					</button>
					<button className="fltrbtns font16 fltrbluebtns" onClick={() => this.applyFilters()}>
						Apply
					</button>
				</div>
				{onBoardingDataWithFilter && onBoardingDataWithFilter.length > 0 && (
					// <></>
					<ContractModal
						history={this.props.history}
						expand={this.state.expand}
						contractData={onBoardingDataWithFilter}
						handleLoadMore={this.handleLoadMore}
						totalContractData={this.props.fetchOnboardingTotal}
						loadMore={this.state.loadMore}
						pageAction={pageAction}
						onPageChange={this.onPageChange}
						pageShow={this.state.pageShow}
					/>
				)}
			</div>
		);
	}
}

function mapStateToProps(state) {
	return {
		empcode: state.jd_store.empcode,
		user: state.jd_store.user,
		OnboardingEmp: state.jd_store.OnboardingEmp,
		contract_filter: state.jd_store.contract_filter,
		onb_filter: state.jd_store.onb_filter,
		clearOnbdata: state.jd_store.clearOnbdata,
	};
}

const mapDispatchToProps = (dispatch) => {
	return {
		// dispatching plain actions
		applyFilters: (params) => dispatch(applyFilters(params)),
		applyOnbFilters: (params) => dispatch(applyOnbFilters(params)),
		clearOnbFilters: (params) => dispatch(clearOnbFilters(params)),
	};
};
export default connect(mapStateToProps, mapDispatchToProps)(Filter);
