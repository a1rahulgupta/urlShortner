import React from "react";
import { Facebook, List } from "react-content-loader";

//import { Modal, Alert, ButtonGroup, Button } from "react-bootstrap";
export const ComponentLoader = (props) => {
	//var loaderGif = "../myjd/dev/src/media/images/loader.gif";
	return (
		<div
			style={{
				float: "left",
				width: "100%",
				height: "calc(100vh - 100px)",
				display: "flex",
				alignItems: "center",
				justifyContent: "center",
				borderTop: "1px solid #e4eaef",
			}}
		>
			{/* {props.LoaderName == "DashboardLoader" && ( */}

			{/* <div className="page-loader" id="showbox">
				<div className="reverse-spinner" />
				<div id="showboxDelay" className="loader-text" />
			</div> */}
			<div className="loaderwpr">
				<div className="loader"></div>
			</div>

			{/* )} */}
		</div>
	);
};

export const ContractLoader = (props) => {
	//var loaderGif = "../myjd/dev/src/media/images/loader.gif";
	return (
		<div
			style={{
				float: "left",
				width: "100%",
				height: "calc(100vh - 300px)",
				display: "flex",
				alignItems: "center",
				justifyContent: "center",
				borderTop: "1px solid #e4eaef",
			}}
		>
			{/* {props.LoaderName == "DashboardLoader" && ( */}

			{/* <div className="page-loader" id="showbox">
				<div className="reverse-spinner" />
				<div id="showboxDelay" className="loader-text" />
			</div> */}
			<div className="loaderwpr">
				<div className="loader"></div>
			</div>

			{/* )} */}
		</div>
	);
};

export const ContentLoader = (props) => {
	//var loaderGif = "../myjd/dev/src/media/images/loader.gif";
	return (
		<div>
			<div className="appintlistwpr" key="1" style={{ minHeight: "100px" }}>
				<div className="appintlistprnt">
					<Facebook />
					<List />
				</div>
			</div>
			<div className="appintlistwpr" key="2" style={{ minHeight: "100px" }}>
				<div className="appintlistprnt">
					<Facebook />
					<List />
				</div>
			</div>
			<div className="appintlistwpr" key="3" style={{ minHeight: "100px" }}>
				<div className="appintlistprnt">
					<Facebook />
					<List />
				</div>
			</div>
			<div className="appintlistwpr" key="4" style={{ minHeight: "100px" }}>
				<div className="appintlistprnt">
					<Facebook />
					<List />
				</div>
			</div>
			<div className="appintlistwpr" key="5" style={{ minHeight: "100px" }}>
				<div className="appintlistprnt">
					<Facebook />
					<List />
				</div>
			</div>
		</div>
	);
};
