import React, { Component, PureComponent } from "react";
import { Route, Switch, withRouter } from "react-router-dom";
import { Link } from "react-router";
import { connect } from "react-redux";
import LHSMenu from "./LHSMenu.jsx";
import Filter from "./../Filter.jsx";
import { LHSToggle, filterToggle, closePaymentPopUp, closeMustReadInstructions, getreportmessengerData, insertmessengerdata } from "./../../redux/actions/userActions";
import { whatsappLangToggle } from "./../../redux/actions/whatsappActions";
import { fetchMenuLinks, getMenuLinks } from "./../../redux/actions/userActions";
import { getLocalStorage } from "../../utilities/localStorage.js";
import Minipopup from "./Minipopup";

class Header extends Component {
	constructor(props) {
		super(props);
		this.state = {
			menuState: {},
			activeMenu: "",
			activePageName: "Home",
			showMinipopup: false,
			miniPopupTitle: "",
			miniPopupText: "",
			okPopup: true,
			handleSubmit: "",
			handleCancel: "",
			handleOK: "",
		};
	}
	componentDidMount() {
		const { fetchMenuLinks, datacity, user, typeofemployee, section, OnboardingEmp } = this.props;
		var typeOfemployee = typeofemployee;
		if (OnboardingEmp == 1) typeOfemployee = "onb";
		// Promise.all([fetchMenuLinks({ empcode: localStorage.getItem('empcode'), data_city: "Mumbai", user_type: typeOfemployee, level: "1" })]).then(() => {
		// 	let menuArry = {};
		// 	let homeTitle = ["/new-business", "/allocations", "/todays-allocations"];
		// 	let pathname = this.props.location.pathname;
		// 	let menuState = this.props.menuLinks.filter((item) => {
		// 		if (item.has_child != undefined && item.has_child == 1) {
		// 			let parentid = item.menu_id;
		// 			if (homeTitle.includes(pathname)) {
		// 				this.setState({ ...this.state, activePageName: "Home" });
		// 			}
		// 			if ("/" + item.menu_link == pathname) {
		// 				this.setState({ ...this.state, activePageName: item.menu_name });
		// 			}
		// 			// Promise.all([
		// 			// 	getMenuLinks({
		// 			// 		empcode: localStorage.getItem('empcode'),
					// 		data_city: "Mumbai",
		// 			// 		user_type: typeOfemployee,
		// 			// 		parent_menu_id: parentid,
		// 			// 	}),
		// 			// ]).then((res) => {
		// 			// 	res[0].filter((child) => {
		// 			// 		if ("/assignments/" + child.menu_link == pathname) {
		// 			// 			this.setState({ ...this.state, activePageName: child.menu_name });
		// 			// 		}
		// 			// 	});
		// 			// });
		// 		}
		// 		return (menuArry[item.menu_id] = item);
		// 	});
		// 	if ("/deals-pending" == pathname) {
		// 		this.setState({ ...this.state, activePageName: "Deals Pending" }, () => {
		// 			console.log("deals-pending", "###", this.state.activePageName);
		// 		});
		// 	}
		// 	this.setState({ ...this.state, menuState: menuArry });
		// });
	}
	componentDidUpdate(prevProps, prevState) {
		if (prevProps !== this.props) {
			const {} = { ...this.props };
			let homeTitle = ["/new-business", "/allocations", "/todays-allocations"];
			let pathname = this.props.location.pathname;
			if (prevProps.location.pathname !== pathname && this.state.menuState) {
				Object.values(this.state.menuState).map((item, key) => {
					if (homeTitle.includes(pathname)) {
						this.setState({ ...this.state, activePageName: "Home" });
					}
					if ("/" + item.menu_link == pathname) {
						this.setState({ ...this.state, activePageName: item.menu_name });
						return item;
					}
					if (item.has_child != undefined && item.has_child == 1 && item.child) {
						item.child.filter((child) => {
							if ("/assignments/" + child.menu_link == pathname) {
								this.setState({ ...this.state, activePageName: child.menu_name });
							}
						});
					}
				});
				if ("/deals-pending" == pathname) {
					this.setState({ ...this.state, activePageName: "Deals Pending" });
				}
			}
		}
	}
	handleRightHeaderClick = () => {
		if (this.props.location.pathname.split("/").includes("jd-partner-disposition")) {
			if (this.props.mustReadOpen == true) {
				this.props.closeMustReadInstructions();
			}
			this.props.history.goBack();
			return;
		}

		if (this.props.location.pathname.split("/").includes("complaint-history") || this.props.location.pathname.split("/").includes("payment-details") || this.props.location.pathname.split("/").includes("call-the-client")) {
			this.props.history.goBack();
		}

		if (this.props.lhsMenu) {
			this.toggleMenu();
		} else {
			if (this.props.fetchpaymentsummary.errorCode != undefined) {
				this.props.closePaymentPopUp();
			} else if (this.props.mustReadOpen == true) {
				this.props.closeMustReadInstructions();
			} else {
				this.props.filterToggle();
			}
		}
		// clarification required on design
	};
	handleLeftHeaderClick = () => {
		if(this.props.location.pathname.includes('sales-preparation/add-gst-pan')){
			window.location.href = localStorage.getItem('ppt_back_url');
			return false;
		} else if(this.props.location.pathname.includes('presentation/categorypreview') && localStorage.getItem('parentid')){
			this.props.history.push('/sales-preparation/online-presence-keywords/' + localStorage.getItem('parentid'));
			return false;
		} else if(this.props.location.pathname.includes('sales-preparation/online-presence-keywords/') && localStorage.getItem('parentid')){
			this.props.history.push('/sales-preparation/online-presence/' + localStorage.getItem('parentid'));
			return false;
		} else if(this.props.location.pathname.includes('sales-preparation/online-presence/') && localStorage.getItem('parentid')){
			this.props.history.push('/sales-preparation/add-gstn-category/gst/' + localStorage.getItem('parentid'));
			return false;
		} else if(this.props.location.pathname.includes('sales-preparation/add-gstn-category/') && localStorage.getItem('parentid')){
			this.props.history.push('/sales-preparation/add-gst-pan/' + localStorage.getItem('parentid'));
			return false;
		}


		if (this.props.props.backUrl != "") {
			let { pathname } = this.props.location;
			let salesHome = localStorage.getItem("salesHome") || "";
			if (salesHome != "") {
				this.props.history.goBack();
				return;
			}
			// if(pathname && pathname.split("/").includes("add-gst-pan")){
				// this.props.history.push(localStorage.getItem(""));
			// }else{
			// 	this.props.history.goBack();
			// }
			if (pathname && pathname.split("/").includes("whatsapp-msg") && localStorage.getItem("currLink")) {
				// this.props.history.push(this.props.props.backUrl.replace("#/new-business", "/new-business"));
				this.props.history.push(localStorage.getItem("currLink"));
			} else {
				this.props.history.goBack();
			}
		} else {
			this.toggleMenu();
		}
	};
	toggleMenu = () => {
		this.props.LHSToggle();
	};
	handleToggleWhatsappLang = () => {
		this.props.whatsappLangToggle({ data: "English" });
	};
	menuItemsClick = (parentid) => {
		const { fetchMenuLinks, datacity, user, typeofemployee, section, OnboardingEmp } = this.props;
		var typeOfemployee = typeofemployee;
		if (OnboardingEmp == 1) typeOfemployee = "onb";
		// Promise.all([
		// 	fetchMenuLinks({
		// 		empcode: localStorage.getItem('empcode'),
		// 		data_city: "Mumbai",
		// 		user_type: typeOfemployee,
		// 		parent_menu_id: parentid,
		// 	}),
		// ]).then((res) => {
		// 	let menuArry = this.state.menuState;
		// 	if (menuArry[parentid]["child"] && menuArry[parentid]["child"].length > 0) {
		// 		menuArry[parentid]["child"] = [];
		// 	} else {
		// 		menuArry[parentid]["child"] = [];
		// 		let menuState = this.props.menuLinks.filter((item) => {
		// 			menuArry[parentid]["child"][item.sequence] = [];
		// 			menuArry[parentid]["child"][item.sequence] = item;
		// 			// menuArry[item.parent_menu_id] = { ...menuArry[item.parent_menu_id], child: {} };
		// 			// menuArry[item.parent_menu_id].child = Object.assign({}, menuArry[item.parent_menu_id].child, {
		// 			// 	[item.menu_id]: item
		// 			// });

		// 			//return (menuArry[item.parent_menu_id]["child"][item.menu_id] = item);
		// 		});
		// 	}

		// 	this.setState({ ...this.state, menuState: menuArry, activeMenu: parentid });
		// });

		// let name = param.split(" ").join("");
		// let currState = this.state.menuState[name];
		// let newState = { ...this.state.menuState };
		// newState[name] = !currState;
		// this.setState({ menuState: newState });
	};
	dateformat = (dateData) => {
		if (dateData == null || dateData == "") {
			var newDate = "";
		} else {
			var date = new Date(dateData.replace(/-/g, "/"));
			var newDate = date.toDateString();
		}
		return newDate;
	};
	timeformat = (dateData) => {
		if (dateData == null || dateData == "") {
			var strTime = "";
		} else {
			var date = new Date(dateData.replace(/-/g, "/"));
			var hours = date.getHours();
			var minutes = date.getMinutes();
			var ampm = hours >= 12 ? "PM" : "AM";
			hours = hours % 12;
			hours = hours ? hours : 12; // the hour '0' should be '12'
			minutes = minutes < 10 ? "0" + minutes : minutes;
			var strTime = hours + ":" + minutes + " " + ampm;
		}
		return strTime;
	};
	handleRedirect = async (menu_item) => {
		let menu_link = menu_item.parent_menu_id == 3 ? "/assignments/" + menu_item.menu_link : "/" + menu_item.menu_link;
		//console.log(menu_link);
		this.setState(
			{
				...this.state,
				activePageName: menu_item.menu_name,
			},
			() => {
				document.body.scrollTop = 0;
				document.documentElement.scrollTop = 0;
			},
		);
		if (menu_link == "/reportmessenger") {
			let response = await getreportmessengerData({ empcode: localStorage.getItem('empcode'), data_city: getLocalStorage("datacity") });
			if (response != undefined && response.data != undefined && response.data.errorCode == 0) {
				this.setState({
					showMinOkpop: true,
					miniPopupTitle: "Report Messenger Blocked",
					miniPopupText: "Request sent on " + this.dateformat(response.data.data["0"]["insertedon"]) + " at " + this.timeformat(response.data.data["0"]["insertedon"]),
					okPopup: true,
					handleOK: this.handleOK,
				});
			} else {
				this.setState({
					showMinipopup: true,
					miniPopupTitle: "Report Messenger Blocked",
					miniPopupText: "Are you sure you wish to report messenger blocked?",
					okPopup: false,
					handleSubmit: this.handleSubmit,
					handleCancel: this.handleCancel,
				});
			}
		} else {
			this.props.history.push(menu_link);
		}
	};

	handleSubmit = async () => {
		try {
			const { user } = this.props;
			if (user.type_of_employee === "") var user_type = user.section;
			else var user_type = user.type_of_employee;
			let response = await insertmessengerdata({ empcode: localStorage.getItem('empcode'), data_city: getLocalStorage("datacity"), empname: user.empname, user_type: user_type, mobile: user.mobile_num });
			if (response != undefined && response != "" && response != null) {
				this.setState({
					showMinOkpop: true,
					miniPopupTitle: "Report Messenger Blocked",
					miniPopupText: response.data.errorMsg,
					okPopup: true,
					handleOK: this.handleOK,
				});
			}
		} catch (e) {
			console.log(e);
		}
	};

	handleCancel = () => {
		this.setState({
			showMinipopup: false,
			miniPopupTitle: "",
			miniPopupText: "",
			okPopup: true,
			handleSubmit: "",
			handleCancel: "",
		});
	};
	handleOK = () => {
		this.setState({ showMinOkpop: false, miniPopupText: "", okPopup: false, handleOK: "", showMinipopup: false, miniPopupTitle: "", miniPopupText: "", okPopup: true, handleSubmit: "", handleCancel: "" });
	};

	handleHasFilter = () => {
		return this.props.hasFilter ? (
			<div className="dtablecell genio-header-right">
				<span className="iconbox gno_fltricon" />
			</div>
		) : null;
	};
	render() {
		const { pageName, hasFilter, hasMenu } = this.props.props;
		const { lhsMenu, filter, user, menuLinks, datacity, history, location, fetchpaymentsummary, mustReadOpen, OnboardingEmp } = this.props;

		let headerTitle = pageName == "Home" || pageName == "Deal Closed" ? this.state.activePageName : pageName;
		if (pageName == "Choose Message Template") {
			headerTitle = getLocalStorage("whatsap_compname");
		}
		//let headerTitle = this.state.activePageName || pageName;
		let rightHeaderIcon = hasFilter ? "gno_fltricon" : "";
		let leftHeaderIcon = hasMenu ? "gno_burgericon" : "backicon";
		const { pathname } = location;

		if (filter) {
			headerTitle = "Filter";
			rightHeaderIcon = "gno_closeicn";
			leftHeaderIcon = "";
		}
		// if (fetchpaymentsummary.errorCode != undefined) {
		// 	leftHeaderIcon = "";
		// 	rightHeaderIcon = "gno_closeicn";
		// 	headerTitle = "Payment Details";
		// }
		if (mustReadOpen == true) {
			leftHeaderIcon = "";
			rightHeaderIcon = "gno_closeicn";
			if (pathname.split("/").includes("my-points")) {
				headerTitle = "Must Read Instruction";
			}
			if (this.props.location.state && this.props.location.state.complainid && pathname.split("/").includes("complaint-history")) {
				headerTitle = `History of Complaint id ${this.props.location.state.complainid}`;
			}
		}
		if (pathname && pathname.split("/").includes("dispose-appointment")) {
			leftHeaderIcon = "";
		}

		return (
			<div></div>
					// <header className="borderbottom mb-10 headerfix">
					// 	<div className="dtbl header ">
					// 		{leftHeaderIcon && (
					// 			<div className="dcell leftblock" onClick={() => this.handleLeftHeaderClick()}>
					// 				<span className={`iconbox ${leftHeaderIcon}`}></span>
					// 			</div>
					// 		)}
					// 		{mustReadOpen == true && <div className="dcell leftblock"></div>}
					// 		{/* <div className="dcell tcenter color363 font15 fw600">{headerTitle}</div> */}
					// 		<div className="dcell rightblock">&nbsp;</div>
					// 	</div>
					// </header>
		);
	}
}

function mapStateToProps(state, props) {
	return {
		user: state.jd_store.user || "",
		typeofemployee: state.jd_store.typeofemployee || "",
		section: state.jd_store.section || "",
		OnboardingEmp: state.jd_store.OnboardingEmp || 0,
		datacity: state.jd_store.datacity,
		lhsMenu: state.jd_store.lhsMenu || "",
		rdx_whatsappLangage: state.whatsappReducer.rdx_whatsappLangage || false,
		filter: state.jd_store.filter || "",
		menuLinks: state.jd_store.menuLinks || "",
		fetchpaymentsummary: state.jd_store.fetchpaymentsummary || "",
		mustReadOpen: state.jd_store.mustReadOpen || "",
	};
}
function mapDispatchToProps(dispatch) {
	return {
		LHSToggle: (params) => dispatch(LHSToggle()),
		fetchMenuLinks: (params) => dispatch(fetchMenuLinks(params)),
		filterToggle: (params) => dispatch(filterToggle()),
		closePaymentPopUp: (params) => dispatch(closePaymentPopUp()),
		closeMustReadInstructions: (params) => dispatch(closeMustReadInstructions()),
		whatsappLangToggle: (params) => dispatch(whatsappLangToggle(params)),
	};
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Header));
