import React, { Component } from "react";
import { Route, Switch, withRouter, useLocation } from "react-router-dom";
import { ComponentLoader, ContentLoader } from "./ComponentLoader";
import { urlencode, ucWords } from "./../../utilities/helperFunctions";

const DeepLink = () => {
	let query_str = new URLSearchParams(useLocation().search);
	let route_name = query_str.get("name");
	if (route_name != undefined && route_name != null && route_name != "") {
		window.location.href = "geniolite://article/" + urlencode(route_name);
	}
	return <ComponentLoader LoaderName="Loader" />;
};

export default DeepLink;
