import React from "react";

let JdMartStatusPopup = (props) => {
	return (
		<div>
			<div className="overlay"></div>
			<div className="mini_popup">
				<div>
					<div className="title font18 jdappstatus-title">
						Jd Mart Download Status
						<span className="iconbox gno_closeicn" onClick={props.showJdmartStatus}></span>
					</div>

					<div className="jdappstatus-content">
						{props.mobile_str.map((num, key) => {
							let status = props.jd_mart_download_status.hasOwnProperty(num) ? "Yes" : "No";

							return (
								<div key={key}>
									<p className="infosub">Mobile Number {key + 1}</p>
									<p className="infohd">{num}</p>
									<p className="infosub">Download status Date & Time</p>
									{status == "Yes" && (
										<p className="infohd">
											<span className="addfeld">{status}</span> | {props.jd_mart_download_status[num]}
										</p>
									)}
									{status == "No" && (
										<p className="infohd">
											<span className="revrfeld">{status}</span>{" "}
										</p>
									)}
								</div>
							);
						})}
					</div>

					<div className="submitwpr" style={{ width: "100%" }} onClick={props.showJdmartStatus}>
						<button className="font16">OK</button>
					</div>
				</div>
			</div>
		</div>
	);
};

export default JdMartStatusPopup;
