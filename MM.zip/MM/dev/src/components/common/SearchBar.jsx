import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";

const SearchBar = React.memo((props) => {
	const { searchBarHandler, placeholder, value, handleOnchange, clearInput, pageName, suggestions, recentSearch } = props;
	return (
		<>
			<div className="mainsearch">
				<div className="inputouter">
					<input className="inputarea font16 " type="text" placeholder={placeholder} value={value} onChange={handleOnchange} />
					<span className="searchIcon" />
					{value && value.length > 0 && <span className="gno_clear" onClick={clearInput}></span>}
				</div>
			</div>
			{/* {pageName == "searchBusiness" && suggestions != undefined &&  suggestions.length > 0 &&
            <div className="ecssrch_rsltwpr">
            <ul>
            {suggestions.map((val,key)=>
                             <li key ={key} onClick={()=>props.suggestionSelected(val)}>
                                 <div className="srchtitle font15">{val.compname}</div>
                                 <div className="srchtitle_id font12">{val.parentid}</div>
                             </li>
                         )}
                     </ul>
           </div>
             
             
            }
            <div>
                <div className="divider" />
                {pageName == "searchBusiness" &&  recentSearch.length > 0 &&
                    <div className="ecssrch_rsltwpr">
                    <div className=" srchtitle_id font15">Recent Searches</div>
                      <ul>
                         {Object.values(recentSearch).map((recent, index)=> (
                              <li key ={index} onClick={()=>props.suggestionSelected(recent)}>
                                  <div className="srchtitle font15">{recent.compname}</div>
                                  <div className="srchtitle_id font12">{recent.parentid}</div>
                              </li>
                          ))}
                      </ul>
                  </div>
                }
                
            </div> */}
		</>
	);
});

SearchBar.propTypes = {
	pageName: PropTypes.string.isRequired,
	placeholder: PropTypes.string.isRequired,
	value: PropTypes.string,
	handleOnchange: PropTypes.func.isRequired,
};

export default SearchBar;
