import React, { Component } from "react";
import { Link, Route, Switch, withRouter } from "react-router-dom";
import { connect } from "react-redux";
import { urlencode, ucWords, handleGenioLiteRedirect } from "../../utilities/helperFunctions";
//import * as helperFn from "./HelperFunc";

// import { searchBusiness } from "./../redux/actions/userActions";
import CryptoEncryption from "../../utilities/CryptoEncryption";
//nonceValue same as loginToMasterDashboard
var nonceValue = "l45bwsdioHds56lfglstuyuyPlyt23l2m3n";
const cryptoEncryption = new CryptoEncryption();
const enc_empcode = cryptoEncryption.encrypt(JSON.stringify({ empcode: EMPCODE, module: "sales_genio" }), nonceValue);

/**import components */

const LHSMenu = (props) => {
	//console.log(props);
	const { empname, pro_pic_url, type_of_employee, section, OnboardingEmp } = props.user;
	const { menuLinks, datacity, history } = props;
	let menuLinksTemp = [];
	if (menuLinks && Object.values(menuLinks).length > 0) {
		menuLinksTemp = Object.values(menuLinks);
		menuLinksTemp.sort(function(a, b) {
			let dateA = a.sequence;
			let dateB = b.sequence;
			if (dateA < dateB) {
				return -1;
			} else if (dateA > dateB) {
				return 1;
			}
			return 0;
		});
	}
	const { menuState } = props.state;
	let style = { backgroundImage: `url('${pro_pic_url}')` };
	const typeofemployee = type_of_employee ? type_of_employee : "ME";
	const rejectedDocumentsUri = "https://sales.genio.in/genio_lite/#/allocation/documentRejectedDetails";
	const rejectedPhotosUri = "https://sales.genio.in/genio_lite/#/rejectedMandate/";
	const missingGeocodesUri = "https://sales.genio.in/genio_lite/#/allocation/missingGeo";
	const rejectedMandatesUri = "https://sales.genio.in/genio_lite/#/rejectedMandate/";
	const dealClosedContractsUri = "https://sales.genio.in/genio_lite/#/deal-closed-contacts/";
	const applyForClashUri = "https://sales.genio.in/clashApply/#/?q=1";
	const jdPayStatusUri = "https://sales.genio.in/genio_lite/#/jdpay-status";
	const dialMeJdaNumberUri = "https://sales.genio.in/genio_lite/#/DialMeJda";
	const allPaymentDetailsUri = "https://sales.genio.in/genio_lite/#/allocation/recentPayments";
	const onlineTransferGenioLiteUri = "https://sales.genio.in/genio_lite/#/allocation/onlinetransfergeniolite";
	const testCmpUri = "https://sales.genio.in/genio_lite/dev/src/utils/app_test_component.html";
	const talkTimeReportUri = "https://sales.genio.in/genio_lite/#/talktime-report";
	const talktimeDashboardPath = "https://sales.genio.in/sales_genio/Utility/loginToTalktimeDashboard.php?params=" + enc_empcode + "&OPEN_OUTSIDE_APP=1&return_url=" + encodeURIComponent(window.location.href);

	const pathname = props.pathname;
	return (
		<div className="leftmenuwpr">
			<div className="menuprflwpr">
				<div className="menuprfltbl">
					<div className="menuprflcell menuprflpic">
						{!pro_pic_url && <span className="prflimg" />}
						{pro_pic_url && <span className="prflimg" style={{ backgroundImage: 'url("' + pro_pic_url.toLowerCase() + '")' }} />}
					</div>

					<div className="menuprflcell">
						<span className="menuusername font17">{empname}</span>
						<span className="menuuserprfl font11">
							<Link to={"/my-profile"} onClick={props.toggle}>
								View Profile
							</Link>
						</span>
					</div>
					<div className="dtablecell genio-header-right" onClick={() => props.rightClick()}>
						<span className={`iconbox gno_closeicn`}></span>
					</div>
				</div>
			</div>
			<div className="menulistwpr">
				<ul className="menulist">
					<li>
						<span className="menulistcell menulisticon">
							<span className="gno_locationicn" />
						</span>
						<span className="menulistcell font14">{ucWords(datacity)}</span>

						<span className="menulistcell lctnchange font11">
							<Link to="/select-city" onClick={props.toggle}>
								Change
							</Link>
						</span>
					</li>
					<li>
						<Link to={"/todays-allocations"} onClick={props.toggle}>
							<span className="menulistcell menulisticon">
								<span className="gno_homeicon" style={{ width: "20px" }} />
							</span>
							<span className="menulistcell font14">
								<span className="innerlistwpr">Home</span>
							</span>
						</Link>
					</li>
					{/* <li>
						<a href={talktimeDashboardPath} target="_blank">
							<span className="menulistcell menulisticon">
								<span className="gno_dashboard" style={{ width: "20px" }} />
							</span>
							<span className="menulistcell font14">
								<span className="innerlistwpr">My Input Dashboard</span>
							</span>
						</a>
					</li> */}
					{menuLinksTemp &&
						Object.values(menuLinksTemp).map((item, key) => {
							if (item.has_child != undefined && item.has_child == 1) {
								let dispStatus = item.child && item.child.length > 0 ? 1 : 0;
								let extraVals = item.extraVals ? JSON.stringify(item.extraVals) : JSON.stringify("{menu_icon: '.gno_assignmentsicn'}");
								let menu_icon = extraVals
									.replace("{menu_icon:'.", "")
									.replace("'}", "")
									.replace("{menu_icon: '.", "")
									.replace('"', "")
									.replace('"', "");
								return (
									<li key={key} className={dispStatus == 1 ? "active" : ""}>
										{/* {className={dispStatus ? "active" : ""}} */}
										<span className="menulistcell menulisticon">
											<span className={menu_icon} />
										</span>
										<span className="menulistcell font14">
											<span className="innerlistwpr" onClick={() => props.menuItemsClick(item.menu_id)}>
												{item.menu_name} <i className="gno_leftdownarrow" />
											</span>
											{item.child && (
												<span className="listinnermenu">
													<ul>
														{item.child &&
															Object.values(item.child).map((child, k) => {
																{
																	let menu_link = child.parent_menu_id == 3 ? "/assignments/" + child.menu_link : "/" + child.menu_link;
																	let active_menu = pathname == menu_link ? "active" : "";
																	return (
																		<li key={k} className={"font13 " + active_menu} onClick={props.toggle}>
																			{child.menu_link == "talktime-report" && <a onClick={() => handleGenioLiteRedirect("", EMPCODE, datacity, typeofemployee, talkTimeReportUri)}>{child.menu_name}</a>}
																			{child.menu_link == "rejected-documents" && <a onClick={() => handleGenioLiteRedirect("", EMPCODE, datacity, typeofemployee, rejectedDocumentsUri)}>{child.menu_name}</a>}
																			{child.menu_link == "rejected-photos" && <a onClick={() => handleGenioLiteRedirect("", EMPCODE, datacity, typeofemployee, rejectedPhotosUri)}>{child.menu_name}</a>}
																			{child.menu_link == "missing-geocodes" && <a onClick={() => handleGenioLiteRedirect("", EMPCODE, datacity, typeofemployee, missingGeocodesUri)}>{child.menu_name}</a>}
																			{child.menu_link == "rejected-mandates" && <a onClick={() => handleGenioLiteRedirect("", EMPCODE, datacity, typeofemployee, rejectedMandatesUri)}>{child.menu_name}</a>}
																			{child.menu_link == "all-payment-details" && <a onClick={() => handleGenioLiteRedirect("", EMPCODE, datacity, typeofemployee, allPaymentDetailsUri)}>{child.menu_name}</a>}
																			{child.menu_link == "online-transfer-geniolite" && <a onClick={() => handleGenioLiteRedirect("", EMPCODE, datacity, typeofemployee, onlineTransferGenioLiteUri)}>{child.menu_name}</a>}

																			{child.menu_link == "deal-closed-contracts" && <a onClick={() => handleGenioLiteRedirect("", EMPCODE, datacity, typeofemployee, dealClosedContractsUri)}>{child.menu_name}</a>}
																			{child.menu_link == "apply-for-clash" && (
																				<a target="_blank" style={{ color: "#414e5a" }} href={`https://sales.genio.in/clashApply/#/?q=1`}>
																					{child.menu_name}
																				</a>
																			)}
																			{child.menu_link == "jd-pay-status" && <a onClick={() => handleGenioLiteRedirect("", EMPCODE, datacity, typeofemployee, jdPayStatusUri)}>{child.menu_name}</a>}
																			{child.menu_link == "dial-me-jda-number" && <a onClick={() => handleGenioLiteRedirect("", EMPCODE, datacity, typeofemployee, dialMeJdaNumberUri)}>{child.menu_name}</a>}

																			{child.menu_link != "rejected-documents" &&
																				child.menu_link != "talktime-report" &&
																				child.menu_link != "rejected-photos" &&
																				child.menu_link != "missing-geocodes" &&
																				child.menu_link != "rejected-mandates" &&
																				child.menu_link != "deal-closed-contracts" &&
																				child.menu_link != "all-payment-details" &&
																				child.menu_link != "apply-for-clash" &&
																				child.menu_link != "jd-pay-status" &&
																				child.menu_link != "dial-me-jda-number" &&
																				child.menu_link != "online-transfer-geniolite" && (
																					<a
																						//to={menu_link}
																						onClick={() => props.handleRedirect(child)}
																					>
																						{child.menu_name}
																					</a>
																				)}
																		</li>
																	);
																}
															})}
													</ul>
												</span>
											)}
											{/*  */}
										</span>
									</li>
								);
							} else {
								let extraVals = item.extraVals ? JSON.stringify(item.extraVals) : JSON.stringify("{menu_icon: '.gno_assignmentsicn'}");
								let menu_icon = extraVals
									.replace("{menu_icon:'.", "")
									.replace("'}", "")
									.replace("{menu_icon: '.", "")
									.replace('"', "")
									.replace('"', "");
								//window.location.reload(true)
								let active_menu = pathname == "/" + item.menu_link ? "active" : "";
								return (
									<li key={key} onClick={props.toggle} className={active_menu}>
										{item.menu_link && item.menu_name != "Reload" && item.menu_name != "Logout" && (
											<a
												//to={item.menu_link} style={{ color: "#414e5a" }}
												onClick={() => props.handleRedirect(item)}
											>
												<span className="menulistcell menulisticon">
													<span className={menu_icon} />
												</span>
												<span className="menulistcell font14">
													<span className="innerlistwpr">{item.menu_name} </span>
												</span>
											</a>
										)}
										{!item.menu_link && item.menu_name == "My Input Dashboard" && (
											<a href={talktimeDashboardPath} target="_blank">
												<span className="menulistcell menulisticon">
													<span className="gno_dashboard" />
												</span>
												<span className="menulistcell font14">
													<span className="innerlistwpr">{item.menu_name} </span>
												</span>
											</a>
										)}

										{item.menu_link && item.menu_name == "Reload" && (
											<a onClick={() => rn_app_reload()}>
												<span className="menulistcell menulisticon">
													<span className={menu_icon} />
												</span>
												<span className="menulistcell font14">
													<span className="innerlistwpr">{item.menu_name} </span>
												</span>
											</a>
										)}
										{item.menu_link && item.menu_name == "Logout" && (
											<a
												//to={item.menu_link} style={{ color: "#414e5a" }}
												onClick={() => {
													localStorage.clear();
													let TMPEMPCODE = EMPCODE;
													if (isMobile()) {
														clear_app_storage();
													}
													setTimeout(function() {
														window.location.href = "../sales_genio/Utility/logout.php?empcode=" + TMPEMPCODE;
													}, 30);
												}}
											>
												<span className="menulistcell menulisticon">
													<span className={menu_icon} />
												</span>
												<span className="menulistcell font14">
													<span className="innerlistwpr">{item.menu_name} </span>
												</span>
											</a>
										)}
									</li>
								);
							}
						})}
					<li key={"testComp"} onClick={props.toggle}>
						<Link to="/test_cmp">
							<span className="menulistcell menulisticon">
								<span className=".gno_assignmentsicn" />
							</span>
							<span className="menulistcell font14">
								<span className="innerlistwpr">Test Component </span>
							</span>
						</Link>
					</li>
				</ul>
			</div>
		</div>
	);
};

export default LHSMenu;
