import React, { Component } from "react";
import { withRouter, NavLink } from "react-router-dom";
import { connect } from "react-redux";

class ErrorPage extends Component {
	constructor(props) {
		super(props);
		this.state = {
			error: 0,
			commonErr: null,
		};
	}

	handleGoBackClearError = (event) => {
		event.preventDefault();
		rn_app_reload();
	};
	handleGoBackError = (event) => {
		event.preventDefault();
		//location.reload();
		//history.go(0);
		let currLink = localStorage.getItem("currLink").replace("https://sales.genio.in/sales_genio/", "");
		currLink = "https://sales.genio.in/sales_genio/#" + currLink;
		currLink = currLink.replace("//", "/");
		window.location.href = currLink;
	};
	toggleError = (event) => {
		event.preventDefault();
		this.setState({ error: !this.state.error });
	};

	render() {
		var errorMsg = "";
		var errorStack = "";

		if (typeof this.props.error != "undefined" && this.props.error != null) {
			errorMsg = this.props.error.message || "";
			errorStack = this.props.error.stack || "";
		} else if (typeof this.props.errorCustom != "undefined" && this.props.errorCustom != null) {
			errorMsg = this.props.errorCustom.message || "";
			errorStack = "";
		}
		return (
			<div>
				<header className="dtable genio-header" style={{ height: "54px" }}>
					<div className="dtablecell genio-header-left">&nbsp;</div>
					<a className="dtablecell genio-header-center font15" href="https://sales.genio.in/sales_genio/#">
						Home
					</a>
					<div className="dtablecell genio-header-right">&nbps;</div>
				</header>
				<div className="divider"></div>
				<div className="mainwpr">
					<div className="appinttabs appointsticky">
						<ul className="font13">
							<li>
								<a className="act" href="#/allocations" onClick={() => this.toggleError()}>
									Show/Hide Error
								</a>
							</li>
							<li className="axpandallwpr">
								<a className="moredtllink font11" onClick={(e) => this.handleGoBackError(e)} style={{ float: "right", marginLeft: "20px" }}>
									Back
								</a>
								&nbsp;&nbsp;
								<a className="moredtllink font11" onClick={(e) => this.handleGoBackClearError(e)} style={{ float: "right" }}>
									Reload
								</a>
							</li>
						</ul>
					</div>
					<div className="appintlistwpr">
						<div className="appintlistprnt">{errorMsg}</div>
					</div>
					{this.state.error == 1 && (
						<div className="appintlistwpr" style={{ float: "left", wordBreak: "break-word" }}>
							<div className="appintlistprnt">
								<hr style={{ border: "1px solid #efefefef" }} />
								<pre style={{ whiteSpace: "pre-wrap" }}>{errorStack}</pre>
							</div>
						</div>
					)}
				</div>
			</div>
		);
	}
}

function mapStateToProps(state) {
	return {
		error: state.jd_store.error,
		component_error: state.jd_store.component_error,
	};
}
export default withRouter(connect(mapStateToProps, {})(ErrorPage));
