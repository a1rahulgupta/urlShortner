import React, { Component } from "react";

export default class Paginator extends Component {
	constructor(props) {
		super(props);
		this.state = {
			itemsPerPage: 10,
			currentPage: 1,
			pageNumberLimit: 5,
			minPageNumberLimit: 1,
			maxPageNumberLimit: 5,
			showPagination: false,
		};
	}

	componentDidMount() {
		window.onscroll = () => {
			let scrollPoint = window.scrollY + window.innerHeight + 80;
			let totalPageHeight = document.body.scrollHeight;

			if (scrollPoint >= totalPageHeight) {
				this.setState({ showPagination: true });
			} else {
				this.setState({ showPagination: false });
			}
		};

		if (this.props.pageShow) {
			let pageShow = parseInt(this.props.pageShow) + 1;
			let maxPageNumberLimit;
			let minPageNumberLimit;
			let totalPageCount = Math.ceil(this.props.dataLength / this.props.itemsPerPage);
			for (let i = pageShow; i <= totalPageCount; i++) {
				if (i % this.state.pageNumberLimit == 0) {
					maxPageNumberLimit = i;
					break;
				}
			}

			minPageNumberLimit = maxPageNumberLimit - this.props.pageNumberLimit + 1;

			this.setState({
				itemsPerPage: this.props.itemsPerPage,
				currentPage: pageShow,
				pageNumberLimit: this.props.pageNumberLimit,
				minPageNumberLimit,
				maxPageNumberLimit,
			});
		}
	}

	static getDerivedStateFromProps(props, state) {
		if (props.dataOnPage < 4 && props.dataLength > 10) {
			return { showPagination: true };
		}
	}

	handleNextbtn = () => {
		if (this.state.currentPage + 1 <= Math.ceil(this.props.dataLength / this.state.itemsPerPage)) {
			if (this.state.currentPage + 1 > this.state.maxPageNumberLimit) {
				let minPageNumberLimit = this.state.minPageNumberLimit + this.state.pageNumberLimit;
				let maxPageNumberLimit = this.state.maxPageNumberLimit + this.state.pageNumberLimit;
				this.setState({ minPageNumberLimit, maxPageNumberLimit });
			}

			let currentPage = this.state.currentPage + 1;
			this.setState({ currentPage });
			this.props.onPageChange(currentPage);
		}
	};

	handlePrevbtn = () => {
		if (this.state.currentPage > 1) {
			if ((this.state.currentPage - 1) % this.state.pageNumberLimit == 0) {
				let minPageNumberLimit = this.state.minPageNumberLimit - this.state.pageNumberLimit;
				let maxPageNumberLimit = this.state.maxPageNumberLimit - this.state.pageNumberLimit;
				this.setState({ minPageNumberLimit, maxPageNumberLimit });
			}
			let currentPage = this.state.currentPage - 1;
			this.setState({ currentPage });
			this.props.onPageChange(currentPage);
		}
	};

	onPageChange = (currentPage) => {
		this.setState({ currentPage });
		this.props.onPageChange(currentPage);
	};

	render() {
		const pages = [];
		let totalPageCount = Math.ceil(this.props.dataLength / this.state.itemsPerPage);
		for (let i = 1; i <= totalPageCount; i++) {
			pages.push(i);
		}

		if (this.state.showPagination) {
			return (
				<div className="pagination_wpr" id="paginator">
					<div className={`prev_btn font12  ${this.state.currentPage > 1 ? "prev_btn_act" : ""}`} onClick={this.handlePrevbtn}>
						Prev
					</div>
					<div className="pagination_mddle fw600 font12">
						{pages.map((number) => {
							if (number < this.state.maxPageNumberLimit + 1 && number >= this.state.minPageNumberLimit) {
								return (
									<span className={number == this.state.currentPage ? "act" : ""} key={number} id={number} onClick={() => this.onPageChange(number)}>
										{number}
									</span>
								);
							} else {
								return null;
							}
						})}
					</div>
					<div className={`next_btn fw600 font12 ${this.state.currentPage + 1 <= totalPageCount ? "next_btn_act" : ""}`} onClick={this.handleNextbtn}>
						Next
					</div>
				</div>
			);
		} else {
			return <div></div>;
		}
	}
}
