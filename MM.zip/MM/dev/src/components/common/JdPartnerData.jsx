import React, { Component } from "react";
import GenioApi from "../../redux/api/GenioApi";
import Paginator from "./Paginator";
let genioApi = new GenioApi();

export default class JdPartnerData extends Component {
	constructor(props) {
		super(props);
		this.state = {
			call_dropdown: "",
			call_dropdown_html: "",
		};
	}

	onPageChange = (pageNumber) => {
		window.scrollTo(0, 0);
		this.props.onPageChange(pageNumber);
	};

	handleClickToCall = async (jduid) => {
		if (this.state.call_dropdown == jduid) {
			this.setState({ call_dropdown: "", call_dropdown_html: "" });
		} else {
			let params = {
				jwt_ucode: EMPCODE,
				data_city: localStorage.getItem("datacity"),
				module: localStorage.getItem("user_type"),
				jduid: jduid,
			};
			let partnerMobile = await genioApi.getPartnerMobile(params);
			if (partnerMobile.errorCode == 0) {
				let html = (
					<ul className="call_dropdown">
						<li>
							{isMobile() && (
								<a className="clickcalltel" onClick={() => CallSchema("tel:", partnerMobile.data)}>
									{partnerMobile.data}
								</a>
							)}
							{!isMobile() && (
								<a className="clickcalltel" href={"tel:" + partnerMobile.data}>
									{partnerMobile.data}
								</a>
							)}
						</li>
					</ul>
				);

				this.setState({
					call_dropdown: jduid,
					call_dropdown_html: html,
				});
			}
		}
	};

	render() {
		let { contractData, totalContractData, history } = { ...this.props };
		if (contractData && contractData.length > 0) {
			let contractDataHtml = contractData.map((contract, index) => {
				const sr_no = this.props.pageShow > 0 ? this.props.pageShow * 10 + (index + 1) : index + 1;
				let { fullname, dispositionValue, dispositionComment, jduid } = { ...contract };
				return (
					<div className="appintlistwpr" key={index}>
						<div className="appintlistprnt">
							<div className="listhdrtbl">
								<div className="listhdrcell">
									<div className="listhdrname font15">{sr_no + ". " + fullname} </div>
									<div className="listcontact font12">{"+91-XXXXXXXXXX"}</div>
								</div>
								<div className="listhdrcell listrighticon">
									<span className="gno_resultcall" onClick={() => this.handleClickToCall(jduid)}></span>
									{//click to call html
									this.state.call_dropdown == jduid && this.state.call_dropdown_html}
								</div>
							</div>
							<div className="comnlistwpr">
								<div className="comnlisttext font11">Jd Partner Status</div>
								<div className="comnlistprnt font12">{dispositionValue}</div>
							</div>
							<div style={{ display: "inline-block", width: "80%", wordWrap: "break-word" }}>
								<div className="comnlisttext font11">Comments</div>
								<div className="comnlistprnt font12">{dispositionComment}</div>
							</div>
							<div className="moredtlcell settingicnprnt" style={{ display: "inline-block", width: "20%" }}>
								<span className="gno_settingicn" onClick={() => history.push("/jd-partner-disposition/" + jduid)}></span>
							</div>
						</div>
					</div>
				);
			});

			return (
				<>
					{contractDataHtml}
					{contractData && contractData.length > 0 && totalContractData > 10 && <Paginator dataLength={totalContractData} onPageChange={this.onPageChange} itemsPerPage={10} pageShow={this.props.pageShow} pageNumberLimit={5} />}
				</>
			);
		} else {
			return (
				<div className="fnotfoundwpr" style={{ height: "60vh" }}>
					<div className="fnotfoundprnt">
						<img src={PATH_INFO + "/dev/src/media/img/filenotfound.svg"} />
						<div className="fnotfoundtext font18">Data Not Found</div>
					</div>
				</div>
			);
		}
	}
}
