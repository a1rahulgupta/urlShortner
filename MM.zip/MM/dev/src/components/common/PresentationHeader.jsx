import React, { Component } from "react";

class PresentationHeader extends Component {
    constructor(props) {
		super(props);
		this.state = {

        }

        this.handleRightHeaderClick = this.handleRightHeaderClick.bind(this);
        this.handleLeftHeaderClick = this.handleLeftHeaderClick.bind(this);

    }

    componentDidMount() {}

    handleRightHeaderClick = (url) => {
        if(this.props.location.pathname.includes('presentation/why-choose-us2')){
            window.location.href = localStorage.getItem('ppt_back_url');
            return false;
        }
        if(url){
            this.props.history.push(url + '/' + this.props.match.params.parentid);
        }
    }

    handleLeftHeaderClick = (url) => {
        if(this.props.location.pathname.includes('presentation/business-presentation')){
            window.location.href = localStorage.getItem('ppt_back_url');
            return false;
        }

        if(url){
            console.log('URL', url)
            this.props.history.push(url + '/' + this.props.match.params.parentid);
        }
    }

    render() {
        const { pageName, nextUrl, prevUrl } = this.props.headerProps;
        //const pathname = this.props.location.pathname;
        return (
            // <header className="mb-10">
            //     <div className="dtbl header ">
            //         <div className="dcell leftblock" onClick={() => this.handleLeftHeaderClick(prevUrl)}>
            //             <span className="iconbox leftarrow_icon"></span>
            //         </div>
            //         <div className="dcell tcenter color1a1 font20 fw700">{pageName}</div>
            //         <div className="dcell rightblock" onClick={pageName == "Review Selected Keywords" ? this.props.onProceedClick : () => this.handleRightHeaderClick(nextUrl)}>
            //             <span className="iconbox ppt_rightarrow_icon"></span>
            //         </div>
            //     </div>
            // </header>
            <header className="mb-10">
                <div className="pptheader">
                    <div className="headercell headerlftcell" onClick={() => this.handleLeftHeaderClick(prevUrl)}>
                        <span className="lftarw"></span>
                    </div>
                    <div className="headercell">{pageName}</div>
                    <div className="headercell headerrgtcell" onClick={pageName == "Review Selected Keywords" ? this.props.onProceedClick : () => this.handleRightHeaderClick(nextUrl)}>
                        <span className="rgtarw"></span>
                    </div>
                </div>
            </header>
        )
    }
}

export default PresentationHeader;