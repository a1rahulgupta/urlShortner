// import React, { Component } from "react";
// import PropTypes from "prop-types";
// import { connect } from "react-redux";
// import { Link, Redirect } from "react-router-dom";
// import Minipopup from "./Minipopup";
// import JdAppStatusPopup from "./JdAppStatusPopup";
// import JdMartStatusPopup from "./JdMartStatusPopup";
// import { ComponentLoader, ContentLoader, ContractLoader } from "./ComponentLoader";
// import {
// 	getAppointments,
// 	getLastDisposition,
// 	getActionData,
// 	getMobileNumber,
// 	cancelDownsellRequest,
// 	getShadowData,
// 	fetchLiveData,
// 	getWebRedirectToken,
// 	chkContractEditAccess,
// 	JDAppdownloadstatus,
// 	JDMartdownloadstatus,
// 	resendJdpayLink,
// 	deleteJdpayLink,
// 	getPaymentDetails,
// 	closeMustReadInstructions,
// 	setDataCity,
// 	fetchOnboardingLiveStatus,
// 	insertOnboardingData,
// } from "../../redux/actions/userActions";
// import GenioApi from "../../redux/api/GenioApi";
// import { GET_RATINGS, GET_ACTIVE_CAPMS, GET_FULLADDRESS } from "../../redux/actions/actionTypes";
// import { urlencode, handleGenioLiteRedirect } from "../../utilities/helperFunctions";
// import Moment, { calendarFormat } from "moment";
// import { setLocalStorage, getLocalStorage } from "./../../utilities/localStorage";
// import Paginator from "./Paginator";
// import SmsEmail from "../SmsEmail.jsx";
// const genioApi = new GenioApi();

// class ContractModal extends Component {
// 	constructor(props) {
// 		super(props);
// 		this.state = {
// 			loader: false,
// 			DashboardLoader: true,
// 			parentidExpand: [],
// 			loadMoreDetails: [],
// 			showMinipopup: false,
// 			miniPopupTitle: "",
// 			miniPopupText: "",
// 			call_dropdown: "",
// 			call_dropdown_html: "",
// 			jdAppStatusShow: "",
// 			jdMartStatusShow: "",
// 			loadMoreDisable: false,
// 			popup_submitText: "",
// 			popup_cancelText: "",
// 			popup_okPopup: true,
// 			popup_handleSubmit: "",
// 			viewFulladdress: "",
// 		};
// 	}

// 	eventHandler = () => {
// 		this.setState({ viewFulladdress: "" });
// 	};

// 	componentDidMount() {
// 		const { empcode, getLastDisposition, contractData, getActionData, typeofemployee, JDAppdownloadstatus, JDMartdownloadstatus } = { ...this.props };
// 		var currLink = window.location.hash.replace("#", "");
// 		setLocalStorage("currLink", currLink);
// 		document.body.addEventListener("click", this.eventHandler);

// 		if (contractData && contractData.length > 0) {
// 			const parentIdStr = this.getParentIdStr(contractData);
// 			Promise.all([
// 				getLastDisposition({
// 					data_city: this.props.datacity,
// 					empcode: empcode,
// 					paridStr: parentIdStr,
// 					pageShow: 0,
// 				}),
// 				getActionData(
// 					{
// 						data_city: this.props.datacity,
// 						emp_code: empcode,
// 						paridStr: parentIdStr,
// 						module: typeofemployee,
// 						bypass: typeofemployee == "ME" ? "0" : "1",
// 						pageShow: 0,
// 					},
// 					GET_RATINGS,
// 					"/contract/getRatingsAPI",
// 				),
// 				getActionData(
// 					{
// 						data_city: this.props.datacity,
// 						emp_code: empcode,
// 						paridStr: parentIdStr,
// 						module: typeofemployee,
// 						bypass: typeofemployee == "ME" ? "0" : "1",
// 						pageShow: 0,
// 					},
// 					GET_FULLADDRESS,
// 					"/geniosales/getFullAddressDataBeta",
// 				),
// 				getActionData(
// 					{
// 						data_city: this.props.datacity,
// 						emp_code: empcode,
// 						parentid: parentIdStr,
// 						module: typeofemployee,
// 						bypass: typeofemployee == "ME" ? "0" : "1",
// 						pageShow: 0,
// 					},
// 					GET_ACTIVE_CAPMS,
// 					"/campaignInfo/getPopCatsNdActiveCamps",
// 				),
// 			]).then(() => {
// 				JDAppdownloadstatus({
// 					jwt_ucode: EMPCODE,
// 					data_city: this.props.datacity,
// 					module: typeofemployee,
// 					mobileNo: this.props.mobile_str,
// 				});
// 				JDMartdownloadstatus({
// 					jwt_ucode: EMPCODE,
// 					data_city: this.props.datacity,
// 					module: typeofemployee,
// 					mobileNo: this.props.mobile_str,
// 				});
// 				this.setState({ DashboardLoader: false });
// 			});
// 		} else {
// 			this.setState({ DashboardLoader: false });
// 			return false;
// 		}
// 	}

// 	componentWillUnmount() {
// 		document.body.removeEventListener("click", this.eventHandler);
// 	}

// 	componentDidUpdate(prevProps, prevState) {
// 		let prevContracts = this.getParentIdStr(prevProps.contractData);
// 		let nextContracts = this.getParentIdStr(this.props.contractData);
// 		if (prevProps.expand != this.props.expand || prevProps.loadMore != this.props.loadMore) {
// 			if (this.props.contractData && this.props.contractData.length > 0) {
// 				if (this.props.expand) {
// 					let parentidExpand = [];
// 					this.props.contractData.map((contract, index) => parentidExpand.push(contract.parentid));

// 					this.setState({ parentidExpand });
// 				} else {
// 					this.setState({ parentidExpand: [] });
// 				}
// 			}
// 		}
// 		if (prevProps != this.props && prevContracts != nextContracts) {
// 			const { empcode, getLastDisposition, contractData, getActionData, typeofemployee, JDAppdownloadstatus, JDMartdownloadstatus } = { ...this.props };

// 			if (contractData && contractData.length > 0) {
// 				const parentIdStr = this.getParentIdStr(contractData);
// 				Promise.all([
// 					getLastDisposition({
// 						data_city: this.props.datacity,
// 						empcode: empcode,
// 						paridStr: parentIdStr,
// 						pageShow: 1,
// 					}),
// 					getActionData(
// 						{
// 							data_city: this.props.datacity,
// 							emp_code: empcode,
// 							paridStr: parentIdStr,
// 							module: typeofemployee,
// 							bypass: typeofemployee == "TME" ? "1" : "0",
// 							pageShow: 1,
// 						},
// 						GET_RATINGS,
// 						"/contract/getRatingsAPI",
// 					),
// 					getActionData(
// 						{
// 							data_city: this.props.datacity,
// 							emp_code: empcode,
// 							paridStr: parentIdStr,
// 							module: typeofemployee,
// 							bypass: typeofemployee == "ME" ? "0" : "1",
// 							pageShow: 1,
// 						},
// 						GET_FULLADDRESS,
// 						"/geniosales/getFullAddressDataBeta",
// 					),
// 					getActionData(
// 						{
// 							data_city: this.props.datacity,
// 							emp_code: empcode,
// 							parentid: parentIdStr,
// 							module: typeofemployee,
// 							bypass: typeofemployee == "TME" ? "1" : "0",
// 							pageShow: 1,
// 						},
// 						GET_ACTIVE_CAPMS,
// 						"/campaignInfo/getPopCatsNdActiveCamps",
// 					),
// 				]).then(() => {
// 					JDAppdownloadstatus({
// 						jwt_ucode: EMPCODE,
// 						data_city: this.props.datacity,
// 						module: typeofemployee,
// 						mobileNo: this.props.mobile_str,
// 					});
// 					JDMartdownloadstatus({
// 						jwt_ucode: EMPCODE,
// 						data_city: this.props.datacity,
// 						module: typeofemployee,
// 						mobileNo: this.props.mobile_str,
// 					});
// 					this.setState({ DashboardLoader: false });
// 				});
// 			} else {
// 				this.setState({ DashboardLoader: false });
// 				return false;
// 			}
// 		}
// 	}

// 	viewFulladdress = (parentid) => {
// 		this.setState({ viewFulladdress: parentid });
// 	};

// 	getParentIdStr = (contractData) => {
// 		return contractData
// 			.reduce((currentArr, currentData) => {
// 				currentArr.push(currentData["parentid"]);
// 				return currentArr;
// 			}, [])
// 			.join();
// 	};

// 	getDispositionData = (parentid, value) => {
// 		const { lastDispositionData } = { ...this.props };

// 		let finalData = "";
// 		if (lastDispositionData.length > 0) {
// 			lastDispositionData.forEach((data) => {
// 				if (data["contractCode"] == parentid) {
// 					switch (value) {
// 						case "mename":
// 							finalData = data["mename"];
// 							break;
// 						case "me_mobile_number":
// 							finalData = data["me_mobile_number"];
// 							break;
// 						case "tmename":
// 							finalData = data["tmename"];
// 							break;
// 						case "tme_mob_num":
// 							finalData = data["tme_mob_num"];
// 							break;
// 						case "disposition_name":
// 							finalData = data["disposition_name"];
// 							break;
// 						case "diposition_date":
// 							finalData = data["allocationTime"];
// 							break;
// 					}
// 				}
// 			});
// 		}
// 		return finalData;
// 	};

// 	getRatings = (data, parentId) => {
// 		const ratingsObject = {
// 			totalRating: 0,
// 			ratstar: 0.0,
// 			star: [],
// 		};
// 		for (let [key, value] of Object.entries(data)) {
// 			if (key == parentId) {
// 				if (value["rating"] && value["rating"]["totrates"]) {
// 					ratingsObject["totalRating"] = value["rating"]["totrates"];
// 					ratingsObject["ratstar"] = value["rating"]["ratstar"];
// 					ratingsObject["star"] = value["rating"]["result"]["star"];
// 				}
// 				break;
// 			}
// 		}
// 		return ratingsObject;
// 	};

// 	getActiveCampaignDetails = (data, parentId) => {
// 		const activeCampaignDetails = {
// 			businessKeywords: "NA",
// 			activeCampaign: "NA",
// 			active_for: "NA",
// 			expiry_status: "NA",
// 			fin_paid: 0,
// 			paid: 0,
// 			website: "",
// 			activeCampaignMobile: [],
// 		};
// 		for (let [key, value] of Object.entries(data)) {
// 			if (key == parentId) {
// 				activeCampaignDetails["businessKeywords"] = value["catName"];
// 				activeCampaignDetails["activeCampaign"] = value["campaignName"];
// 				activeCampaignDetails["active_for"] = value["active_for"];
// 				activeCampaignDetails["expiry_status"] = value["expiry_status"];
// 				activeCampaignDetails["fin_paid"] = value["fin_paid"];
// 				activeCampaignDetails["paid"] = value["paid"];
// 				activeCampaignDetails["website"] = value["website"] ? value["website"] : "";
// 				activeCampaignDetails["activeCampaignMobile"] = value["mobile"] ? value["mobile"].split(",") : [];
// 				break;
// 			}
// 		}
// 		return activeCampaignDetails;
// 	};

// 	getFullAddressDetail = (data, parentId) => {
// 		const fullAddressDetails = { full_address: "", mobile_str: [] };
// 		for (let [key, value] of Object.entries(data)) {
// 			if (key == parentId) {
// 				fullAddressDetails["full_address"] = value["full_address"];
// 				fullAddressDetails["mobile_str"] = value["mobile"] ? value["mobile"].split(",") : value["mobile"];
// 				fullAddressDetails["pincode"] = value["pincode"];
// 				fullAddressDetails["area"] = value["area"];
// 				break;
// 			}
// 		}
// 		return fullAddressDetails;
// 	};

// 	handleParentIdExpand = (e, parentId, show, instrumentid) => {
// 		e.preventDefault();
// 		let parentidExpand = [...this.state.parentidExpand];
// 		if (show) {
// 			parentidExpand.push(parentId);
// 		} else {
// 			parentidExpand = parentidExpand.filter((element) => element != parentId);
// 		}
// 		this.setState({ parentidExpand });
// 	};

// 	handleClickToCall = (parentid) => {
// 		if (this.state.call_dropdown == "call_" + parentid) {
// 			this.setState({ call_dropdown: "", call_dropdown_html: "" });
// 		} else {
// 			Promise.all([
// 				this.props.getMobileNumber({
// 					jwt_ucode: EMPCODE,
// 					data_city: this.props.datacity,
// 					parentid: parentid,
// 					module: this.props.typeofemployee,
// 					table: "tbl_companymaster_generalinfo_shadow",
// 					blockFlag: 1,
// 				}),
// 			]).then(() => {
// 				let mobArr = this.props.clickCallMobileNumber.split(",");
// 				let html = (
// 					<span id={"call_" + parentid}>
// 						<ul className="call_dropdown">
// 							{isMobile() &&
// 								mobArr.map(function(val, key) {
// 									return (
// 										<li key={"clickcalltell_" + key}>
// 											<a className="clickcalltel" onClick={() => CallSchema("tel:", val)}>
// 												{val}
// 											</a>
// 										</li>
// 									);
// 								})}

// 							{!isMobile() &&
// 								mobArr.map(function(val, key) {
// 									return (
// 										<li key={"clickcalltell_" + key}>
// 											<a className="clickcalltel" href={"tel:" + val}>
// 												{val}
// 											</a>
// 										</li>
// 									);
// 								})}
// 						</ul>
// 					</span>
// 				);
// 				this.setState({ call_dropdown: "call_" + parentid, call_dropdown_html: html });
// 			});
// 		}
// 	};

// 	redirectToWhatsapp = (obj) => {
// 		setLocalStorage("pageShow", this.props.pageShow);
// 		this.props.history.push(obj);
// 	};

// 	handleCpmRedirect = (parentid) => {
// 		let CPM_URL =
// 			"../genio_lite/setEmpRedirect.php?data_city=" +
// 			this.props.datacity +
// 			"&parentid=" +
// 			parentid +
// 			"&user_type=" +
// 			getLocalStorage("user_type") +
// 			"&empcode=" +
// 			EMPCODE +
// 			"&deal=10&new_genio_redirect=" +
// 			urlencode("../genio_cpm/#/" + this.props.datacity + "/" + parentid + "/");
// 		setLocalStorage("pageShow", this.props.pageShow);
// 		localStorage.setItem("lite_url", window.location.href);
// 		window.location.href = CPM_URL;
// 	};

// 	handleEditListingRedirect = async (parentid, city, version) => {
// 		const { user, datacity, typeofemployee, OnboardingEmp } = { ...this.props };
// 		var onboarding_flag = "0";
// 		if (this.props.OnboardingEmp == 1) {
// 			onboarding_flag = "1";
// 			var mainCityArr = ["mumbai", "delhi", "kolkata", "chennai", "bangalore", "hyderabad", "pune", "ahmedabad"];
// 			setLocalStorage("datacity", city.toLowerCase());
// 			var redir_city = mainCityArr.includes(city.toLowerCase()) ? city.toLowerCase() : "remote";
// 			setLocalStorage("redir_datacity", redir_city);
// 			await this.props.setDataCity({ data: city.toLowerCase() });
// 		}
// 		let backUrl = window.location.href;
// 		localStorage.removeItem("new_genio_back");
// 		localStorage.removeItem("new_genio_redirect");
// 		setLocalStorage("pageShow", this.props.pageShow);
// 		let editAccessCheckParams = {
// 			jwt_ucode: EMPCODE,
// 			server_city: this.props.datacity,
// 			user_type: typeofemployee,
// 			onboarding_flag: onboarding_flag,
// 			allocid: null,
// 			contractdata: {
// 				empcode: EMPCODE,
// 				parentid: parentid,
// 				data_city: this.props.datacity,
// 			},
// 		};

// 		Promise.all([this.setState({ loader: true })])
// 			.then(async () => {
// 				let editAccessRes = await chkContractEditAccess(editAccessCheckParams);

// 				if (editAccessRes.errorCode == 0 || editAccessRes.errorCode == 2) {
// 					let params = {
// 						jwt_ucode: EMPCODE,
// 						data_city: this.props.datacity,
// 						server_city: this.props.datacity,
// 						module: typeofemployee,
// 						objData: {
// 							empcode: EMPCODE,
// 							parentid: parentid,
// 							mobile: user.mobile_num,
// 							empname: user.empname,
// 							source: "allocation",
// 							url: backUrl,
// 						},
// 						user_type: typeofemployee,
// 						allocid: getLocalStorage("allocId"),
// 						host: "sales.genio.in",
// 						urlflag: this.props.history.location.pathname,
// 					};
// 					let paramsOnb = {
// 						jwt_ucode: EMPCODE,
// 						data_city: this.props.datacity,
// 						server_city: this.props.datacity,
// 						module: "ME",
// 						empcode: EMPCODE,
// 						parentid: parentid,
// 						user_type: typeofemployee,
// 						version: version,
// 					};
// 					let liveParamsOnb = {
// 						jwt_ucode: EMPCODE,
// 						parentid: parentid,
// 						userid: EMPCODE,
// 						username: user.empname,
// 						server_city: this.props.datacity,
// 						minibform: "0",
// 						user_type: typeofemployee,
// 					};
// 					let insertOnParams = {
// 						jwt_ucode: EMPCODE,
// 						parentid: parentid,
// 						empcode: EMPCODE,
// 						empname: user.empname,
// 						module: "ME",
// 						data_city: this.props.datacity,
// 						user_type: typeofemployee,
// 						emp_phone_number: user.mobile_num,
// 					};
// 					if (this.props.OnboardingEmp == 1) {
// 						// onboarding flow - redirect to old flow.
// 						let response = await fetchOnboardingLiveStatus(paramsOnb);
// 						if (response.data.errorCode == 0) {
// 							let liveResOnb = await fetchLiveData(liveParamsOnb);
// 							if (liveResOnb.error.code == 0) {
// 								let insertOnbres = await insertOnboardingData(insertOnParams);
// 								if (insertOnbres.data.errorCode == 0) {
// 									var redirectionURL = "https://sales.genio.in/genio_lite/#/whatsApp-msg/" + parentid + "/download";
// 									// redirectionURL = "http://project02.hemavathiv.26.blrsoftware.com/GENIO_LITE/genio_lite/#/whatsApp-msg/" + parentid + "/download"; // remove
// 									handleGenioLiteRedirect(parentid, EMPCODE, this.props.datacity, typeofemployee, redirectionURL, "", this.props.pageShow, this.props.OnboardingEmp);
// 								} else {
// 									this.setState({ showMinipopup: true, miniPopupTitle: "Alert", miniPopupText: response.data.errorStatus, loader: false });
// 								}
// 							}
// 						} else {
// 							this.setState({ showMinipopup: true, miniPopupTitle: "Alert", miniPopupText: response.data.errorStatus, loader: false });
// 						}
// 						return false;
// 					}
// 					// onboarding flow ends
// 					if (backUrl.includes("new-business")) {
// 						params.objData.newBusinessFlag = 1;
// 						let response = await getWebRedirectToken(params);
// 						if (response.data.errorCode == 0) {
// 							window.location.href = response.data.link;
// 						} else if (response.data.errorCode == 1 && response.data.tokenRes && response.data.tokenRes.status == 1) {
// 							this.setState({
// 								showMinipopup: true,
// 								miniPopupTitle: "",
// 								miniPopupText: "This business status is closed down in our records. Please contact on dbescalations@justdial.com",
// 								popup_okPopup: true,
// 								popup_submitText: "",
// 								popup_cancelText: "",
// 								popup_handleSubmit: "",
// 								loader: false,
// 								DashboardLoader: false,
// 							});
// 						}
// 					} else {
// 						let shadowParams = {
// 							jwt_ucode: EMPCODE,
// 							data: parentid,
// 							server_city: this.props.datacity,
// 							empcode: EMPCODE,
// 							countrycode: 98,
// 							module: typeofemployee,
// 							parentid: parentid,
// 							getAllData: "",
// 							data_city: this.props.datacity,
// 							allocid: "S",
// 							bypass: typeofemployee == "ME" ? "0" : "1",
// 							user_type: typeofemployee,
// 						};

// 						let shadowRes = await getShadowData(shadowParams);

// 						if (shadowRes != undefined && shadowRes.tableData != undefined && shadowRes.tableData.errorCode == 0) {
// 							params.objData.data = shadowRes;
// 							let response = await getWebRedirectToken(params);
// 							if (response.data.errorCode == 0) {
// 								window.location.href = response.data.link;
// 							} else if (response.data.errorCode == 1 && response.data.tokenRes && response.data.tokenRes.status == 1) {
// 								this.setState({
// 									showMinipopup: true,
// 									miniPopupTitle: "",
// 									miniPopupText: "This business status is closed down in our records. Please contact on dbescalations@justdial.com",
// 									popup_okPopup: true,
// 									popup_submitText: "",
// 									popup_cancelText: "",
// 									popup_handleSubmit: "",
// 									loader: false,
// 									DashboardLoader: false,
// 								});
// 							}
// 						} else {
// 							let liveParams = {
// 								jwt_ucode: EMPCODE,
// 								parentid: parentid,
// 								userid: EMPCODE,
// 								username: user.empname,
// 								server_city: this.props.datacity,
// 								minibform: "0",
// 								user_type: typeofemployee,
// 							};
// 							let liveRes = await fetchLiveData(liveParams);
// 							if (liveRes.error.code == 0) {
// 								let response = await getWebRedirectToken(params);
// 								if (response.data.errorCode == 0) {
// 									window.location.href = response.data.link;
// 								} else if (response.data.errorCode == 1 && response.data.tokenRes && response.data.tokenRes.status == 1) {
// 									this.setState({
// 										showMinipopup: true,
// 										miniPopupTitle: "",
// 										miniPopupText: "This business status is closed down in our records. Please contact on dbescalations@justdial.com",
// 										popup_okPopup: true,
// 										popup_submitText: "",
// 										popup_cancelText: "",
// 										popup_handleSubmit: "",
// 										loader: false,
// 										DashboardLoader: false,
// 									});
// 								}
// 							}
// 						}
// 					}
// 				} else if (editAccessRes.errorCode == 3) {
// 					console.log("freezed popup");
// 					this.setState({ showMinipopup: true, miniPopupTitle: "Alert", miniPopupText: editAccessRes.freezeMsg, loader: false });
// 				} else if (editAccessRes.errorCode == 4) {
// 					console.log("blocked popup");
// 					this.setState({ showMinipopup: true, miniPopupTitle: "Alert", miniPopupText: editAccessRes.errorMsg, loader: false });
// 				} else if (editAccessRes.errorCode == 5) {
// 					console.log("national listing redirect");
// 					console.log(editAccessRes);
// 				} else {
// 					console.log("edit access denied popup");
// 					//todo: reject downsell part is remaining
// 					this.setState({ showMinipopup: true, miniPopupTitle: "Alert", miniPopupText: editAccessRes.errorMsg, loader: false });
// 				}
// 			})
// 			.catch((err) => {
// 				console.log(err);
// 			});
// 	};

// 	popupHandleOk = () => {
// 		this.setState({
// 			showMinipopup: false,
// 			miniPopupTitle: "",
// 			miniPopupText: "",
// 			popup_okPopup: true,
// 			popup_submitText: "",
// 			popup_cancelText: "",
// 			popup_handleSubmit: "",
// 		});
// 	};

// 	comingSoon = () => {
// 		this.setState({ showMinipopup: true, miniPopupTitle: "Alert", miniPopupText: "COMING SOON..." });
// 	};

// 	instructionPopup = (companyname, miniPopupText) => {
// 		this.setState({ showMinipopup: true, miniPopupTitle: companyname, miniPopupText });
// 	};

// 	showJdappStatus = (index) => {
// 		if (index || index == 0) {
// 			this.setState({ jdAppStatusShow: index });
// 		} else {
// 			this.setState({ jdAppStatusShow: "" });
// 		}
// 	};

// 	showJdmartStatus = (index) => {
// 		if (index || index == 0) {
// 			this.setState({ jdMartStatusShow: index });
// 		} else {
// 			this.setState({ jdMartStatusShow: "" });
// 		}
// 	};

// 	dealsPendingDeleteLink = (parentid) => {
// 		const { empcode, deleteJdpayLink, contractData } = { ...this.props };
// 		Promise.all([
// 			deleteJdpayLink({
// 				data_city: this.props.datacity,
// 				empcode: empcode,
// 				parentid: parentid,
// 				server_city: this.props.datacity,
// 			}),
// 		]).then(() => {
// 			this.props.updateDealPending(parentid);
// 			this.setState({
// 				showMinipopup: true,
// 				miniPopupTitle: "Confirmation",
// 				miniPopupText: "JD Pay link deleted",
// 				popup_submitText: "",
// 				popup_cancelText: "",
// 				popup_okPopup: true,
// 				popup_handleSubmit: "",
// 			});
// 		});
// 	};

// 	jdPayLinkDeleteConfirm = (parentid) => {
// 		this.setState({
// 			showMinipopup: true,
// 			miniPopupTitle: "Confirmation",
// 			miniPopupText: "Are you sure you want to delete JD Pay link",
// 			popup_submitText: "Yes",
// 			popup_cancelText: "No",
// 			popup_okPopup: false,
// 			popup_handleSubmit: () => this.dealsPendingDeleteLink(parentid),
// 		});
// 	};

// 	dealsPendingResendLink = async (parentid) => {
// 		const { empcode } = { ...this.props };
// 		let res = await genioApi.resendJdpayLink({
// 			data_city: this.props.datacity,
// 			empcode: empcode,
// 			parentid: parentid,
// 			server_city: this.props.datacity,
// 		});

// 		if (res.jdpaylink_cnt == 1 && res.errorCode == 0) {
// 			this.setState({
// 				showMinipopup: true,
// 				miniPopupTitle: "Confirmation",
// 				miniPopupText: "JD Pay link resent",
// 			});
// 		}
// 		if (res.jdpaylink_cnt == 0 && res.errorCode == 1) {
// 			this.setState({
// 				showMinipopup: true,
// 				miniPopupTitle: "",
// 				miniPopupText: res.errorStatus,
// 			});
// 		}
// 	};

// 	onPageChange = (pageNumber) => {
// 		window.scrollTo(0, 0);
// 		this.props.onPageChange(pageNumber);
// 	};
// 	showPaymentDetails = async (parentid) => {
// 		await this.props.getPaymentDetails({
// 			jwt_ucode: EMPCODE,
// 			parentid,
// 			server_city: this.props.datacity,
// 			empcode: EMPCODE,
// 		});
// 		Promise.all([this.props.closeMustReadInstructions()]);
// 		setLocalStorage("pageShow", this.props.pageShow);
// 		this.props.history.push("/payment-details");
// 	};

// 	render() {
// 		var that = this;
// 		const { contractData, lastDispositionData, empcode, ratings, full_addresses, campaignDetails, datacity, typeofemployee, history, dispositionReportType } = { ...this.props };

// 		let last_app_url = DOMAIN_INFO + "/sales_genio/#" + that.props.history.location.pathname;
// 		last_app_url = last_app_url.replace(/\/\/+/g, "/");
// 		let pageShow = this.props.pageShow;
// 		let currLink = getLocalStorage("currLink");
// 		let { DashboardLoader, parentidExpand, loadMoreDetails, loader } = { ...this.state };

// 		if (loader) {
// 			return <ContractLoader />;
// 		}

// 		if (contractData && contractData.length > 0) {
// 			let contractDataHtml = contractData.map((contract, index) => {
// 				let {
// 					compname,
// 					parentid,
// 					allocationTime,
// 					actionTime,
// 					actual_amt,
// 					proposed_amt,
// 					created_at,
// 					status,
// 					catalogue_url,
// 					companyname,
// 					instrumentAmount,
// 					tdsAmount,
// 					bouncedate,
// 					instrumentid,
// 					instrumentType,
// 					chequeNo,
// 					chequeDate,
// 					bankName,
// 					paymentType,
// 					PaymentPlan,
// 					tmename,
// 					reason,
// 					tme_mob_num,
// 					uptDate,
// 					exec_tmename,
// 					exec_tmecode,
// 					exec_mename,
// 					exec_mecode,
// 					dealcloseddt,
// 					is_jdpay_pending,
// 					status_text,
// 					instruction,
// 					cust_name,
// 					cust_id,
// 					updated_by,
// 					updated_at,
// 					master_transaction_id,
// 					bankClearanceRemarks,
// 					company_address,
// 					whatsapp_sent,
// 					link_sent,
// 					approval,
// 					data_city,
// 					version,
// 				} = { ...contract };

// 				const downsell_module = contract.module;
// 				const campaignvalue = campaignDetails[parentid] ? campaignDetails[parentid].campaignName : "";
// 				if (contractData.module == "bounce") {
// 					let { companyname, instrumentAmount } = { ...contract };
// 					compname = companyname;
// 				}
// 				const { totalRating, ratstar, star } = { ...this.getRatings(ratings, parentid) };
// 				const { full_address, mobile_str, pincode, area } = { ...this.getFullAddressDetail(full_addresses, parentid) };
// 				const { businessKeywords, activeCampaign, active_for, expiry_status, paid, fin_paid, website, activeCampaignMobile } = { ...this.getActiveCampaignDetails(campaignDetails, parentid) };

// 				var jdAppStatus = 0;
// 				if (mobile_str != undefined && that.props.jd_app_download_status != undefined && that.props.jd_app_download_status != "") {
// 					Object.keys(that.props.jd_app_download_status).map((num) => {
// 						if (mobile_str.indexOf(num) > -1) {
// 							jdAppStatus = 1;
// 						}
// 					});
// 				}
// 				var jdMartStatus = 0;
// 				if (mobile_str != undefined && that.props.jd_mart_download_status != undefined && that.props.jd_mart_download_status != "") {
// 					Object.keys(that.props.jd_mart_download_status).map((num) => {
// 						if (mobile_str.indexOf(num) > -1) {
// 							jdMartStatus = 1;
// 						}
// 					});
// 				}

// 				const disposition_name = this.getDispositionData(parentid, "disposition_name");
// 				const diposition_date = this.getDispositionData(parentid, "diposition_date");
// 				const mename = this.getDispositionData(parentid, "mename");

// 				const me_mobile_number = this.getDispositionData(parentid, "me_mobile_number");

// 				const allocatedTo = contract.mename;
// 				const allocatedToEmpcode = contract.empcode;

// 				const uri = "https://sales.genio.in/genio_lite/#/whatsApp-msg/" + parentid + "/product";
// 				const uri_add_on_payment = "https://sales.genio.in/genio_lite/#/addon-payment/" + parentid + "/";
// 				const uri_external_mandate = "https://sales.genio.in/genio_lite/#/mandate-history/" + parentid + "/";
// 				const uri_booster = "https://sales.genio.in/genio_lite/#/booster/" + parentid + "/";
// 				const uri_digicat_keywords = "https://sales.genio.in/genio_lite/#/category/" + parentid + "/";
// 				const sr_no = this.props.pageShow > 0 ? this.props.pageShow * 10 + (index + 1) : index + 1;

// 				var currLink = window.location.hash.replace("#", "");
// 				var city = this.props.datacity;
// 				if (this.props.OnboardingEmp == 1) {
// 					city = data_city;
// 				}

// 				return (
// 					<div className="appintlistwpr" key={parentid + "_" + index}>
// 						{this.state.jdAppStatusShow === index && <JdAppStatusPopup showJdappStatus={this.showJdappStatus} mobile_str={mobile_str} jd_app_download_status={this.props.jd_app_download_status} />}
// 						{this.state.jdMartStatusShow === index && <JdMartStatusPopup showJdmartStatus={this.showJdmartStatus} mobile_str={mobile_str} jd_mart_download_status={this.props.jd_mart_download_status} />}

// 						<div className="appintlistprnt">
// 							<div className="listhdrtbl">
// 								<div className="listhdrcell">
// 									<div className="listhdrname font15" onClick={() => this.handleEditListingRedirect(parentid, city, version)}>
// 										{sr_no + ". " + compname}
// 									</div>
// 									<div className="listcontact font12">{parentid}</div>
// 								</div>
// 								<div className="listhdrcell listrighticon">
// 									{this.props.pageAction == "popular-b2b-data" && paid != undefined && paid != "" && paid == 1 && <span className="gno_jdverifiedicn"></span>}
// 									{this.props.pageAction != "popular-b2b-data" && fin_paid != undefined && fin_paid != "" && fin_paid == 1 && <span className="gno_jdverifiedicn"></span>}
// 									<span className="gno_resultcall" onClick={() => this.handleClickToCall(parentid)}></span>

// 									{//click to call html
// 									this.state.call_dropdown == "call_" + parentid && this.state.call_dropdown_html}
// 								</div>
// 							</div>

// 							{contractData.module != "bounce" && full_address && (
// 								<div className="addresswpr font12" style={{ position: "relative" }}>
// 									<span style={{ color: "#1274c0" }} onClick={() => this.viewFulladdress(parentid)}>{`${area} - ${pincode}`}</span>
// 									{this.state.viewFulladdress == parentid && (
// 										<div className="fade in popover bottom" style={{ display: "block", top: "14px", left: "0", right: "0" }}>
// 											<div className="arrow" style={{ left: "35px" }}></div>
// 											<h3 className="popover-title">Full Address</h3>
// 											<div className="popover-content">
// 												<p>{full_address}</p>
// 											</div>
// 										</div>
// 									)}
// 								</div>
// 							)}
// 							{contractData.module === "bounce" && <div className="addresswpr font12">{company_address}</div>}

// 							{actual_amt && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">Actual Amount</div>
// 									<div className="comnlistprnt font12">{actual_amt ? actual_amt : "NA"}</div>
// 								</div>
// 							)}
// 							{proposed_amt && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">Proposed Amount</div>
// 									<div className="comnlistprnt font12">{proposed_amt ? proposed_amt : "NA"}</div>
// 								</div>
// 							)}
// 							{this.props.reportType != "downsell" && contractData.module != "bounce" && (
// 								<div className="strratingwpr">
// 									<div className="rsltratnw">
// 										<span className="rsltpoint font14">{ratstar ? Number(ratstar).toFixed(1) : Number(0).toFixed(1)}</span>
// 										<span className="rsltstarnw">{star && star.map((starVal, index) => <a key={index} className={`str${starVal}`}></a>)}</span>
// 										<div className="rsltrattxt font12">{totalRating}&nbsp;Ratings</div>
// 									</div>
// 								</div>
// 							)}

// 							<div className="comnlistwpr">
// 								<div className="comnlisttext font11">Business Keywords</div>
// 								<div className="comnlistprnt font12">{businessKeywords ? businessKeywords : "NA"}</div>
// 							</div>

// 							{parentidExpand.includes(parentid) && window.location.href.includes("popular-b2b-data") && (
// 								<>
// 									<div class="moredtlwpr">
// 										<span className="comnlisttext font11">Digi Cat Status</span>
// 									</div>
// 									<div class="moredtlwpr font11">
// 										<div class="moredtltbl">
// 											<div class="moredtlcell ">{whatsapp_sent != undefined && whatsapp_sent == 1 && <span className="gno_checkbtn"></span>}Link Sent</div>
// 											<div class="moredtlcell">{link_sent != undefined && link_sent == 1 && <span className="gno_checkbtn"></span>} Link Clicked</div>
// 											<div class="moredtlcell">
// 												{approval != undefined && approval == 1 && <span className="gno_checkbtn"></span>}
// 												Approved
// 											</div>
// 										</div>
// 									</div>
// 								</>
// 							)}
// 							{instrumentAmount && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr alignlist">
// 									<span className="comnlisttext font11">Instrument Amount :</span>
// 									<span className="comnlistprnt font12 leftalign">{instrumentAmount ? instrumentAmount : "NA"}</span>
// 								</div>
// 							)}

// 							{parentidExpand.includes(parentid) && this.props.reportType != "bounceReport" && this.props.reportType != "downsell" && mobile_str && mobile_str.length > 0 && activeCampaignMobile.length > 0 && (
// 								<div className="jdappdownload font12">
// 									<i className={jdAppStatus == 1 ? "gno_checkbtn" : "gno_closebtn"} /> JD App Download Status
// 									<i className="gno_info" onClick={() => that.showJdappStatus(index)}>
// 										&nbsp;
// 									</i>
// 								</div>
// 							)}

// 							{parentidExpand.includes(parentid) && this.props.reportType != "bounceReport" && this.props.reportType != "downsell" && mobile_str && mobile_str.length > 0 && activeCampaignMobile.length > 0 && (
// 								<div className="jdappdownload font12">
// 									<i className={jdMartStatus == 1 ? "gno_checkbtn" : "gno_closebtn"} /> JD Mart Download Status
// 									<i className="gno_info" onClick={() => that.showJdmartStatus(index)}>
// 										&nbsp;
// 									</i>
// 								</div>
// 							)}

// 							{tdsAmount !== null && tdsAmount !== undefined && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr alignlist">
// 									<div className="comnlisttext font11">TDS Amount :</div>
// 									<div className="comnlistprnt font12 leftalign">{tdsAmount !== null || tdsAmount !== undefined ? tdsAmount : "NA"}</div>
// 								</div>
// 							)}

// 							{bankClearanceRemarks && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr alignlist">
// 									<div className="comnlisttext font11">Bounce Reason :</div>
// 									<div className="comnlistprnt font12 leftalign">{bankClearanceRemarks ? bankClearanceRemarks : "NA"}</div>
// 								</div>
// 							)}

// 							{bouncedate && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr alignlist">
// 									<div className="comnlisttext font11">Bounce Date :</div>
// 									<div className="comnlistprnt font12 leftalign">{bouncedate ? bouncedate : "NA"}</div>
// 								</div>
// 							)}
// 							{instrumentid && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr alignlist">
// 									<div className="comnlisttext font11">Bill desk ID :</div>
// 									<div className="comnlistprnt font12 leftalign">{instrumentid ? instrumentid : "NA"}</div>
// 								</div>
// 							)}

// 							{instrumentid && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr alignlist">
// 									<div className="comnlisttext font11">Instrument Id :</div>
// 									<div className="comnlistprnt font12 leftalign">{instrumentid ? instrumentid : "NA"}</div>
// 								</div>
// 							)}

// 							{instrumentType && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr alignlist">
// 									<div className="comnlisttext font11">Instrument Type :</div>
// 									<div className="comnlistprnt font12 leftalign">{instrumentType ? instrumentType : "NA"}</div>
// 								</div>
// 							)}
// 							{chequeNo && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr alignlist">
// 									<div className="comnlisttext font11">Cheque No :</div>
// 									<div className="comnlistprnt font12 leftalign">{chequeNo ? chequeNo : "NA"}</div>
// 								</div>
// 							)}
// 							{chequeDate && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr alignlist">
// 									<div className="comnlisttext font11">Cheque Date :</div>
// 									<div className="comnlistprnt font12 leftalign">{chequeDate ? chequeDate : "NA"}</div>
// 								</div>
// 							)}
// 							{chequeDate && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr alignlist">
// 									<div className="comnlisttext font11">Deposite Date :</div>
// 									<div className="comnlistprnt font12 leftalign">{chequeDate ? chequeDate : "NA"}</div>
// 								</div>
// 							)}

// 							{bankName && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr alignlist">
// 									<div className="comnlisttext font11">Bank Name :</div>
// 									<div className="comnlistprnt font12 leftalign">{bankName ? bankName : "NA"}</div>
// 								</div>
// 							)}

// 							{paymentType && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr alignlist">
// 									<div className="comnlisttext font11">Payment Type :</div>
// 									<div className="comnlistprnt font12 leftalign">{paymentType ? paymentType : "NA"}</div>
// 								</div>
// 							)}

// 							{PaymentPlan && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr alignlist">
// 									<div className="comnlisttext font11">Payment Plan :</div>
// 									<div className="comnlistprnt font12 leftalign">{PaymentPlan ? PaymentPlan : "NA"}</div>
// 								</div>
// 							)}

// 							{exec_tmename && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr">
// 									<div className="comnlistprnt font12">
// 										TME : {exec_tmename ? exec_tmename : "NA"} | {exec_tmecode ? exec_tmecode : "NA"}
// 									</div>
// 									<div className="comnlistprnt font12">
// 										ME : {exec_mename ? exec_mename : "NA"} | {exec_mecode ? exec_mecode : "NA"}
// 									</div>
// 									<div className="comnlisttext font11">Deal closed date : {dealcloseddt ? dealcloseddt : "NA"}</div>
// 								</div>
// 							)}
// 							{parentidExpand.includes(parentid) && actionTime && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">{dispositionReportType && dispositionReportType == 22 ? "Call Back" : dispositionReportType && dispositionReportType == 24 ? "Follow Up" : "Appointment"} Date & Time</div>
// 									<div className="comnlistprnt font12">
// 										{actionTime ? Moment(actionTime).format("DD MMM YYYY | hh:mm A") : "NA"}
// 										&nbsp;|&nbsp;
// 										{instruction && (
// 											<a className="" style={{ color: "#1274c0" }} onClick={() => this.instructionPopup(compname, instruction)} disabled={instruction == "" ? true : false}>
// 												Instructions
// 											</a>
// 										)}
// 										{(location.hash.substr(2) == "allocations" || location.hash.substr(2) == "todays-allocations") && actionTime && <span className="gno_soundicon" onClick={(e) => this.props.showCallHistory(e, parentid, compname)} />}
// 									</div>
// 								</div>
// 							)}
// 							{window.location.href.includes("disposition-report") && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">Appointment Status</div>
// 									<div className="comnlistprnt font12">
// 										{contract["allocationType"] != undefined && (contract["allocationType"] == "25" || contract["allocationType"] == "99") && contract["cancel_flag"] != undefined && contract["cancel_flag"] == 1 && <span>Cancelled</span>}
// 										{contract["cancel_flag"] != undefined && contract["cancel_flag"] != 1 && <span>NA</span>}
// 									</div>
// 								</div>
// 							)}
// 							{allocatedTo && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">Appointment Allocated To</div>
// 									<div className="comnlistprnt font12">
// 										{allocatedTo ? allocatedTo : "NA"} | {allocatedToEmpcode ? allocatedToEmpcode : "NA"}
// 									</div>
// 								</div>
// 							)}

// 							{allocationTime && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">{dispositionReportType && [22, 24].indexOf(dispositionReportType) == -1 ? "Disposition Date & Time" : "Appointment Allocated on"}</div>
// 									<div className="comnlistprnt font12">{allocationTime ? Moment(allocationTime).format("DD MMM YYYY | hh:mm A") : "NA"}</div>
// 								</div>
// 							)}

// 							{this.props.reportType !== "bounceReport" && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">
// 										Active Campaigns |{" "}
// 										{currLink != "/deals-pending" && currLink != "/deal-closed" && (
// 											<span className="apply-pointer" style={{ color: "#1274c0" }} onClick={() => this.showPaymentDetails(parentid)}>
// 												Payment Details
// 											</span>
// 										)}
// 									</div>
// 									<div className="comnlistprnt font12">{activeCampaign ? activeCampaign : "NA"}</div>
// 								</div>
// 							)}

// 							{this.props.reportType != "bounceReport" && website && this.props.reportType != "downsell" && parentidExpand.includes(parentid) && currLink != "/deals-pending" && currLink != "/deal-closed" && website.length > 0 ? (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">Website URL</div>
// 									{website.split(",").map((websiteUrl, index) => {
// 										return (
// 											<>
// 												{!isMobile() && (
// 													<a href={"http://" + websiteUrl + ""}>
// 														<div className="comnlistprnt font12" style={{ color: "#1274c0" }}>
// 															{websiteUrl}
// 														</div>
// 													</a>
// 												)}
// 												{isMobile() && (
// 													<a href="javascript:void(0)" onClick={() => openInSide("http://" + websiteUrl, "outside_app", last_app_url)}>
// 														<div className="comnlistprnt font12" style={{ color: "#1274c0" }}>
// 															{websiteUrl}
// 														</div>
// 													</a>
// 												)}{" "}
// 											</>
// 										);
// 									})}
// 								</div>
// 							) : (
// 								""
// 							)}
// 							{created_at && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">Requested on </div>
// 									<div className="comnlistprnt font12">{created_at ? Moment(created_at).format("ddd Do MMM YYYY , hh:mm A") : "NA"}</div>
// 								</div>
// 							)}
// 							{cust_name && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">Requested By :</div>
// 									<div className="comnlistprnt font12">
// 										{cust_name} | {cust_id}
// 									</div>
// 								</div>
// 							)}

// 							{status && parentidExpand.includes(parentid) && currLink != "/deals-pending" && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">Status</div>
// 									<div className="comnlistprnt font12" style={{ color: status == 1 ? "#228b22" : status == 2 ? "#ff0000" : "#bdb600" }}>
// 										{status == 1 ? "Approved" : status == 2 ? "Rejected" : status == -1 ? "Pending for Deal Closed" : "Pending"}
// 										{status == -1 && (
// 											<a onClick={() => this.props.pendingStatusCancelRequest(contract.id, parentid, contract.data_city, contract.master_transaction_id, contract.source)} style={{ color: "#1274c0" }}>
// 												{" "}
// 												| Cancel Request
// 											</a>
// 										)}
// 									</div>
// 								</div>
// 							)}

// 							{this.props.reportType == "downsell" && status == 0 && parentidExpand.includes(parentid) && currLink != "/deals-pending" && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">Status</div>
// 									<div className="comnlistprnt font12" style={{ color: status == 1 ? "#228b22" : status == 2 ? "#ff0000" : "#bdb600" }}>
// 										{status == 1 ? "Approved" : status == 2 ? "Rejected" : status == -1 ? "Pending for Deal Closed" : "Pending"}
// 										{!status && (
// 											<a onClick={() => this.props.pendingStatusCancelRequest(contract.id, parentid, contract.data_city, contract.master_transaction_id, contract.source)} style={{ color: "#1274c0" }}>
// 												{" "}
// 												| Cancel Request
// 											</a>
// 										)}
// 									</div>
// 								</div>
// 							)}

// 							{this.props.reportType == "downsell" && status == 2 && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">Reason</div>
// 									<div className="comnlistprnt font12">{reason ? reason : "N/A"}</div>
// 								</div>
// 							)}

// 							{updated_by && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">Updated By :</div>
// 									<div className="comnlistprnt font12">{updated_by}</div>
// 								</div>
// 							)}
// 							{updated_at && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">Updated On :</div>
// 									<div className="comnlistprnt font12">{updated_at}</div>
// 								</div>
// 							)}
// 							{downsell_module && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">Downsell done through : </div>
// 									<div className="comnlistprnt font12">{downsell_module}</div>
// 								</div>
// 							)}
// 							{expiry_status && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">Expiry Status</div>
// 									<div className="comnlistprnt font12">{expiry_status ? expiry_status : "NA"}</div>
// 								</div>
// 							)}

// 							{active_for && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">Active For</div>
// 									<div className="comnlistprnt font12">{active_for ? active_for : "NA"}</div>
// 								</div>
// 							)}

// 							{status_text && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">Status</div>
// 									<div className="comnlistprnt font12">
// 										{status_text ? status_text : "NA"}
// 										{currLink == "/deals-pending" && (
// 											<span className="" onClick={(e) => this.props.fetchPaymentSummary(parentid, master_transaction_id)}>
// 												<a className="moredtllink font11">&nbsp;&nbsp;View Payment Details</a>
// 											</span>
// 										)}
// 									</div>
// 								</div>
// 							)}

// 							{this.props.reportType != "downsell" && currLink != "/disposition-report" && contractData.module != "bounce" && disposition_name && parentidExpand.includes(parentid) && currLink != "/deals-pending" && currLink != "/deal-closed" && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">Last Disposition</div>
// 									<div className="comnlistprnt font12">
// 										{disposition_name ? disposition_name : "NA"} | {diposition_date ? Moment(diposition_date).format("DD MMM YYYY | hh:mm A") : "NA"}
// 									</div>
// 								</div>
// 							)}

// 							{this.props.reportType != "bounceReport" && this.props.reportType != "downsell" && currLink != "/disposition-report" && currLink != "/deals-pending" && currLink != "/deal-closed" && mename && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">Disposed By</div>
// 									<div className="comnlistprnt font12">
// 										{mename ? mename : "NA"}{" "}
// 										{isMobile() && me_mobile_number && (
// 											<a className="gno_resultcallwithcircle" onClick={() => CallSchema("tel:", me_mobile_number)}>
// 												&nbsp;
// 											</a>
// 										)}
// 										{!isMobile() && me_mobile_number && (
// 											<a className="gno_resultcallwithcircle" href={"tel:" + me_mobile_number}>
// 												&nbsp;
// 											</a>
// 										)}
// 									</div>
// 								</div>
// 							)}
// 							{tmename && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">TME Details</div>
// 									<div className="comnlistprnt font12">
// 										{tmename ? tmename : "NA"}{" "}
// 										{isMobile() && tme_mob_num && (
// 											<a className="gno_resultcallwithcircle" onClick={() => CallSchema("tel:", tme_mob_num)}>
// 												&nbsp;
// 											</a>
// 										)}
// 										{!isMobile() && tme_mob_num && (
// 											<a className="gno_resultcallwithcircle" href={"tel:" + tme_mob_num}>
// 												&nbsp;
// 											</a>
// 										)}
// 									</div>
// 								</div>
// 							)}
// 							{currLink == "/allocations" ||
// 								(currLink == "/todays-allocations" && actionTime && parentidExpand.includes(parentid) && (
// 									<div className="comnlistwpr">
// 										<div className="comnlisttext font11">Last Called:</div>
// 										<div className="comnlistprnt font12">{actionTime ? Moment(actionTime).format("DD MMM YYYY | hh:mm A") : "NA"}</div>
// 									</div>
// 								))}
// 							{(currLink == "/deal-closed" || currLink == "/deals-pending") && uptDate && parentidExpand.includes(parentid) && (
// 								<div className="comnlistwpr">
// 									<div className="comnlisttext font11">Deal Date:</div>
// 									<div className="comnlistprnt font12">{uptDate ? Moment(uptDate).format("DD MMM YYYY | hh:mm A") : "NA"}</div>
// 								</div>
// 							)}
// 							{this.props.reportType != "downsell" && parentidExpand.includes(parentid) && contractData.module != "bounce" && (
// 								<div className="extrasrvswpr">
// 									<a onClick={() => handleGenioLiteRedirect(parentid, EMPCODE, datacity, typeofemployee, uri_add_on_payment, "", pageShow)} style={{ color: "#000" }}>
// 										<span className="extrasrvslink">Add on Payment</span>
// 									</a>
// 									{" | "}
// 									<a onClick={() => handleGenioLiteRedirect(parentid, EMPCODE, datacity, typeofemployee, uri_external_mandate, "", pageShow)} style={{ color: "#000" }}>
// 										<span className="extrasrvslink">External Mandate</span>
// 									</a>
// 									{" | "}
// 									<a onClick={() => handleGenioLiteRedirect(parentid, EMPCODE, datacity, typeofemployee, uri_booster, "", pageShow)} style={{ color: "#000" }}>
// 										<span className="extrasrvslink">Booster</span>
// 									</a>
// 									{window.location.href.includes("disposition-report") && (
// 										<div>
// 											<a onClick={(e) => this.props.tmeUserRedirection(parentid, compname, "tracker-report")} style={{ color: "#000" }}>
// 												<span className="extrasrvslink">Tracker Report</span>
// 											</a>
// 											{" | "}
// 											<a onClick={(e) => e.preventDefault()} style={{ color: "#000" }}>
// 												<span className="extrasrvslink">Statement</span>
// 											</a>
// 											{" | "}
// 											<a onClick={(e) => this.props.tmeUserRedirection(parentid, compname, "generateInvoice")} style={{ color: "#000" }}>
// 												<span className="extrasrvslink">Generate Invoice</span>
// 											</a>
// 										</div>
// 									)}
// 									{currLink == "/deals-pending" && is_jdpay_pending == 1 && (
// 										<span>
// 											{" | "}
// 											<a onClick={() => this.jdPayLinkDeleteConfirm(parentid)} style={{ color: "#000" }}>
// 												<span className="extrasrvslink">Delete Jd Pay Link</span>
// 											</a>
// 											{" | "}
// 											<a onClick={() => this.dealsPendingResendLink(parentid)} style={{ color: "#000" }}>
// 												<span className="extrasrvslink">Resend Jd Pay Link</span>
// 											</a>
// 										</span>
// 									)}
// 								</div>
// 							)}

// 							<div className="moredtlwpr">
// 								{!parentidExpand.includes(parentid) && (
// 									<div className="moredtltbl">
// 										<div className="moredtlcell" onClick={(e) => this.handleParentIdExpand(e, parentid, true, instrumentid)}>
// 											<a className="moredtllink font11">More Details</a>
// 										</div>
// 										{["10083404", "10015427", "10100034"].indexOf(EMPCODE) > -1 && (
// 											<div className="moredtlcell">
// 												<a
// 													className="moredtllink font11"
// 													onClick={() => {
// 														setLocalStorage("digiCatSalesGenio", 1);
// 														handleGenioLiteRedirect(parentid, EMPCODE, city, typeofemployee, uri_digicat_keywords, "", pageShow);
// 													}}
// 												>
// 													{" "}
// 													Digi Catalogue{" "}
// 												</a>
// 											</div>
// 										)}
// 										{this.props.reportType !== "bounceReport" && (
// 											<>
// 												{" "}
// 												<div className="moredtlcell settingicnprnt" style={{ width: "110px" }}>
// 													<span className="sociallinkprnt font11">
// 														<a
// 															onClick={() => {
// 																let companyTitle = compname && compname.length > 26 ? compname.substring(0, 26) + "..." : compname;
// 																setLocalStorage("whatsap_compname", companyTitle);
// 																this.redirectToWhatsapp({
// 																	pathname: "/whatsapp-msg/" + parentid + "/jdgodigital",
// 																	state: { parentid: parentid, currLink: currLink, sharevia: "whatsapp" },
// 																});
// 															}}
// 															style={{ color: "#000" }}
// 														>
// 															<span className="gno_whatsupicon"></span>Messenger
// 														</a>
// 													</span>
// 												</div>
// 												<div className="moredtlcell settingicnprnt" style={{ width: "25px" }} onClick={() => this.handleCpmRedirect(parentid)}>
// 													<span className="gno_settingicn"></span>
// 												</div>
// 											</>
// 										)}
// 									</div>
// 								)}
// 								{parentidExpand.includes(parentid) && (
// 									<div className="moredtltbl">
// 										<div className="moredtlcell" onClick={(e) => this.handleParentIdExpand(e, parentid, false, instrumentid)}>
// 											<a className="moredtllink font11">Hide Details</a>
// 										</div>
// 										{["10083404", "10015427"].indexOf(EMPCODE) > -1 && (
// 											<div className="moredtlcell">
// 												<a
// 													className="moredtllink font11"
// 													onClick={() => {
// 														setLocalStorage("digiCatSalesGenio", 1);
// 														handleGenioLiteRedirect(parentid, EMPCODE, city, typeofemployee, uri_digicat_keywords, "", pageShow);
// 													}}
// 												>
// 													{" "}
// 													Digi Catalogue{" "}
// 												</a>
// 											</div>
// 										)}
// 										{this.props.reportType !== "bounceReport" && (
// 											<>
// 												{" "}
// 												<div className="moredtlcell settingicnprnt" style={{ width: "110px" }}>
// 													<span className="sociallinkprnt font11">
// 														<a
// 															onClick={() => {
// 																let companyTitle = compname && compname.length > 26 ? compname.substring(0, 26) + "..." : compname;
// 																setLocalStorage("whatsap_compname", companyTitle);
// 																history.push({
// 																	pathname: "/whatsapp-msg/" + parentid + "/jdgodigital",
// 																	state: { parentid: parentid, currLink: currLink, sharevia: "whatsapp" },
// 																});
// 															}}
// 															style={{ color: "#000" }}
// 														>
// 															<span className="gno_whatsupicon"></span>Messenger
// 														</a>
// 													</span>
// 												</div>
// 												<div className="moredtlcell settingicnprnt" style={{ width: "25px" }} onClick={() => this.handleCpmRedirect(parentid)}>
// 													<span className="gno_settingicn"></span>
// 												</div>
// 											</>
// 										)}
// 									</div>
// 								)}
// 							</div>
// 						</div>
// 					</div>
// 				);
// 			});

// 			let totalContractData = this.props.totalContractData || 0;

// 			return (
// 				<div>
// 					{this.state.showMinipopup && (
// 						<Minipopup
// 							title={this.state.miniPopupTitle}
// 							text={this.state.miniPopupText}
// 							handleOk={this.popupHandleOk}
// 							okPopup={this.state.popup_okPopup}
// 							handleSubmit={this.state.popup_handleSubmit}
// 							submitText={this.state.popup_submitText}
// 							handleCancel={this.popupHandleOk}
// 							cancelText={this.state.popup_cancelText}
// 						/>
// 					)}
// 					{contractDataHtml}

// 					{contractData && contractData.length > 0 && totalContractData != contractData.length && DashboardLoader && <ContentLoader />}

// 					{contractData && contractData.length > 0 && totalContractData > 10 && !DashboardLoader && (
// 						<Paginator dataOnPage={contractData.length} dataLength={totalContractData} onPageChange={this.onPageChange} itemsPerPage={10} pageShow={this.props.pageShow} pageNumberLimit={5} />
// 					)}
// 				</div>
// 			);
// 		} else {
// 			return (
// 				<div className="fnotfoundwpr" style={{ height: "60vh" }}>
// 					<div className="fnotfoundprnt">
// 						<img src={PATH_INFO + "/dev/src/media/img/filenotfound.svg"} />
// 						<div className="fnotfoundtext font18">Data Not Found</div>
// 					</div>
// 				</div>
// 			);
// 		}
// 	}
// }

// ContractModal.propTypes = {
// 	contractData: PropTypes.array.isRequired,
// };

// function mapStateToProps(state) {
// 	return {
// 		typeofemployee: state.jd_store.typeofemployee,
// 		lastDispositionData: state.jd_store.lastDispositionData || "",
// 		empcode: state.jd_store.empcode || "",
// 		datacity: state.jd_store.datacity,
// 		ratings: state.jd_store.ratings || [],
// 		campaignDetails: state.jd_store.campaignDetails || "",
// 		full_addresses: state.jd_store.full_addresses || [],
// 		mobile_str: state.jd_store.mobile_str || [],
// 		jd_app_download_status: state.jd_store.jd_app_download_status || "",
// 		jd_mart_download_status: state.jd_store.jd_mart_download_status || "",
// 		clickCallMobileNumber: state.jd_store.clickCallMobileNumber || [],
// 		user: state.jd_store.user || {},
// 		dataLoaded: state.jd_store.dataLoaded,
// 		OnboardingEmp: state.jd_store.OnboardingEmp || 0,
// 	};
// }

// const mapDispatchToProps = (dispatch) => {
// 	return {
// 		getLastDisposition: (params) => dispatch(getLastDisposition(params)),
// 		getActionData: (params, type, apiUrl) => dispatch(getActionData(params, type, apiUrl)),
// 		getMobileNumber: (params) => dispatch(getMobileNumber(params)),
// 		JDAppdownloadstatus: (params) => dispatch(JDAppdownloadstatus(params)),
// 		JDMartdownloadstatus: (params) => dispatch(JDMartdownloadstatus(params)),
// 		cancelDownsellRequest: (params) => dispatch(cancelDownsellRequest(params)),
// 		resendJdpayLink: (params) => dispatch(resendJdpayLink(params)),
// 		deleteJdpayLink: (params) => dispatch(deleteJdpayLink(params)),
// 		getPaymentDetails: (params) => dispatch(getPaymentDetails(params)),
// 		closeMustReadInstructions: (params) => dispatch(closeMustReadInstructions(params)),
// 		setDataCity: (params) => dispatch(setDataCity(params)),
// 		fetchOnboardingLiveStatus: (params) => dispatch(fetchOnboardingLiveStatus(params)),
// 		insertOnboardingData: (params) => dispatch(insertOnboardingData(params)),
// 	};
// };

// export default connect(mapStateToProps, mapDispatchToProps)(ContractModal);
