import React from "react";

let Minipopup = (props) => {
	let popup_title = props.title || "";
	let popup_titleCenter = props.titleCenter || false;
	let popup_height = props.height || "150px";
	let popup_text = props.text || "";
	let popup_submitText = props.submitText || "Submit";
	let popup_cancelText = props.cancelText || "Cancel";
	let popup_okText = props.okText || "OK";
	let popup_okPopup = props.okPopup;

	return (
		<div>
			<div className="overlay"></div>
			<div className="mini_popup">
				<div style={{ height: popup_height }}>
					<div className="title font18 mt-20" style={popup_titleCenter == true ? { textAlign: "center" } : {}}>
						{popup_title}
					</div>
					<div className="text font12 mt-10">{popup_text}</div>
					{!popup_okPopup && (
						<>
							<div className="submitwpr" onClick={() => props.handleSubmit()}>
								<button className="font16">{popup_submitText}</button>
							</div>
							<div className="cancelwpr">
								<button className="font16" onClick={() => props.handleCancel()}>
									{popup_cancelText}
								</button>
							</div>
						</>
					)}
					{popup_okPopup && (
						<div className="submitwpr" style={{ width: "100%" }} onClick={() => props.handleOk()}>
							<button className="font16">{popup_okText}</button>
						</div>
					)}
				</div>
			</div>
		</div>
	);
};

export default Minipopup;
