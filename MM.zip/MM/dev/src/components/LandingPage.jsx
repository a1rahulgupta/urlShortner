import React, { Component } from "react";
import { Route, Switch, withRouter, Redirect } from "react-router-dom";
import { connect } from "react-redux";
import { getServerCity, isPlainObjectES6 } from "./../utilities/helperFunctions";
import jsonRoute from "./Route";
import ComponentErrorSuccess from "./common/ComponentErrorSuccess";
import ErrorPage from "./common/ErrorPage";
import Minipopup from "./common/Minipopup";

//import Homepage from "./Homepage.jsx";
import Header from "./common/Header";
import Footer from "./common/Footer";

import CryptoEncryption from "../utilities/CryptoEncryption";
//nonceValue same as loginToMasterDashboard
var nonceValue = "l45bwsdioHds56lfglstuyuyPlyt23l2m3n";
const cryptoEncryption = new CryptoEncryption();
const enc_empcode = cryptoEncryption.encrypt(JSON.stringify({ empcode: EMPCODE, module: "sales_genio" }), nonceValue);

class LandingPage extends Component {
	constructor(props) {
		super(props);
		this.state = {
			inputDashPop: false,
			showLineageMinipopup: false,
			miniPopupTitle: "",
			miniPopupText: "",
		};
	}
	getHeaderProps(routes, pathname) {
		let getHeaderPropsObj = {
			pageName: "Home",
			hasMenu: true,
			hasFilter: true,
			backUrl: "",
			hasPresentationHeader: false,
		};

		routes.forEach((route) => {
			let routePathName = route['path'].split('/');
			if(window.location.href.includes(routePathName[1]+'/'+routePathName[2])){
				getHeaderPropsObj["pageName"] = route["name"];
				getHeaderPropsObj["hasMenu"] = route["hasMenu"];
				getHeaderPropsObj["hasFilter"] = route["hasFilter"];
				getHeaderPropsObj["backUrl"] = route["backUrl"];
				getHeaderPropsObj["hasPresentationHeader"] = route["hasPresentationHeader"];
				if(route["hasPresentationHeader"]){
					if(route["nextRoute"]){
						getHeaderPropsObj["nextUrl"] = route["nextRoute"];
					}
					if(route["prevRoute"]){
						getHeaderPropsObj["prevUrl"] = route["prevRoute"];
					}
				}
			}
			
			// if (
			// 	route["path"] == pathname ||
			// 	(pathname != undefined &&
			// 		((pathname.split("/").includes("whatsapp-msg") && route["path"].split("/").includes("whatsapp-msg")) ||
			// 			(route["path"].split("/").includes("finance-show-payment") && pathname.split("/").includes("finance-show-payment")) ||
			// 			(route["path"].split("/").includes("jd-partner-disposition") && pathname.split("/").includes("jd-partner-disposition")) || (route["path"].split("/").includes("finance-show-payment") && pathname.split("/").includes("finance-show-payment"))))
			// ) {
			// 	getHeaderPropsObj["pageName"] = route["name"];
			// 	getHeaderPropsObj["hasMenu"] = route["hasMenu"];
			// 	getHeaderPropsObj["hasFilter"] = route["hasFilter"];
			// 	getHeaderPropsObj["backUrl"] = route["backUrl"];
			// }
		});

		return getHeaderPropsObj;
	}
	// logout = () => {
	// 	localStorage.clear();
	// 	setTimeout(function() {
	// 		window.location.href = "../sales_genio/Utility/logout.php?empcode=" + EMPCODE;
	// 	}, 300);
	// };
	allocations() {
		this.props.history.push("/todays-allocations");
	}

	componentDidMount() {
		// const { datacity, location, ahdLineageRes, typeofemployee } = { ...this.props };
		//location.pathname == "/logout" && this.logout();
		//location.pathname == "/reload" && window.location.reload(true);
		// if (datacity == "") {
		// 	//this.props.history.push("/select-city");
		// 	this.props.history.push({
		// 		pathname: "/select-city",
		// 		deeplink_url: this.props.location.pathname || "",
		// 	});
		// }
		// let that = this;
		// document.addEventListener("click", this.onBodyClick);
		// setTimeout(function() {
		// 	that.checkLineage();
		// }, 800);
		console.log('landing----')
	}

	componentDidUpdate(prevProps, prevState) {
		//const { datacity, location } = { ...this.props };
		//location.pathname == "/logout" && this.logout();
		//location.pathname == "/reload" && window.location.reload(true);
	}
	componentWillUnmount() {
		//document.removeEventListener("click", this.onBodyClick);
	}

	handleClearError = () => {};
	handleErrorSucccessMsg = () => {};

	// checkLineage = () => {
	// 	// console.log(this.props.ahdLineageRes, "lineage");
	// 	if (this.props.ahdLineageRes && this.props.ahdLineageRes.errorcode == 1) {
	// 		this.setState({ showLineageMinipopup: true, miniPopupText: "Please update your Lineage on My Jd app in Lineage Selection and Click OK.", miniPopupTitle: "Update Lineage" });
	// 	} else if (this.props.ahdLineageRes && this.props.ahdLineageRes.errorcode == 2) {
	// 		this.setState({ showLineageMinipopup: true, miniPopupText: this.props.ahdLineageRes.errorStatus, miniPopupTitle: "Access Denied" });
	// 	} else {
	// 		let typeOfEmployeeActual = localStorage.getItem("typeOfEmployeeActual");
	// 		if (
	// 			typeOfEmployeeActual &&
	// 			(typeOfEmployeeActual.toLowerCase() == "me" || typeOfEmployeeActual.toLowerCase() == "jda" || typeOfEmployeeActual.toLowerCase() == "tme") &&
	// 			(localStorage.getItem("inputDashboard") != 1 || (localStorage.getItem("inputDashboard") == 1 && localStorage.getItem("inputDashboardLatest") != new Date().getDate()))
	// 		) {
	// 			this.setState({ inputDashPop: true });
	// 		}
	// 	}
	// };

	// onBodyClick = (event) => {
	// 	if (!this.state.showLineageMinipopup) {
	// 		if (event.target.closest(".mini_popup") && this.state.inputDashPop) {
	// 			return;
	// 		} else {
	// 			localStorage.setItem("inputDashboard", 1);
	// 			localStorage.setItem("inputDashboardLatest", new Date().getDate());
	// 			this.setState({ inputDashPop: false });
	// 		}
	// 	}
	// };

	// popupHandleOk = () => {
	// 	this.setState({ showLineageMinipopup: false, miniPopupText: "" }, () => {
	// 		if (isMobile()) {
	// 			rn_app_reload();
	// 		} else {
	// 			window.location.reload(true);
	// 		}
	// 	});
	// };

	// submitInputDash = () => {
	// 	let talktimeDashboardPath = "https://sales.genio.in/sales_genio/Utility/loginToTalktimeDashboard.php?params=" + enc_empcode + "&OPEN_OUTSIDE_APP=1&return_url=" + encodeURIComponent(window.location.href);

	// 	localStorage.setItem("inputDashboard", 1);
	// 	localStorage.setItem("inputDashboardLatest", new Date().getDate());
	// 	this.setState({ inputDashPop: false }, () => window.open(talktimeDashboardPath));
	// };

	render() {
		const routes = jsonRoute.sidebarRoute;
		console.log("routes",routes)
		const { location } = this.props;
		const {error} = this.props;
		const { pathname } = location;
		let { pageName, hasMenu, hasFooter, hasFilter, hasPresentationHeader } = this.getHeaderProps(routes, pathname);
		//pathname == "/logout" && this.logout();

		if(pathname.includes('presentation/add-jd-category')) {
			hasPresentationHeader = false;
		}

		// const nonFooterPathArr = [
		// 	"/login",
		// 	"/select-city",
		// 	"/sms-email",
		// 	"/support",
		// 	"/profile/my-ratings",
		// 	"/profile/my-digital-payment-stats",
		// 	"/whatsapp-msg",
		// 	"/create-new-business/",
		// 	"/create-new-business/1",
		// 	"/dispose-appointment",
		// 	"/feedback-report",
		// 	"/logged-by-cs",
		// 	"/complaint-history",
		// 	"/cs-logger-tracker",
		// 	"/payment-details",
		// 	"/call-the-client",
		// ];
		if (error) {
			return <ErrorPage error={error} />;
		}
		// if (!isPlainObjectES6(user)) {
		// 	var { type_of_employee } = user;
		// 	var typeofemployee = type_of_employee ? type_of_employee : "ME";
		// }
		//var errorSuccessMsgHtml = <ComponentErrorSuccess formError={"test"} formSuccess={""} handleClearError={this.handleClearError} handleErrorSucccessMsg={this.handleErrorSucccessMsg} />;

		return (
			<div>
				{
					//errorSuccessMsgHtml
				}
				{!hasPresentationHeader &&
					<Header props={this.getHeaderProps(routes, pathname)} routes={routes}></Header>
				}
				
				<Switch>
					{routes.map((prop, key) => {
						let cmp = prop.component || "";
						if (cmp) {
							return <Route exact path={prop.path} history={this.props.history} render={(props) => <prop.component {...props} myRef={this.myRef} headerProps={this.getHeaderProps(routes, pathname)} />} key={key} />;
						} else {
							return <Route exact path={prop.path} key={key} />;
						}
					})}
					<Route
						exact
						path="/"
						render={() => {
							return this.props.location.pathname == "/" && typeofemployee == "ME" ? <Redirect to="/todays-allocations" /> : <Redirect to="/todays-allocations" />;
							// return this.props.location.pathname == "/" && <Redirect to="/select-city" />;
						}}
					/>
				</Switch>

				{/* {this.state && this.state.showLineageMinipopup && <Minipopup title={this.state.miniPopupTitle} text={this.state.miniPopupText} handleOk={this.popupHandleOk} okPopup={true} />}
				{this.state && this.state.inputDashPop && (
					<div>
						<div className="overlay"></div>
						<div className="mini_popup p0">
							<div className="pt-10 pl-20 pr-20 pb-20">
								<p className="col-xs-12 p0 blkhd text-center">
									<span className="targetimage"></span>
								</p>
								<p className="col-xs-12 p0 blkhd weight700 text-center font16">Target Achieved</p>
								<p className="col-xs-12 p0 blkhd mb20 text-center">View Target Achieved by you and your Average Rating before you start your day</p>
								<div className="text-left p0">
									<button type="button" className="btn btn-primary btnwid100 p10" onClick={() => this.submitInputDash()}>
										View Dashboard
									</button>
								</div>
							</div>
						</div>
					</div>
				)} */}

				{/* {pathname != undefined && !nonFooterPathArr.includes(pathname) && !pathname.split("/").includes("whatsapp-msg") && !pathname.split("/").includes("jd-partner-disposition") && <Footer></Footer>} */}
			</div>
		);
	}
}

function mapStateToProps(state, props) {
	return {
		// user: state.jd_store.user || "",
		// error: state.jd_store.error || "",
		// typeofemployee: state.jd_store.typeofemployee || "",
		// section: state.jd_store.section || "",
		// OnboardingEmp: state.jd_store.OnboardingEmp || 0,
		// datacity: state.jd_store.datacity,
		// filter: state.jd_store.filter || "",
		// ahdLineageRes: state.jd_store.ahdLineageRes,
	};
}

export default withRouter(connect(mapStateToProps, {})(LandingPage));

// comment 2
