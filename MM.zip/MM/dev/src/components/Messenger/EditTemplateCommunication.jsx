import React, { Component } from "react";
import { connect } from "react-redux";
import ErrorPage from "../common/ErrorPage.jsx";
import SearchBar from "../common/SearchBar.jsx";
import { ComponentLoader, ContentLoader } from "../common/ComponentLoader";
import Autosuggest from "react-autosuggest";
import { getTemplateDetailsById, updateTemplateDetails, getShadowTabData } from "../../redux/actions/userActions";
import PresentationHeader from "../common/PresentationHeader";
import { setLocalStorage, getLocalStorage } from "../../utilities/localStorage";
import Minipopup from "../common/Minipopup";


class EditTemplateCommunication extends Component {
    constructor(props) {
        super(props);
        this.state = {

            hasError: false,
            formData: {
                category: "",
                catSelList: { MRK: [], PK: [], RK: [], MRLK: [] },
                existCats: [],
                removeCatsExist: [],
            },
            suggestions: [],
            categoryListShow: 0,
            blockcatListShow: 0,
            categoryList: [],
            catPageName: "",
            selSuggestion: {},
            allCategoryList: {},
            addMoreKeyword: 0,
            scrollPageNo: 1,
            jdUserFlg: 0,
            // ----------------
            submitCatLoader: 0,
            categoryLoader: 0,
            autoLoader: 0,
            // -------------
            alertPop: 0,
            alertMsg: "",
            isWarning: 0,
            isAlert: 0,
            isDownsell: 0,
            openPopUp: 0,
            version: "",
            master_transaction_id: "",
            suggestSelected: "",
            blockSuggestions: 0,
            blockedCampName: "",
            onboarding_flow: localStorage.getItem("onboarding"),
            removeCatIdList: "",
            authorisedPaid: [],
            authorisedNonPaid: [],
            nonAuthorisedPaid: [],
            nonAuthorisedNonPaid: [],
            nonpaidCatlist: "",
            removeCats: [],
            previouslySelectedKeywords: [],
            presentSelectedKeywords: [],
            previouslySelectedKeywordsReset: [],
            deletedKeywordsId: [],
            viewMore: false,
            blockedCatList: [],
            shadowData: {},
            templateDetails: {},
            Loader: true,
            title: "",
            mediaArr: [],
            media: ["sms", "email", "whatsapp"],
            message: "",
            authorizedEmp:false
        };
        // this.nextTo = this.nextTo.bind(this);
        this.onChangeTemplateTitle = this.onChangeTemplateTitle.bind(this);
        this.selectMedia = this.selectMedia.bind(this);
        this.closeUnauthorizedAlert = this.closeUnauthorizedAlert.bind(this);
    }
    componentDidMount() {
        let empcode = localStorage.getItem("messenger_admin_empcode");
        let allowedEmp = [
        "10101144",
        "10101299",
        "012435",
        "10072762",
        "023552",
        "10100034",
        "10081491",
        "10097513"
        ];
        if (empcode && allowedEmp.indexOf(window.atob(empcode)) > -1) {
          this.setState({ authorizedEmp: true , Loader: false});
          this.getTemplateDetails();
        }else{
          this.setState({ Loader: false});
        }

    }
    onChangeTemplateTitle(e) {
        console.log("e==", e)
        this.setState({
            title: e.target.value
        })

    }
    backTo = async () => {
        this.props.history.push("/select-tab/" + this.props.match.params.id)
    }

    getTemplateDetails = async () => {
        let params = {
            objectId: this.props.match.params.id,

        };
        console.log(params)
        let templateDetails = await getTemplateDetailsById(params);
        console.log("templateDetails--", templateDetails)
        this.setState({
            templateDetails: templateDetails.data.data.template,
            message: templateDetails.data.data.campaignName, Loader: false, mediaArr: templateDetails.data.data.template.communicationMedium
        })
    }
    selectMedia(e, value) {

        let index;
        let mediaName = value.toLowerCase();
        let media_arr = this.state.mediaArr;
        console.log("mediaName", mediaName)
        if (media_arr.includes(mediaName)) {
            index = media_arr.indexOf(mediaName);
            media_arr.splice(index, 1);
        } else {
            media_arr.push(mediaName);

        }
        console.log(media_arr);
        this.setState({ mediaArr: media_arr });
    }

    updateTitleHandler = async () => {
        let params = {

            objectId: this.props.match.params.id,
            updateType: "communicationMedium",
            updateData: this.state.mediaArr

        };
        await updateTemplateDetails(params);
        this.props.history.push("/select-tab/" + this.props.match.params.id)

    }
    closeUnauthorizedAlert(){
        window.location.href = "https://www.justdial.com/"
      }

    render() {
        if (loading || this.state.Loader) {
            return <ComponentLoader LoaderName="Loader" />;
        }
        if (this.state.hasError) {
            // You can render any custom fallback UI
            let errorMsg = "Something went wrong.";
            console.log(errorMsg);
            return <h1>Something went wrong.</h1>;
        }
        console.log('PROPS', this.props);

        const { error, loading, user } = this.props;
        var component_error = this.props.component_error || null;
        if (error) {
            return <ErrorPage error={error} />;
        }
        let { nextTo } = this;

        // var empcode = user.empcode || "";
        var that = this;
        const { history, pageName } = this.props;
        console.log(that.state);
        if (!this.state.authorizedEmp) {
            return (
              <Minipopup
                title={"Unauthorized"}
                text={"You are not authorized to access this Module!"}
                handleOk={this.closeUnauthorizedAlert}
                okPopup={true}
              />
            );
          }
        return (

            <div className="ms_middlewrapper">
                <div className="dtable msg_header">
                    <div className="dtable_cell msg_header_left hide_desktop"><span onClick={() => this.backTo()} className="msg_backarrow"></span></div>
                    <div className="dtable_cell msg_header_center">{this.state.message}</div>
                    {/* <div className="dtable_cell msg_header_right hide_desktop"><span className="msg_download_icon"></span></div> */}
                </div>
                <div className="ms_content_wrpr">
                    <div className="msg_heading">{this.state.templateDetails?.title}</div>
                    <div className="msg_tab_content">
                        <div className="animwrap">

                            {this.state.media &&
                                this.state.media.map((val, index) => {
                                    let isChecked = this.state.mediaArr.includes(val.toLowerCase()) ? true : false;
                                    return (
                                        <div key={index}>
                                            <div className="msg_select_options active" ><input type="checkbox" className="msg_blue_tick" checked={isChecked} onChange={(e) => this.selectMedia(e, val)} /> {val.toUpperCase()}</div>

                                        </div>


                                    )
                                })}
                        </div>


                    </div>
                </div>
                <div className="mob_footer">
                    <button onClick={() => this.updateTitleHandler()} >Save</button>
                </div>
            </div>




        );
    }
}

function mapStateToProps(state) {
    return {
        // categorySuggestionData: state.jd_store.categoryAutoSuggest,
        // user: state.jd_store.user,
        // lhsMenu: state.jd_store.lhsMenu,
    };
}

const mapDispatchToProps = (dispatch) => {
    return {
        // getCategoryAuto: (params) => dispatch(getCategoryAuto(params))

    };
};
export default connect(mapStateToProps, mapDispatchToProps)(EditTemplateCommunication);
