import React, { Component } from "react";
import { connect } from "react-redux";
import ErrorPage from "../common/ErrorPage.jsx";
import SearchBar from "../common/SearchBar.jsx";
import { ComponentLoader, ContentLoader } from "../common/ComponentLoader";
import Autosuggest from "react-autosuggest";
import { getTemplateDetailsById, updateTemplateDetails, fetchEmployeeForMessanger, getPresentationAutoSuggest } from "../../redux/actions/userActions";
import PresentationHeader from "../common/PresentationHeader";
import { setLocalStorage, getLocalStorage } from "../../utilities/localStorage";
const getSuggestionValue = (suggestion) => suggestion.empcode;
import Minipopup from "../common/Minipopup";
var timer;


class SelectEmployee extends Component {
    constructor(props) {
        super(props);
        this.state = {

            hasError: false,
            formData: {
                empId: "",
                catSelList: { MRK: [], PK: [], RK: [], MRLK: [] },
                existCats: [],
                removeCatsExist: [],
            },
            suggestions: [],
            empIdListShow: 0,
            blockcatListShow: 0,
            empIdList: [],
            catPageName: "",
            selSuggestion: {},
            allempIdList: {},
            addMoreKeyword: 0,
            scrollPageNo: 1,
            jdUserFlg: 0,
            // ----------------
            submitCatLoader: 0,
            empIdLoader: 0,
            autoLoader: 0,
            // -------------
            alertPop: 0,
            alertMsg: "",
            isWarning: 0,
            isAlert: 0,
            isDownsell: 0,
            openPopUp: 0,
            version: "",
            master_transaction_id: "",
            suggestSelected: "",
            blockSuggestions: 0,
            blockedCampName: "",
            onboarding_flow: localStorage.getItem("onboarding"),
            removeCatIdList: "",
            authorisedPaid: [],
            authorisedNonPaid: [],
            nonAuthorisedPaid: [],
            nonAuthorisedNonPaid: [],
            nonpaidCatlist: "",
            removeCats: [],
            previouslySelectedEMPs: [],
            presentSelectedEmps: [],
            previouslySelectedEMPReset: [],
            deletedEmployeesId: [],
            viewMore: false,
            blockedCatList: [],
            shadowData: {},
            templateDetails: {},
            Loader: true,
            title: "",
            empArr: [],
            empType: ["ME",
                "TME",
                "JDA",
                "JDMart"],
            message: "",
            suggestions: [],
            empIdListShow: 0,
            blockcatListShow: 0,
            empIdList: [],
            catPageName: "",
            selSuggestion: {},
            allempIdList: {},
            addMoreKeyword: 0,
            scrollPageNo: 1,
            jdUserFlg: 0,
            proceedPopup: false,
            authorizedEmp:false
        };
        // this.nextTo = this.nextTo.bind(this);
        this.onChangeTemplateTitle = this.onChangeTemplateTitle.bind(this);
        this.selectEmpType = this.selectEmpType.bind(this);
        this.onSuggestionsFetchRequested = this.onSuggestionsFetchRequested.bind(this);
        this.onSuggestionsClearRequested = this.onSuggestionsClearRequested.bind(this);
        this.onSuggestionSelected = this.onSuggestionSelected.bind(this);
        this.resetSelectedEmp = this.resetSelectedEmp.bind(this);
        this.clearText = this.clearText.bind(this);
        this.removeEmp = this.removeEmp.bind(this);
        this.setViewMore = this.setViewMore.bind(this);
        this.selectEmpCode = this.selectEmpCode.bind(this);
        this.closeUnauthorizedAlert = this.closeUnauthorizedAlert.bind(this);
    }
    componentDidMount() {
        
        let empcode = localStorage.getItem("messenger_admin_empcode");
    let allowedEmp = [
    "10101144",
    "10101299",
    "012435",
    "10072762",
    "023552",
    "10100034",
    "10081491",
    "10097513"
    ];
    if (empcode && allowedEmp.indexOf(window.atob(empcode)) > -1) {
      this.setState({ authorizedEmp: true , Loader: false});
      this.getTemplateDetails();
    }else{
      this.setState({ Loader: false});
    }

    }
    closeUnauthorizedAlert(){
        window.location.href = "https://www.justdial.com/"
      }

    resetSelectedEmp() {
        this.setState({ presentSelectedEmps: [], previouslySelectedEMPs: this.state.previouslySelectedEMPReset, viewMore: false });
    }

    setViewMore() {
        this.setState({ viewMore: !this.state.viewMore });
    }

    removeEmp(keyword) {
        if (this.state.presentSelectedEmps.length + this.state.previouslySelectedEMPs.length == 1) {
            this.setState({ viewMore: false });
        }
        for (let i = 0; i < this.state.presentSelectedEmps.length; i++) {
            if (this.state.presentSelectedEmps[i][1] === keyword) {
                let updatedKeywords = [...this.state.presentSelectedEmps].filter((keyWord) => keyWord[1] !== keyword);
                let deletedKey = [...this.state.deletedEmployeesId, this.state.presentSelectedEmps[i][0]];
                this.setState({ presentSelectedEmps: updatedKeywords, deletedEmployeesId: deletedKey });
            }
        }
        for (let i = 0; i < this.state.previouslySelectedEMPs.length; i++) {
            if (this.state.previouslySelectedEMPs[i][1] === keyword) {

                let updatedKeywords = [...this.state.previouslySelectedEMPs].filter((keyWord) => keyWord[1] !== keyword);
                let deletedKey = [...this.state.deletedEmployeesId, this.state.previouslySelectedEMPs[i][0]];
                this.setState({ previouslySelectedEMPs: updatedKeywords, deletedEmployeesId: deletedKey });
            }
        }
    }
    resetempId(state) {
        if (state == 1) {
            var tempRemoveCats = Object.keys(this.state.formData.existCats);
            var tempRemoveCatsStr = tempRemoveCats.join();
            this.setState({ removeCats: tempRemoveCats, removeCatIdList: tempRemoveCatsStr });
            this.setState({ previouslySelectedEMPs: [], presentSelectedEmps: [] });
            this.state.formData.existCats = [];
        } else {
            this.setState({ removeCats: [], removeCatIdList: "" });
        }
    }
    onSuggestionsClearRequested() {
        this.setState({
            suggestions: [],
        });
    }
    renderSuggestion(suggestion) {
        var suggest_txt = suggestion;
        return (
            <div>
                <div className="msg_emplyee_box">
                    <div className="msg_employee_txt1 mb10">{suggest_txt.empname}</div>
                    <div className="msg_employee_txt2">Emp ID : {suggest_txt.empcode} <span className="ml15">Dept : {suggest_txt.department}</span></div>
                </div>
                {/* <div dangerouslySetInnerHTML={{ __html: suggest_txt }} /> */}
            </div>
        );
    }

    onChangeTemplateTitle(e) {
        console.log("e==", e)
        this.setState({
            title: e.target.value
        })

    }
    backTo = async () => {
        this.props.history.push("/select-tab/" + this.props.match.params.id)
    }

    getTemplateDetails = async () => {
        let params = {
            objectId: this.props.match.params.id,

        };
        console.log(params)
        let templateDetails = await getTemplateDetailsById(params);
        this.setState({
            templateDetails: templateDetails.data.data.template,
            message: templateDetails.data.data.campaignName, Loader: false, empArr: templateDetails.data.data.template.employeeType,
            previouslySelectedEMPs: templateDetails.data.data.template.employeeId
        })


    }
    selectEmpType(e, value) {

        let index;
        let empName = value.toLowerCase();
        let emp_arr = this.state.empArr;
        if (emp_arr.includes(empName)) {
            index = emp_arr.indexOf(empName);
            emp_arr.splice(index, 1);
        } else {
            emp_arr.push(empName);

        }
        console.log(emp_arr);
        this.setState({ empArr: emp_arr });
    }

    updateTitleHandler = async () => {

        let employeeIdArr = [];
        // for (let i = 0; i < this.state.presentSelectedEmps.length; i++) {
        //     employeeIdArr.push(this.state.presentSelectedEmps[i][0]);
        // }
        let empTemp = this.state.previouslySelectedEMPs;
        employeeIdArr = empTemp.concat(this.state.presentSelectedEmps)

        let paramsEmpType = {

            objectId: this.props.match.params.id,
            updateType: "employeeType",
            updateData: this.state.empArr

        };
        let paramsEmpName = {

            objectId: this.props.match.params.id,
            updateType: "employeeId",
            updateData: employeeIdArr

        };
        //if (employeeIdArr.length == 0) {
           // this.setState({ proceedPopup: true });
        //} else {
            this.setState({ Loader: true })
            await updateTemplateDetails(paramsEmpType);
            await updateTemplateDetails(paramsEmpName);
            this.props.history.push("/select-tab/" + this.props.match.params.id)

        //}


    }

    closeAlert = () => {
        this.setState({ proceedPopup: false });
    };

    checkRenderAuto(value) {
        return value.trim().length > 1;
    }

    inputPropsAuto(type, placeHolder, value, onChangeCB, onBlurCB) {
        // $(".react-autosuggest__suggestions-container").animate({ scrollTop: 0 }, 100);
        var obj = this;
        var changeTypeVal = onChangeCB;
        var retData = {
            placeholder: placeHolder,
            value: value,
            onChange: function (event, { newValue }) {
                var newVals = {};
                newVals = Object.assign({}, obj.state);
                newVals["formData"][changeTypeVal] = newValue;
                obj.setState({ newVals });
            },
            onBlur: onBlurCB,
            onFocus: function (event) {
                event.preventDefault();
                return false;
            },
        };
        return retData;
    }

    onSuggestionSelected = async (type, suggestion) => {
        console.log(type, suggestion)
        this.setState({ selSuggestion: suggestion, suggestSelected: suggestion.empcode });
        let params = {};
        var thisObj = this;
        var tempArray = [];
        // params.data_city = datacity
        params.searchEmp = suggestion.empcode
        // params.catStr = suggestion.mcn
        let empFullDetails = await fetchEmployeeForMessanger(params)
        this.state.autoLoader = 0;
        if (thisObj.flagExistCheck == 1) {
            thisObj.flagExistCheck = 0;
        }
        if (empFullDetails && empFullDetails.data["errorCode"] == 0) {
            this.setState({ addMoreKeyword: 1 });
            this.setState({ empIdLoader: 0 });
            this.setState({ empIdListShow: 1 });
            this.setState({ allempIdList: empFullDetails.data["data"], scrollPageNo: 1 });

            for (var i = 0; i < 2; i++) {
                if (empFullDetails.data["data"][i] != undefined) {
                    tempArray.push(empFullDetails.data["data"][i]);
                }
            }
            var totalSelectedKewywords = this.state.previouslySelectedEMPs.concat(this.state.presentSelectedEmps);
            let totalSelectedKewywordIds = totalSelectedKewywords.map((x) => parseInt(x[0]));

            if (totalSelectedKewywordIds.indexOf(parseInt(tempArray[0]["empcode"])) == -1) {
                this.selectEmpCode(tempArray[0]['empname'], parseInt(tempArray[0]["empcode"]));
            }


            this.setState({ catPageName: "relevant", empIdList: tempArray, scrollPageNo: this.state.scrollPageNo + 4 });
        }
    }


    onSuggestionsFetchRequested = async (type, value, reason) => {
        let data_city = localStorage.getItem("datacity")
        var newVals = {};
        newVals = Object.assign({}, this.state);
        let params = {};
        let empData;
        params.searchEmp = value
        if (reason == "input-focused") {
            return;
        }
        if (value.length > 4) {
            empData = await fetchEmployeeForMessanger(params)

            clearTimeout(timer);
            this.setState({ autoLoader: 1 });
            if (empData && empData.data.errorCode == 0) {
                this.state.autoLoader = 0;
                if (empData.data.data.length > 0) {
                    newVals["suggestions"] = empData.data.data;
                } else {
                    newVals["suggestions"] = [];
                }
                this.setState({ suggestions: newVals["suggestions"] });
            }

        }
    }

    clearText() {
        var newVals = {};
        newVals = Object.assign({}, this.state.formData);
        newVals["empId"] = "";
        this.setState({ formData: newVals });
    }

    selectEmpCode(keyword, id) {
        console.log(keyword, id, this.state)
        //count ---> count of number of values in selectedKeyword equal to (keyword)
        let count = 0;
        for (let i = 0; i < this.state.presentSelectedEmps.length; i++) {
            if (this.state.presentSelectedEmps[i][1] === keyword) {
                count++;
            }
        }
        for (let i = 0; i < this.state.previouslySelectedEMPs.length; i++) {
            if (this.state.previouslySelectedEMPs[i][1] === keyword) {
                count++;
            }
        }
        if (count === 0) {
            let selectedKeyword = [...this.state.presentSelectedEmps, [id, keyword]];
            this.setState({ presentSelectedEmps: selectedKeyword }, () => { });
        }
    }

    render() {
        if (loading || this.state.Loader) {
            return <ComponentLoader LoaderName="Loader" />;
        }
        if (this.state.hasError) {
            // You can render any custom fallback UI
            let errorMsg = "Something went wrong.";
            console.log(errorMsg);
            return <h1>Something went wrong.</h1>;
        }

        const { error, loading, user } = this.props;
        var component_error = this.props.component_error || null;
        if (error) {
            return <ErrorPage error={error} />;
        }
        let { nextTo } = this;
        const suggestions = this.state.suggestions;
        let bformData = this.state.formData;
        var checkForm = this.state;
        // var empcode = user.empcode || "";
        var thisObj = this;
        const { history, pageName } = this.props;
        let { selectEmpCode, removeEmp, proceed, resetSelectedEmp } = this;
        var totalSelectedKewywords = this.state.previouslySelectedEMPs.concat(this.state.presentSelectedEmps);

        let keywordsType = this.props.match.params.type;
        let totalSelectedKewywordIds = totalSelectedKewywords.map((x) => parseInt(x[0]));
        if (this.state.proceedPopup) {
            return (
                <Minipopup
                    title={"Select Employee"}
                    text={"Please select atleast one employee"}
                    handleOk={this.closeAlert}
                    okPopup={true}
                />
            );
        }
        if (!this.state.authorizedEmp) {
            return (
              <Minipopup
                title={"Unauthorized"}
                text={"You are not authorized to access this Module!"}
                handleOk={this.closeUnauthorizedAlert}
                okPopup={true}
              />
            );
          }
        return (

            <div className="ms_middlewrapper">
                <div className="dtable msg_header">
                    <div className="dtable_cell msg_header_left hide_desktop"><span onClick={() => this.backTo()} className="msg_backarrow"></span></div>
                    <div className="dtable_cell msg_header_center">{this.state.message}</div>
                    {/* <div className="dtable_cell msg_header_right hide_desktop"><span className="msg_download_icon"></span></div> */}
                </div>
                <div className="ms_content_wrpr">
                    <div className="msg_heading">{this.state.templateDetails?.title}</div>
                    <div className="msg_tab_content">
                        <div className="animwrap">

                            {this.state.empType &&
                                this.state.empType.map((val, index) => {
                                    let isChecked = this.state.empArr.includes(val.toLowerCase()) ? true : false;
                                    return (
                                        <div key={index}>
                                            <div className="msg_select_options active" ><input type="checkbox" className="msg_blue_tick" checked={isChecked} onChange={(e) => this.selectEmpType(e, val)} /> {val.toUpperCase()}</div>

                                        </div>


                                    )
                                })}
                        </div>

                        <div className="col-xs-12 p0 mb-15">
                            <div className="col-xs-12 p0 grytxt2 weight600 mb-15">Select Employee</div>
                            <div className="col-xs-12 p0 searchfilter">
                                <span className="addkeyword_search ct_iconbx dib vm"></span>
                                <Autosuggest
                                    suggestions={suggestions}
                                    onSuggestionsFetchRequested={function ({ value, reason }) {
                                        if (reason == "input-focused") {
                                            return;
                                        }
                                        thisObj.onSuggestionsFetchRequested("area", value);
                                    }}
                                    onSuggestionsClearRequested={this.onSuggestionsClearRequested}
                                    getSuggestionValue={getSuggestionValue}
                                    renderSuggestion={thisObj.renderSuggestion}
                                    inputProps={this.inputPropsAuto("empId", "Search for Employee", bformData["empId"], "empId", thisObj.populatePinBlank)}
                                    onSuggestionSelected={function (e, { suggestion }) {
                                        thisObj.onSuggestionSelected("empId", suggestion);
                                    }}
                                    shouldRenderSuggestions={thisObj.checkRenderAuto}
                                />
                                {thisObj.state.autoLoader == 1 && (
                                    <svg className="catCircular" viewBox="25 25 50 50">
                                        <circle className="path" cx="50" cy="50" r="20" fill="none" strokeWidth="2" strokeMiterlimit="10" />
                                    </svg>
                                )}
                                {thisObj.state.formData["empId"] != "" && (
                                    <a href="javascript:;" className="clr color007" onClick={this.clearText}>
                                        CLEAR
                                    </a>
                                )}
                            </div>
                        </div>
                        {totalSelectedKewywords.length !== 0 && (
                            <div className="col-xs-12 p0 mb10 displayFlex">
                                <div className="col-xs-6 p0 color414 font13 fw400 pb-20 tleft">Selected Employee</div>
                                <div className="col-xs-6 p0 color007 font13 fw400 tright">
                                   

                                    <a className="color007" href="javascript:;" onClick={this.resetempId.bind(this, 1)}>
                                        Remove All
										</a>
                                </div>
                            </div>
                        )}

                        {this.state.viewMore ? (
                            <div>
                                <div className="p0 mb-10">
                                    {totalSelectedKewywords.map(function (keyword, i) {

                                        return (
                                            // <span key={i}>


                                            <span key={i} className="msg_selectedemp">{keyword[1]}
                                                <span onClick={() => removeEmp(keyword[1])} className="msg_bluecrs">
                                                </span>
                                            </span>




                                        );
                                    })}
                                </div>
                                <div className="color007 font13 fw400 mb-10 dtbl">
                                    {totalSelectedKewywords.length > 3 && (
                                        <a href="javascript:;" onClick={() => this.setViewMore()}>
                                            View Less
                                        </a>
                                    )}
                                </div>
                            </div>
                        ) : (
                                <div>
                                    <div className="p0 mb-20">
                                        {totalSelectedKewywords.map(function (keyword, i) {
                                            if (i < 4) {

                                                return (
                                                    <span key={i} className="msg_selectedemp">{keyword[1]}
                                                        <span onClick={() => removeEmp(keyword[1])} className="msg_bluecrs">
                                                        </span>
                                                    </span>
                                                );
                                            }
                                        })}
                                    </div>
                                    <div>
                                        {totalSelectedKewywords.length > 4 && (
                                            <a className="color007 font13 fw400 mb-10 dtbl" href="javascript:;" onClick={() => this.setViewMore()}>
                                                View More
                                            </a>
                                        )}
                                    </div>
                                </div>
                            )}

                    </div>
                </div>
                <div className="mob_footer">
                    <button onClick={() => this.updateTitleHandler()} >Save</button>
                </div>
            </div>




        );
    }
}

function mapStateToProps(state) {
    return {
        // empIdSuggestionData: state.jd_store.empIdAutoSuggest,
        // user: state.jd_store.user,
        // lhsMenu: state.jd_store.lhsMenu,
    };
}

const mapDispatchToProps = (dispatch) => {
    return {
        // getempIdAuto: (params) => dispatch(getempIdAuto(params))

    };
};
export default connect(mapStateToProps, mapDispatchToProps)(SelectEmployee);
