
import React, { Component } from "react";
import { connect } from "react-redux";
import ErrorPage from "../common/ErrorPage.jsx";
import SearchBar from "../common/SearchBar.jsx";
import { ComponentLoader, ContentLoader } from "../common/ComponentLoader";
import Autosuggest from "react-autosuggest";
import { getTemplateDetailsById, updateTemplateDetails, fetchMainCities,fetchRemoteCities,fetchTierCities } from "../../redux/actions/userActions";
import PresentationHeader from "../common/PresentationHeader";
import { setLocalStorage, getLocalStorage } from "../../utilities/localStorage";
import Minipopup from "../common/Minipopup";


class SelectCity extends Component {
    constructor(props) {
        super(props);
        this.state = {

            hasError: false,
            scrollPageNo: 1,
            jdUserFlg: 0,
            // ----------------
            submitCatLoader: 0,
            categoryLoader: 0,
            autoLoader: 0,
            // -------------
            alertPop: 0,
            alertMsg: "",
            isWarning: 0,
            isAlert: 0,
            isDownsell: 0,
            openPopUp: 0,
            version: "",
            viewMore: false,
            blockedCatList: [],
            shadowData: {},
            templateDetails: {},
            Loader: true,
            title: "",
            message: "",
            baseCityArr: [],
            is11Mains: true,
            isRemote: false,
            isTier1: false,
            isTier2: false,
            isTier3: false,
            mains11Cities: [],
            cityArr: [],
            proceedPopup:false,
            authorizedEmp:false
            
        };
        // this.nextTo = this.nextTo.bind(this);
        this.selectBaseCity = this.selectBaseCity.bind(this);
        this.closeUnauthorizedAlert = this.closeUnauthorizedAlert.bind(this);
    }
    componentDidMount() {
       
        let empcode = localStorage.getItem("messenger_admin_empcode");
        let allowedEmp = [
        "10101144",
        "10101299",
        "012435",
        "10072762",
        "023552",
        "10100034",
        "10081491",
        "10097513"
        ];
        if (empcode && allowedEmp.indexOf(window.atob(empcode)) > -1) {
          this.setState({ authorizedEmp: true , Loader: false});
          this.getTemplateDetails();
        this.fetchMainCitiesHandler();
        }else{
          this.setState({ Loader: false});
        }

    }
    closeUnauthorizedAlert(){
        window.location.href = "https://www.justdial.com/"
      }


    updateCityHandler = async () => {
        var cityArr = this.state.cityArr;
        if(this.state.cityArr.length > 1){
            
            cityArr = this.state.cityArr.filter(item => item !== "all_cities")
        }
        
        let params = {

            objectId: this.props.match.params.id,
            updateType: "citySelected",
            updateData: cityArr

        };

        if((cityArr.length == 0 && (this.state.baseCityArr.includes("all_cities") || this.state.baseCityArr.includes("select_cities"))) || (this.state.baseCityArr.includes("select_cities") && (cityArr.includes("all_cities") ))){
            this.setState({ proceedPopup: true });
        }else{
            await updateTemplateDetails(params);
            this.props.history.push("/select-template")
    
        }
        
       
    }
    backTo = async () => {
        this.props.history.push("/select-tab/" + this.props.match.params.id)
    }
    getTemplateDetails = async () => {
        let params = {
            objectId: this.props.match.params.id,

        };
        console.log(params)
        let templateDetails = await getTemplateDetailsById(params);
        console.log("templateDetails---", templateDetails)
        this.setState({
            templateDetails: templateDetails.data.data.template, message: templateDetails.data.data.campaignName, Loader: false,
            cityArr: templateDetails.data.data.template.citySelected
        })
        let baseCityArr = [];
        if (this.state.cityArr.includes("all_cities")) {
            baseCityArr.push("all_cities")
            this.setState({
                baseCityArr: baseCityArr
            })
        } else {
            baseCityArr.push("select_cities")
            this.setState({
                baseCityArr: baseCityArr
            })
        }
    }
    fetchMainCitiesHandler = async () => {
        this.setState({
            is11Mains: true, isRemote: false, isTier1: false, isTier2: false,
            isTier3: false, isTier4: false
        });
        let params = {
            mainCity: 'Main City'
        }
        let fetchMainCitiesDetails = await fetchMainCities(params);
        console.log("fetchMainCities===", fetchMainCitiesDetails)
        this.setState({ mains11Cities: fetchMainCitiesDetails.data.data })


    }

    fetchRemoteCitiesHandler = async() => {
        console.log("0000-");
        this.setState({
          is11Mains: false,
          isRemote: true,
          isTier1: false,
          isTier2: false,
          isTier3: false,
          isTier4: false
        });
        let params = {
          filterCity: [],
          remoteCity: "Remote City",
          searchText: ""
        };
        let fetchRemoteCitiesDetails = await fetchRemoteCities(params);
        console.log("fetchMainCities===", fetchRemoteCitiesDetails)
        this.setState({ RemoteCities: fetchRemoteCitiesDetails.data.data })
        
      };
      fetchTier1CitiesHandler = async() => {
        this.setState({
          is11Mains: false,
          isRemote: false,
          isTier1: true,
          isTier2: false,
          isTier3: false,
          isTier4: false
        });
        let params = {
          tier: "Tier 1",
          searchText: ""
        };
        let fetchTierCitiesDetails = await fetchTierCities(params);
        console.log("fetchMainCities===", fetchTierCitiesDetails)
        this.setState({ TierCities: fetchTierCitiesDetails.data.data })
       
      };
      fetchTier2CitiesHandler = async() => {
        this.setState({
          is11Mains: false,
          isRemote: false,
          isTier1: false,
          isTier2: true,
          isTier3: false,
          isTier4: false
        });
        let params = {
          tier: "Tier 2",
          searchText: ""
        };
        let fetchTierCitiesDetails = await fetchTierCities(params);
        console.log("fetchMainCities===", fetchTierCitiesDetails)
        this.setState({ TierCities: fetchTierCitiesDetails.data.data })
      };
      fetchTier3CitiesHandler = async() => {
        this.setState({
          is11Mains: false,
          isRemote: false,
          isTier1: false,
          isTier2: false,
          isTier3: true,
          isTier4: false
        });
        let params = {
          tier: "Tier 3",
          searchText: ""
        };
        let fetchTierCitiesDetails = await fetchTierCities(params);
        console.log("fetchMainCities===", fetchTierCitiesDetails)
        this.setState({ TierCities: fetchTierCitiesDetails.data.data })
      };

    selectBaseCity = async (e, value) => {
        console.log(e, value)
        let baseCityArr
        let city_arr = [];
        if (value == "all_cities") {
            baseCityArr = [];
            baseCityArr.push("all_cities")
            city_arr.push("all_cities");
            this.setState({ cityArr: city_arr });
        } else {
            baseCityArr = [];
            // this.setState({ cityArr: [] });
            baseCityArr.push("select_cities")
            // this.getTemplateDetails();
        }
        this.setState({
            baseCityArr: baseCityArr
        })
    }
    selectCities = (e, value) => {
        let index;
        let cityName = value.toLowerCase();
        let city_arr = this.state.cityArr;
        console.log("cityName", cityName);
        if (city_arr.includes(cityName)) {
          index = city_arr.indexOf(cityName);
          city_arr.splice(index, 1);
        } else {
          city_arr.push(cityName);
        }
        console.log(city_arr);
        this.setState({ cityArr: city_arr });
    }

    closeAlert = () => {
        this.setState({ proceedPopup: false });
      };
    render() {
        if (loading || this.state.Loader) {
            return <ComponentLoader LoaderName="Loader" />;
        }
        if (this.state.hasError) {
            // You can render any custom fallback UI
            let errorMsg = "Something went wrong.";
            console.log(errorMsg);
            return <h1>Something went wrong.</h1>;
        }
        console.log('PROPS', this.props);

        const { error, loading, user } = this.props;
        var component_error = this.props.component_error || null;
        if (error) {
            return <ErrorPage error={error} />;
        }
        let { nextTo } = this;

        // var empcode = user.empcode || "";
        var that = this;
        const { history, pageName } = this.props;
        console.log(that.state);
        if (this.state.proceedPopup) {
            return (
              <Minipopup
                title={"Select Cities"}
                text={"Please select atleast one city"}
                handleOk={this.closeAlert}
                okPopup={true}
              />
            );
          }
          if (!this.state.authorizedEmp) {
            return (
              <Minipopup
                title={"Unauthorized"}
                text={"You are not authorized to access this Module!"}
                handleOk={this.closeUnauthorizedAlert}
                okPopup={true}
              />
            );
          }

        return (

            <div className="ms_middlewrapper">
                <div className="dtable msg_header">
                    <div className="dtable_cell msg_header_left hide_desktop"><span onClick={() => this.backTo()} className="msg_backarrow"></span></div>
                    <div className="dtable_cell msg_header_center">{this.state.message}</div>
                    {/* <div className="dtable_cell msg_header_right hide_desktop"><span className="msg_download_icon"></span></div> */}
                </div>
                
                <div className="ms_content_wrpr">
                    <div className="msg_heading">{this.state.templateDetails?.title}</div>
                    <div className="msg_tab_content">
                        <div className="animwrap">

                            <div className="msg_select_options active" ><input type="checkbox" className="msg_blue_tick" checked={this.state.baseCityArr.includes("all_cities") ? true : false} onChange={(e) => this.selectBaseCity(e, "all_cities")} />All Cities</div>
                            <div className="msg_select_options active" ><input type="checkbox" className="msg_blue_tick" checked={this.state.baseCityArr.includes("select_cities") ? true : false} onChange={(e) => this.selectBaseCity(e, "select_cities")} />Select Cities</div>




                        </div>
                        {this.state.baseCityArr.includes("select_cities") && (<div>
                            <div className="msg_label mb10">Choose Desired cities</div>

                            <div className="mb20 msg_sub_tabs">
                                <div className={"msg_subtabs_li " + (this.state.is11Mains ? 'active' : '')} onClick={() => this.fetchMainCitiesHandler()} >9 Mains</div>
                                <div className={"msg_subtabs_li " + (this.state.isRemote ? 'active' : '')} onClick={() => this.fetchRemoteCitiesHandler()} >All Remotes</div>
                                <div className={"msg_subtabs_li " + (this.state.isTier1 ? 'active' : '')} onClick={() => this.fetchTier1CitiesHandler()} >Tier 1</div>
                                <div className={"msg_subtabs_li " + (this.state.isTier2 ? 'active' : '')} onClick={() => this.fetchTier2CitiesHandler()} >Tier 2</div>
                                <div className={"msg_subtabs_li " + (this.state.isTier3 ? 'active' : '')} onClick={() => this.fetchTier3CitiesHandler()} >Tier 3</div>
                            </div>


                            {this.state.is11Mains == true && this.state.mains11Cities &&
                                this.state.mains11Cities.map((val, index) => {

                                     let isChecked = this.state.cityArr.includes(val.City.toLowerCase()) ? true : false;

                                    return (

                                        <div className="msg_cities_wrpr" key={"filtertype_" + index}>

                                            <div className="msg_select_options active" ><input type="checkbox" checked={isChecked} className="msg_blue_tick" onChange={(e) => this.selectCities(e, val.City)} /> {val.City}</div>

                                        </div>
                                    )
                                })}
                                {this.state.isRemote == true && this.state.RemoteCities &&
                                this.state.RemoteCities.map((val, index) => {

                                     let isChecked = this.state.cityArr.includes(val.City.toLowerCase()) ? true : false;

                                    return (

                                        <div className="msg_cities_wrpr" key={"filtertype_" + index}>

                                            <div className="msg_select_options active" ><input type="checkbox" checked={isChecked} className="msg_blue_tick" onChange={(e) => this.selectCities(e, val.City)} /> {val.City}</div>

                                        </div>
                                    )
                                })}
                                {this.state.isTier1 == true && this.state.TierCities &&
                                this.state.TierCities.map((val, index) => {

                                     let isChecked = this.state.cityArr.includes(val.City.toLowerCase()) ? true : false;

                                    return (

                                        <div className="msg_cities_wrpr" key={"filtertype_" + index}>

                                            <div className="msg_select_options active" ><input type="checkbox" checked={isChecked} className="msg_blue_tick" onChange={(e) => this.selectCities(e, val.City)} /> {val.City}</div>

                                        </div>
                                    )
                                })}
                              
                                {this.state.isTier2 == true && this.state.TierCities &&
                                this.state.TierCities.map((val, index) => {

                                     let isChecked = this.state.cityArr.includes(val.City.toLowerCase()) ? true : false;

                                    return (

                                        <div className="msg_cities_wrpr" key={"filtertype_" + index}>

                                            <div className="msg_select_options active" ><input type="checkbox" checked={isChecked} className="msg_blue_tick" onChange={(e) => this.selectCities(e, val.City)} /> {val.City}</div>

                                        </div>
                                    )
                                })}
{this.state.isTier3 == true && this.state.TierCities &&
                                this.state.TierCities.map((val, index) => {

                                     let isChecked = this.state.cityArr.includes(val.City.toLowerCase()) ? true : false;

                                    return (

                                        <div className="msg_cities_wrpr" key={"filtertype_" + index}>

                                            <div className="msg_select_options active" ><input type="checkbox" checked={isChecked} className="msg_blue_tick" onChange={(e) => this.selectCities(e, val.City)} /> {val.City}</div>

                                        </div>
                                    )
                                })}
                        </div>

                        )}


                    </div>
                </div>
                <div className="mob_footer">
                    <button onClick={() => this.updateCityHandler()} >Save</button>
                </div>
            </div>




        );
    }
}

function mapStateToProps(state) {
    return {
        // categorySuggestionData: state.jd_store.categoryAutoSuggest,
        // user: state.jd_store.user,
        // lhsMenu: state.jd_store.lhsMenu,
    };
}

const mapDispatchToProps = (dispatch) => {
    return {
        // getCategoryAuto: (params) => dispatch(getCategoryAuto(params))

    };
};
export default connect(mapStateToProps, mapDispatchToProps)(SelectCity);
