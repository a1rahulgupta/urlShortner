import React, { Component } from "react";
import loadable from "react-loadable";
import { setLocalStorage, getLocalStorage } from "./../utilities/localStorage";

function hardReload() {
	window.location.reload(1);
}

const LoadingComponent = (props) => {
	
	if (props.error) {
		return (
			<div
				style={{
					width: "50%",
					margin: "0 auto",
					position: "relative",
					top: "100px",
					textAlign: "center",
				}}
			>
				<p>New Changes went live. Please retry! </p>
				<button className="btn btn-default" type="button" onClick={() => hardReload()}>
					Retry
				</button>
			</div>
		);
	} else if (props.timedOut) {
		return <div status={props}>&nbsp;</div>;
	} else if (props.pastDelay) {
		return <div status={props}>&nbsp;</div>;
	} else {
		return null;
	}
};

var currLink = localStorage.getItem("currLink");

const Login = loadable({
	loader: () => import(/* webpackChunkName: "AddKeywords" */ "./Login_jdmart.jsx").then((object) => object.default),
	loading: LoadingComponent,
	delay: 200,
	timeout: 10000,
});
const SelectMessage = loadable({
	loader: () => import(/* webpackChunkName: "AddKeywords" */ "./Messenger/SelectMessage.jsx").then((object) => object.default),
	loading: LoadingComponent,
	delay: 200,
	timeout: 10000,
});
const SelectTemplate = loadable({
	loader: () => import(/* webpackChunkName: "AddKeywords" */ "./Messenger/SelectTemplate.jsx").then((object) => object.default),
	loading: LoadingComponent,
	delay: 200,
	timeout: 10000,
});
const MessageEditTabs = loadable({
	loader: () => import(/* webpackChunkName: "AddKeywords" */ "./Messenger/MessageEditTabs.jsx").then((object) => object.default),
	loading: LoadingComponent,
	delay: 200,
	timeout: 10000,
});

const EditTemplateTitle = loadable({
	loader: () => import(/* webpackChunkName: "AddKeywords" */ "./Messenger/EditTemplateTitle.jsx").then((object) => object.default),
	loading: LoadingComponent,
	delay: 200,
	timeout: 10000,
});
const EditTemplateCommunication = loadable({
	loader: () => import(/* webpackChunkName: "AddKeywords" */ "./Messenger/EditTemplateCommunication.jsx").then((object) => object.default),
	loading: LoadingComponent,
	delay: 200,
	timeout: 10000,
});
const EditTemplateAbbr = loadable({
	loader: () => import(/* webpackChunkName: "AddKeywords" */ "./Messenger/EditTemplateAbbr.jsx").then((object) => object.default),
	loading: LoadingComponent,
	delay: 200,
	timeout: 10000,
});
const SelectCity = loadable({
	loader: () => import(/* webpackChunkName: "AddKeywords" */ "./Messenger/SelectCity.jsx").then((object) => object.default),
	loading: LoadingComponent,
	delay: 200,
	timeout: 10000,
});
const ContentAndImage = loadable({
	loader: () => import(/* webpackChunkName: "AddKeywords" */ "./Messenger/ContentAndImage.jsx").then((object) => object.default),
	loading: LoadingComponent,
	delay: 200,
	timeout: 10000,
});
const SelectEmployee = loadable({
	loader: () => import(/* webpackChunkName: "AddKeywords" */ "./Messenger/SelectEmployee.jsx").then((object) => object.default),
	loading: LoadingComponent,
	delay: 200,
	timeout: 10000,
});

var routes = [
	
	{
		path: "/login",
		name: "Login",
		icon: " icon",
		hasMenu: false,
		hasFooter: false,
		hasFilter: false,
		backUrl: "go-back",
		component: Login,
		layout: ".",
		wow_duration: "0.00s",
	},
	{
		path: "/select-message/:empcode?",
		name: "Select Message",
		icon: " icon",
		hasMenu: false,
		hasFooter: false,
		hasFilter: false,
		backUrl: "go-back",
		component: SelectMessage,
		layout: ".",
		wow_duration: "0.00s",
	},
	{
		path: "/select-template",
		name: "Select Template",
		icon: " icon",
		hasMenu: false,
		hasFooter: false,
		hasFilter: false,
		backUrl: "go-back",
		component: SelectTemplate,
		layout: ".",
		wow_duration: "0.00s",
	},
	{
		path: "/select-tab/:id",
		name: "Select Tab",
		icon: " icon",
		hasMenu: false,
		hasFooter: false,
		hasFilter: false,
		backUrl: "go-back",
		component: MessageEditTabs,
		layout: ".",
		wow_duration: "0.00s",
	},
	{
		path: "/select-title/:id",
		name: "Select Title",
		icon: " icon",
		hasMenu: false,
		hasFooter: false,
		hasFilter: false,
		backUrl: "go-back",
		component: EditTemplateTitle,
		layout: ".",
		wow_duration: "0.00s",
	},
	{
		path: "/select-communication/:id",
		name: "Select Title",
		icon: " icon",
		hasMenu: false,
		hasFooter: false,
		hasFilter: false,
		backUrl: "go-back",
		component: EditTemplateCommunication,
		layout: ".",
		wow_duration: "0.00s",
	},
	{
		path: "/select-abbr/:id",
		name: "Select Title",
		icon: " icon",
		hasMenu: false,
		hasFooter: false,
		hasFilter: false,
		backUrl: "go-back",
		component: EditTemplateAbbr,
		layout: ".",
		wow_duration: "0.00s",
	},
	{
		path: "/select-city/:id",
		name: "Select City",
		icon: " icon",
		hasMenu: false,
		hasFooter: false,
		hasFilter: false,
		backUrl: "go-back",
		component: SelectCity,
		layout: ".",
		wow_duration: "0.00s",
	},
	{
		path: "/content-and-image/:id",
		name: "Content and Image",
		icon: " icon",
		hasMenu: false,
		hasFooter: false,
		hasFilter: false,
		backUrl: "go-back",
		component: ContentAndImage,
		layout: ".",
		wow_duration: "0.00s",
	},
	{
		path: "/select-employee/:id",
		name: "Select Employee",
		icon: " icon",
		hasMenu: false,
		hasFooter: false,
		hasFilter: false,
		backUrl: "go-back",
		component: SelectEmployee,
		layout: ".",
		wow_duration: "0.00s",
	},
	
	
	
	
];
export default { sidebarRoute: routes };
