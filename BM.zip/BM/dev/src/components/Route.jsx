import React, { Component } from "react";
import loadable from "react-loadable";
import { setLocalStorage, getLocalStorage } from "./../utilities/localStorage";

function hardReload() {
  window.location.reload(true);
}

const LoadingComponent = props => {
  if (props.error) {
    return (
      <div
        style={{
          width: "50%",
          margin: "0 auto",
          position: "relative",
          top: "100px",
          textAlign: "center"
        }}
      >
        <p>New Changes went live. Please retry! </p>
        <button
          className="btn btn-default"
          type="button"
          onClick={() => hardReload()}
        >
          Retry
        </button>
      </div>
    );
  } else if (props.timedOut) {
    return <div status={props}>&nbsp;</div>;
  } else if (props.pastDelay) {
    return <div status={props}>&nbsp;</div>;
  } else {
    return null;
  }
};
const currLink = getLocalStorage("currLink") || "";

const SelectUsers = loadable({
  loader: () => import("./SelectUsers.jsx").then(object => object.default),
  loading: LoadingComponent,
  delay: 200,
  timeout: 10000
});
const SelectCity = loadable({
  loader: () => import("./SelectCity.jsx").then(object => object.default),
  loading: LoadingComponent,
  delay: 200,
  timeout: 10000
});

const SelectCampaign = loadable({
  loader: () => import("./SelectCampaign.jsx").then(object => object.default),
  loading: LoadingComponent,
  delay: 200,
  timeout: 10000
});
const SelectVariant = loadable({
  loader: () => import("./SelectVariant.jsx").then(object => object.default),
  loading: LoadingComponent,
  delay: 200,
  timeout: 10000
});

const PlanBudget = loadable({
  loader: () => import("./PlanBudget.jsx").then(object => object.default),
  loading: LoadingComponent,
  delay: 200,
  timeout: 10000
});

const Discount = loadable({
  loader: () => import("./Discount.jsx").then(object => object.default),
  loading: LoadingComponent,
  delay: 200,
  timeout: 10000
});

const FreeAddOnProduct = loadable({
  loader: () => import("./FreeAddOnProduct.jsx").then(object => object.default),
  loading: LoadingComponent,
  delay: 200,
  timeout: 10000
});

const BudgetWindowTime = loadable({
  loader: () => import("./BudgetWindowTime.jsx").then(object => object.default),
  loading: LoadingComponent,
  delay: 200,
  timeout: 10000
});
const UpdatePlanCampaign = loadable({
  loader: () =>
    import("./UpdatePlanCampaign.jsx").then(object => object.default),
  loading: LoadingComponent,
  delay: 200,
  timeout: 10000
});

const PlanCampaign = loadable({
  loader: () => import("./PlanCampaign.jsx").then(object => object.default),
  loading: LoadingComponent,
  delay: 200,
  timeout: 10000
});

const ChooseTop5Plan = loadable({
  loader: () => import("./choosePlans.jsx").then(object => object.default),
  loading: LoadingComponent,
  delay: 200,
  timeout: 10000
});

const UpdateAddOn = loadable({
  loader: () => import("./AddonUpdate.jsx").then(object => object.default),
  loading: LoadingComponent,
  delay: 200,
  timeout: 10000
});

// ecs

const EcsFlow = loadable({
  loader: () => import("./EcsFlow.jsx").then(object => object.default),
  loading: LoadingComponent,
  delay: 200,
  timeout: 10000
});

const BulkUpload = loadable({
  loader: () => import("./BulkUpload.jsx").then(object => object.default),
  loading: LoadingComponent,
  delay: 200,
  timeout: 10000
});

const CampaignSelection = loadable({
  loader: () =>
    import("./CampaignSelection.jsx").then(object => object.default),
  loading: LoadingComponent,
  delay: 200,
  timeout: 10000
});

const BulkUploadReport = loadable({
  loader: () => import("./BulkUploadReport.jsx").then(object => object.default),
  loading: LoadingComponent,
  delay: 200,
  timeout: 10000
});
var routes = [
  {
    path: "/select-users/:empcode?",
    name: "Select Users",
    icon: " icon",
    hasMenu: true,
    hasFooter: false,
    hasFilter: false,
    backUrl: "",
    component: SelectUsers,
    layout: ".",
    wow_duration: "0.00s"
  },
  {
    path: "/select-cities",
    name: "Select Cities",
    icon: " icon",
    hasMenu: true,
    hasFooter: false,
    hasFilter: false,
    backUrl: "",
    component: SelectCity,
    layout: ".",
    wow_duration: "0.00s"
  },

  {
    path: "/select-campaign",
    name: "Select Campaign",
    icon: " icon",
    hasMenu: true,
    hasFooter: false,
    hasFilter: false,
    backUrl: "",
    component: SelectCampaign,
    layout: ".",
    wow_duration: "0.00s"
  },
  {
    path: "/select-variant",
    name: "Select Variant",
    icon: " icon",
    hasMenu: true,
    hasFooter: false,
    hasFilter: false,
    backUrl: "",
    component: SelectVariant,
    layout: ".",
    wow_duration: "0.00s"
  },
  {
    path: "/plan-budget/:variant",
    name: "Plan and Budget",
    icon: " icon",
    hasMenu: true,
    hasFooter: false,
    hasFilter: false,
    backUrl: "",
    component: PlanBudget,
    layout: ".",
    wow_duration: "0.00s"
  },
  {
    path: "/discount/:variant",
    name: "Discount",
    icon: " icon",
    hasMenu: true,
    hasFooter: false,
    hasFilter: false,
    backUrl: "",
    component: Discount,
    layout: ".",
    wow_duration: "0.00s"
  },
  {
    path: "/freeAddOn-product/:variant",
    name: "Free Add on product",
    icon: " icon",
    hasMenu: true,
    hasFooter: false,
    hasFilter: false,
    backUrl: "",
    component: FreeAddOnProduct,
    layout: ".",
    wow_duration: "0.00s"
  },
  {
    path: "/budget-window-time",
    name: "Budget Window Time",
    icon: " icon",
    hasMenu: true,
    hasFooter: false,
    hasFilter: false,
    backUrl: "",
    component: BudgetWindowTime,
    layout: ".",
    wow_duration: "0.00s"
  },
  {
    path: "/planCampaign",
    name: "Plan Campaign",
    icon: " icon",
    hasMenu: true,
    hasFooter: false,
    hasFilter: false,
    backUrl: "",
    component: PlanCampaign,
    layout: ".",
    wow_duration: "0.00s"
  },
  {
    path: "/UpdatePlanCampaign/:type",
    name: "Update Plan Campaign",
    icon: " icon",
    hasMenu: true,
    hasFooter: false,
    hasFilter: false,
    backUrl: "",
    component: UpdatePlanCampaign,
    layout: ".",
    wow_duration: "0.00s"
  },
  {
    path: "/ChooseTop5Plan",
    name: "Choose Top 5 Plans",
    icon: " icon",
    hasMenu: true,
    hasFooter: false,
    hasFilter: false,
    backUrl: "",
    component: ChooseTop5Plan,
    layout: ".",
    wow_duration: "0.00s"
  },
  {
    path: "/UpdateAddOn/:type",
    name: "Update Addon",
    icon: " icon",
    hasMenu: true,
    hasFooter: false,
    hasFilter: false,
    backUrl: "",
    component: UpdateAddOn,
    layout: ".",
    wow_duration: "0.00s"
  },
  {
    path: "/emi-disable-enable/:campId",
    name: "EMIEnable and Disable",
    icon: " icon",
    hasMenu: true,
    hasFooter: false,
    hasFilter: false,
    backUrl: "",
    component: EcsFlow,
    layout: ".",
    wow_duration: "0.00s"
  },
  {
    path: "/bulk-upload",
    name: "Bulk Upload",
    icon: " icon",
    hasMenu: true,
    hasFooter: false,
    hasFilter: false,
    backUrl: "",
    component: BulkUpload,
    layout: ".",
    wow_duration: "0.00s"
  },
  {
    path: "/bulk-upload",
    name: "Bulk Upload",
    icon: " icon",
    hasMenu: true,
    hasFooter: false,
    hasFilter: false,
    backUrl: "",
    component: BulkUpload,
    layout: ".",
    wow_duration: "0.00s"
  },
  {
    path: "/campaign-selection",
    name: "Campaign Selection",
    icon: " icon",
    hasMenu: true,
    hasFooter: false,
    hasFilter: false,
    backUrl: "",
    component: CampaignSelection,
    layout: ".",
    wow_duration: "0.00s"
  },
  {
    path: "/bulk-upload-report",
    name: "Bulk Upload Report",
    icon: " icon",
    hasMenu: true,
    hasFooter: false,
    hasFilter: false,
    backUrl: "",
    component: BulkUploadReport,
    layout: ".",
    wow_duration: "0.00s"
  }
];
export default { sidebarRoute: routes };
