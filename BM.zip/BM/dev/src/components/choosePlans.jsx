import React, { Component } from "react";
import { Link, withRouter } from "react-router-dom";
import { connect } from "react-redux";
import {
  fetchCampaignList,
  fetchTop5Plans,
  updateTop5Plans
} from "./../redux/actions/userActions";
import { ucWords } from "./../utilities/helperFunctions";
import Minipopup from "./common/Minipopup";

class ChoosePlan extends Component {
  constructor(props) {
    super(props);
    this.state = {
      plansObj: {},
      proceedPopup: false,
      showMinipopup: false,
      miniPopupText: "",
      miniPopupTitle: "",
      prevValue: {}
    };

    this.ChoosePlan = this.ChoosePlan.bind(this);
  }

  componentDidMount() {
    console.log("---selelct city arrr", this.props.selectCityArrDetails);
    this.fetchPlans();
  }

  async fetchPlans() {
    let params = {
      city: this.props.selectCityArrDetails[0],
      camp_id: 2
    };
    Promise.all([this.props.fetchTop5Plans(params)]).then(() => {
      this.setState({
        plansObj: this.props.top5Plans,
        prevValue: this.props.top5Plans
      });
    });
  }

  ChoosePlan(e, value) {
    let plan = value;
    let plan_obj = this.state.plansObj;
    plan_obj[value.days].is_active = !value.is_active;
    this.setState({ plansObj: plan_obj });
  }

  closeAlert = () => {
    if (this.state.miniPopupText == "Plans has been succesfully updated") {
      this.props.history.push("/select-users");
      document.getElementsByClassName(
        "hdrWrp hdrDetail hdrWhiteBg"
      )[0].style.visibility = "visible";
    } else {
      this.setState({ showMinipopup: false });
    }
  };
  proceedTo() {
    console.log("selected plan", this.state.plansObj);

    let params = {
      cityNames: this.props.selectCityArrDetails,
      empcode: EMPCODE,
      username: "",
      prev_value: this.state.prevValue,
      camp_id: 2,
      tenure_options: this.state.plansObj
    };

    Promise.all([this.props.updateTop5Plans(params)]).then(() => {
      console.log("updates", this.props.resUpdate);
      if (this.props.resUpdate && this.props.resUpdate.isUpdate == 1) {
        this.setState(
          {
            miniPopupText: "Plans has been succesfully updated",
            showMinipopup: true
          },
          () => {
            document.getElementsByClassName(
              "hdrWrp hdrDetail hdrWhiteBg"
            )[0].style.visibility = "hidden";
          }
        );
        return;
      }
    });
  }

  proceedToNext(type) {
    if (type == "emi") {
      this.props.history.push({
        pathname: "/emi-disable-enable/" + 2,
        state: {
          campid: 2
        }
      });
    } else if (type == "dp") {
      this.props.history.push({
        pathname: "/dpCount/" + 2,
        state: {
          campid: 2
        }
      });
    }
  }

  render() {
    if (this.state.showMinipopup) {
      return (
        <Minipopup
          title={this.state.miniPopupTitle}
          text={this.state.miniPopupText}
          handleOk={this.closeAlert}
          okPopup={true}
        />
      );
    }
    return (
      <div className=" wrapper-block pb-30">
        <div className="wrapper-block ">
          <div className="font14 fw600 pl-20 pr-20 pt-20">
            {" "}
            Selected Cities: {this.props.selectCityArrDetails.join(", ")}{" "}
          </div>

          <div className="pl-20 pr-20 pt-20">
            <ul className="wrapper-block pb-30">
              <li
                className="selUserLi dtable  color363 pl-15  csrpntr"
                onClick={() => this.proceedToNext("emi")}
              >
                <div className="dtablecell">
                  <span className="font14 fw600">EMI disable/enable</span>
                </div>
                <div className="dtablecell rtArrowBx text-right ">
                  <i className="rightBlkarrow icon-common"> </i>
                </div>
              </li>
              {/* <li
                className="selUserLi dtable  color363 pl-15  csrpntr"
                onClick={() => this.proceedToNext("dp")}
              >
                <div className="dtablecell">
                  <span className="font14 fw600">
                    Dp Count

                  </span>
                </div>
                <div className="dtablecell rtArrowBx text-right ">
                  <i className="rightBlkarrow icon-common"> </i>
                </div>
              </li> */}
            </ul>
          </div>

          <div className="font14 color414 fw600 p-20"> Choose Plans </div>
          <div className="wrapper-block pl-20 pr-20 pb-10">
            <div className="animwrap">
              {this.state.plansObj &&
                Object.keys(this.state.plansObj).length > 0 &&
                Object.keys(this.state.plansObj).map((key, index) => {
                  let isChecked = this.state.plansObj[key].is_active;
                  return (
                    <label key={"filtertype_" + index} className="animcheck">
                      <input
                        className="animinput"
                        type="checkbox"
                        value="true"
                        checked={isChecked}
                        onChange={e =>
                          this.ChoosePlan(e, this.state.plansObj[key])
                        }
                      />
                      <div className="animlabel">
                        <span className="animicon"></span>
                        <span className="animtext font16 fw600 color1a1">
                          {" "}
                          {this.state.plansObj[key].tenure_name}{" "}
                        </span>
                      </div>
                    </label>
                  );
                })}
            </div>
          </div>
        </div>
        <div className="btmFixBtn">
          <button
            className="ftrBlueBtn font16"
            onClick={() => this.proceedTo()}
          >
            {" "}
            Update Plan{" "}
          </button>
        </div>
      </div>
    );
  }
}
function mapStateToProps(state, props) {
  return {
    CampaignList: state.jd_store.fetchCampaignListData,
    selectCityArrDetails: state.jd_store.selectCityArrData,
    top5Plans: state.jd_store.fetchTop5Plans,
    resUpdate: state.jd_store.updateTop5Plans
  };
}

const mapDispatchToProps = dispatch => {
  return {
    fetchCampaignList: params => dispatch(fetchCampaignList(params)),
    fetchTop5Plans: params => dispatch(fetchTop5Plans(params)),
    updateTop5Plans: params => dispatch(updateTop5Plans(params))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ChoosePlan);
