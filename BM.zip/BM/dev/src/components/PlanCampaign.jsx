import React, { Component } from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";

class SelectPlanCampaign extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  singleSelection() {
    this.setState({
      single: event.target.checked
    });
  }
  mutipleSelection() {
    this.setState({
      multiple: event.target.checked
    });
  }

  render() {
    return (
      <div className=" wrapper-block pb-30">
        <div className="font14 color414 fw600 pl-20 pr-20 pt-20">
          {" "}
          Please Select Plan{" "}
        </div>
        <div className="wrapper-block pl-20 pr-20 pt-20">
          <ul className="typeAWrp wrapper-block ">
            <li className="selUserLi dtable  color1a1 pl-15  csrpntr">
              <div className="dtable pb-20">
                <div className="dtablecell">
                  <span className="font14 fw600">Single </span>
                </div>
                <div className="dtablecell switchwidth text-right">
                  <label className="dtablecell switch">
                    <input
                      type="checkbox"
                      onClick={() => this.singleSelection()}
                    />
                    <span className="slider"></span>
                  </label>
                </div>
              </div>
            </li>

            <li className="selUserLi dtable  color1a1 pl-15  csrpntr">
              <div className="dtable pb-20">
                <div className="dtablecell">
                  <span className="font14 fw600">Multiple </span>
                </div>
                <div className="dtablecell switchwidth text-right">
                  <label className="dtablecell switch">
                    <input
                      type="checkbox"
                      value="emi_plan"
                      onClick={() => this.mutipleSelection()}
                    />
                    <span className="slider"></span>
                  </label>
                </div>
              </div>
            </li>
          </ul>
        </div>
        {this.state.single ? (
          <div className="wrapper-block p-20">
            <ul className="wrapper-block pb-30">
              <li className="selUserLi dtable  color363 pl-15  csrpntr">
                <div className="dtablecell">
                  <span className="font14 fw600">Single </span>
                </div>
                <div className="dtablecell rtArrowBx text-right ">
                  <Link to={"/UpdatePlanCampaign/single"}>
                    {" "}
                    <i className="rightBlkarrow icon-common"> </i>
                  </Link>
                </div>
              </li>
            </ul>
          </div>
        ) : (
          ""
        )}
        {this.state.multiple ? (
          <div className="wrapper-block p-20">
            <ul className="wrapper-block pb-30">
              <li className="selUserLi dtable  color363 pl-15  csrpntr">
                <div className="dtablecell">
                  <span className="font14 fw600"> Basic </span>
                </div>
                <div className="dtablecell rtArrowBx text-right ">
                  <Link to={"/UpdatePlanCampaign/Basic"}>
                    {" "}
                    <i className="rightBlkarrow icon-common"> </i>
                  </Link>
                </div>
              </li>
              <li className="selUserLi dtable  color363 pl-15  csrpntr">
                <div className="dtablecell">
                  <span className="font14 fw600"> Standard </span>
                </div>
                <div className="dtablecell rtArrowBx text-right ">
                  <Link to={"/UpdatePlanCampaign/Standard"}>
                    {" "}
                    <i className="rightBlkarrow icon-common"> </i>
                  </Link>
                </div>
              </li>
              <li className="selUserLi dtable  color363 pl-15  csrpntr">
                <div className="dtablecell">
                  <span className="font14 fw600"> Premium </span>
                </div>
                <div className="dtablecell rtArrowBx text-right ">
                  <Link to={"/UpdatePlanCampaign/Premium"}>
                    {" "}
                    <i className="rightBlkarrow icon-common"> </i>
                  </Link>
                </div>
              </li>
            </ul>
          </div>
        ) : (
          ""
        )}
      </div>
    );
  }
}
function mapStateToProps(state, props) {
  return {
    // CampaignList: state.jd_store.fetchCampaignListData
  };
}

const mapDispatchToProps = dispatch => {
  return {
    // fetchCampaignList: (params) => dispatch(fetchCampaignList(params)),
    // activeInactiveCampaign: (params) => dispatch(activeInactiveCampaign(params))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(SelectPlanCampaign);
// export default SelectCampaign;
