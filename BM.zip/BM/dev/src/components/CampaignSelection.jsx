import React, { Component } from "react";
import { Link } from "react-router-dom";
import { withRouter } from "react-router-dom";
import Minipopup from "./common/Minipopup";
import {
  fetchCampaignList,
  activeInactiveCampaign,
  bulkUploadBudget,
  getCampTenure
} from "./../redux/actions/userActions";
import { connect } from "react-redux";
import { ComponentLoader } from "./common/ComponentLoader";

class BulkUpload extends Component {
  constructor(props) {
    super(props);
    this.state = {
      resSqlQueryForAddOns: [],
      resSqlQueryForAll: [],
      resSqlQueryForNational: [],
      resSqlQueryForOthers: [],
      // isTempBudget: false,
      resInactiveCampaigns: [],
      selectedCamps: [],
      packageCampaign: {},
      isProceed: false,
      isPackage: false,
      alertPop: 0,
      alertMsg: "",
      Loader: false
    };
    this.popupHandleOk = this.popupHandleOk.bind(this);
  }
  componentDidMount() {
    this.fetchCampaignListHandler();
  }

  fetchCampaignListHandler = () => {
    let params = {
      selectedCity: localStorage.getItem("datacity")
    };
    this.setState({ Loader: true });
    Promise.all([this.props.fetchCampaignList(params)]).then(() => {
      if (this.props.CampaignList && this.props.CampaignList.data) {
        console.log(
          "console.log(this.state.resSqlQueryForAll)",
          this.props.CampaignList.data
        );
        const arr = this.props.CampaignList.data.resSqlQueryForAll;
        var obj = {
          arr
        };
        var variantObj = obj.arr.filter(function(el) {
          return el.campid >= 54 && el.campid < 57;
        });

        this.setState({
          resSqlQueryForAddOns: this.props.CampaignList.data
            .resSqlQueryForAddOns,
          resSqlQueryForAll: this.props.CampaignList.data.resSqlQueryForAll,
          resSqlQueryForNational: this.props.CampaignList.data
            .resSqlQueryForNational,
          resSqlQueryForOthers: this.props.CampaignList.data
            .resSqlQueryForOthers,
          packageCampaign: variantObj,
          Loader: false
        });
      }
    });
  };

  selectCamp(e, campId, campname) {
    let selectedCamps = [];
    let index;
    if (campId == 54 && !this.state.isPackage) {
      this.setState({ isPackage: true });
    } else {
      if (selectedCamps.includes(campId)) {
        index = selectedCamps.indexOf(campId);
        selectedCamps.splice(index, 1);
      } else {
        index = selectedCamps.indexOf(campId);
        selectedCamps.push(campId);
      }
      console.log("selected camp", selectedCamps, campname);
      this.setState({
        selectedCamps,
        isProceed: selectedCamps.length > 0,
        campname
      });
    }
  }

  checkCampDuration(arr) {
    let count = 0;
    for (let i = 0; i < arr.length; i++) {
      if (arr[i]["Tenure (Days)"] == 1825 || arr[i]["Tenure (Days)"] == 730) {
        count++;
      }
    }
    return count;
  }

  async submit() {
    this.setState({ isProceed: 0, Loader: true });

    try {
      if (JSON.parse(localStorage.getItem("bulkUploadData"))) {
        let data = JSON.parse(localStorage.getItem("bulkUploadData"));
        let checkDuration = this.checkCampDuration(data["data"]);
        console.log("check duartion", checkDuration);
        if (
          (this.state.selectedCamps[0] == 54 ||
            this.state.selectedCamps[0] == 55 ||
            this.state.selectedCamps[0] == 56) &&
          checkDuration > 0
        ) {
          this.setState({
            Loader: false,
            alertPop: 1,
            alertMsg: "Only 1 year tenur option is allowed for selected package"
          });
          return false;
        }
        console.log("data to upload", this.state.campname);
        let cities = {};
        console.log("cities", cities);
        let reObj = {
          ...data,
          campId: this.state.selectedCamps[0],
          campname: this.state.campname
        };
        let res = await bulkUploadBudget(reObj);
        console.log("res", res);
        if (res && res["errorCode"] == 0) {
          if (
            res &&
            res.data.cities &&
            res.data.cities.failedcities &&
            res.data.cities.failedcities.length > 0
          ) {
            cities = res.data.cities;
          }
          this.setState({ Loader: false });
          this.props.history.push({
            pathname: "/bulk-upload-report",
            state: {
              data: { ...reObj, ...cities }
            }
          });
        } else {
          this.setState({ alertPop: 0, alertMsg: "Something went wrong." });
        }
      }
    } catch (err) {
      console.log("err", err);
    }
  }
  popupHandleOk() {
    this.props.history.push("/bulk-upload");
  }

  hidePop() {
    let selectedCamps = this.state.selectedCamps;
    selectedCamps.pop();
    this.setState({ selectedCamps, isProceed: false });
  }

  render() {
    const { isProceed, isPackage, alertPop, alertMsg, Loader } = this.state;
    let thisObj = this;
    console.log("selected camp", this.state.packageCampaign);
    return (
      <>
        {Loader == 1 ? (
          <ComponentLoader LoaderName="DashboardLoader" />
        ) : (
          <div>
            {this.props.CampaignList &&
            this.props.CampaignList.data &&
            !isPackage ? (
              <div className="campaignslctwpr newcampaign_wpr">
                <div className="campaignlistwpr">
                  <ul className="campaignlist">
                    {this.state.resSqlQueryForAll.map((newVal, newKey) => {
                      let isChecked = this.state.selectedCamps.includes(
                        newVal.campid
                      )
                        ? true
                        : false;

                      return (
                        <div key={newKey} style={{ marginBottom: 15 }}>
                          {newVal.campid == "54" && (
                            <li>
                              <label>
                                <span className="campaignlistcell">
                                  <i className="gno_packagelisting"></i>
                                </span>
                                <span className="campaignlistcell font14">
                                  {newVal.campname}
                                </span>
                                <span className="campaignlistcell">
                                  <span className="campaignlist_checkbox">
                                    <input
                                      type="checkbox"
                                      value={true}
                                      checked={isChecked}
                                      onChange={e =>
                                        this.selectCamp(
                                          e,
                                          newVal.campid,
                                          newVal.campname
                                        )
                                      }
                                    />
                                    <span className="checkbox_circle"></span>
                                  </span>
                                </span>
                              </label>
                            </li>
                          )}
                          {/* {
                                                    newVal.campid == "2" && <li>
                                                        <label>
                                                            <span className="campaignlistcell">
                                                                <i className="gno_packagelisting"></i>
                                                            </span>
                                                            <span className="campaignlistcell font14">{newVal.campname}</span>
                                                            <span className="campaignlistcell">
                                                                <span className="campaignlist_checkbox" >
                                                                    <input type="checkbox" name="" checked={isChecked} value={true} onChange={(e) => this.selectCamp(e, newVal.campid, newVal.campname)} />
                                                                    <span className="checkbox_circle"></span>
                                                                </span>
                                                            </span>
                                                        </label>
                                                    </li>
                                                } */}
                          {newVal.campid == "96" && (
                            <li>
                              <label>
                                <span className="campaignlistcell">
                                  <i className="gno_packagelisting"></i>
                                </span>
                                <span className="campaignlistcell font14">
                                  {newVal.campname}
                                </span>
                                <span className="campaignlistcell">
                                  <span className="campaignlist_checkbox">
                                    <input
                                      type="checkbox"
                                      name=""
                                      checked={isChecked}
                                      value={true}
                                      onChange={e =>
                                        this.selectCamp(
                                          e,
                                          newVal.campid,
                                          newVal.campname
                                        )
                                      }
                                    />
                                    <span className="checkbox_circle"></span>
                                  </span>
                                </span>
                              </label>
                            </li>
                          )}
                        </div>
                      );
                    })}
                  </ul>
                </div>
                <div className="campaignlistwpr">
                  <div className="campaignlistwpr_outer">
                    <div className="campaignlist_title font14">Add-on</div>
                    <ul className="campaignlist">
                      {this.state.resSqlQueryForAddOns.map(
                        (childVal, newKey) => {
                          let isChecked = this.state.selectedCamps.includes(
                            childVal.campid
                          )
                            ? true
                            : false;
                          return (
                            <div key={newKey}>
                              <li>
                                <label>
                                  <span className="campaignlistcell">
                                    <i className="gno_jdtrustedseal"></i>
                                  </span>
                                  <span className="campaignlistcell font14">
                                    {childVal.campname}{" "}
                                  </span>
                                  <span className="campaignlistcell">
                                    <span className="campaignlist_checkbox">
                                      <input
                                        type="checkbox"
                                        name=""
                                        checked={isChecked}
                                        value="true"
                                        onChange={e =>
                                          this.selectCamp(
                                            e,
                                            childVal.campid,
                                            childVal.campname
                                          )
                                        }
                                      />
                                      <span className="checkbox_circle"></span>
                                    </span>
                                  </span>
                                </label>
                              </li>
                            </div>
                          );
                        }
                      )}
                    </ul>
                  </div>
                </div>
              </div>
            ) : this.state.packageCampaign && isPackage ? (
              <div className="campaignslctwpr newcampaign_wpr">
                <div className="campaignlistwpr">
                  <ul className="campaignlist">
                    {this.state.packageCampaign.map((newVal, newKey) => {
                      let isChecked = this.state.selectedCamps.includes(
                        newVal.campid
                      )
                        ? true
                        : false;

                      return (
                        <div key={newKey} style={{ marginBottom: 15 }}>
                          {
                            <li>
                              <label>
                                <span className="campaignlistcell">
                                  <i className="gno_packagelisting"></i>
                                </span>
                                <span className="campaignlistcell font14">
                                  {newVal.campid == "54"
                                    ? "Standard"
                                    : newVal.campname}
                                </span>
                                <span className="campaignlistcell">
                                  <span className="campaignlist_checkbox">
                                    <input
                                      type="checkbox"
                                      value={true}
                                      checked={isChecked}
                                      onChange={e =>
                                        this.selectCamp(
                                          e,
                                          newVal.campid,
                                          newVal.campname
                                        )
                                      }
                                    />
                                    <span className="checkbox_circle"></span>
                                  </span>
                                </span>
                              </label>
                            </li>
                          }
                        </div>
                      );
                    })}
                  </ul>
                </div>
              </div>
            ) : (
              ""
            )}
          </div>
        )}

        {isProceed && (
          <div className="bulkupload_popup_wpr">
            <div className="bulkupload_popup_outer p-20">
              <div className="font13 color1a1">
                Are you sure, you want to update the budget
              </div>

              <div className="yesnobtn_wpr mt-30">
                <button
                  onClick={() => {
                    this.submit();
                  }}
                >
                  Yes
                </button>{" "}
                <button className="nobtn ml-20" onClick={() => this.hidePop()}>
                  No
                </button>
              </div>
            </div>
          </div>
        )}
        {alertPop == 1 && (
          <Minipopup
            text={alertMsg}
            handleOk={this.popupHandleOk}
            okPopup={true}
          />
        )}
      </>
    );
  }
}

function mapStateToProps(state, props) {
  return {
    CampaignList: state.jd_store.fetchCampaignListData,
    selectCityArrDetails: state.jd_store.selectCityArrData
  };
}

const mapDispatchToProps = dispatch => {
  return {
    fetchCampaignList: params => dispatch(fetchCampaignList(params)),
    activeInactiveCampaign: params => dispatch(activeInactiveCampaign(params))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(BulkUpload);
