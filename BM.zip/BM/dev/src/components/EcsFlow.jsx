import React, { Component } from "react";
import { Link, withRouter } from "react-router-dom";
import { connect } from "react-redux";
import {
  fetchEcsAllowed,
  updateEcsData,
  fetchEcsPremiumPackage,
  updateEcsPremium
} from "./../redux/actions/userActions";
import Minipopup from "./common/Minipopup";

class EcsFlow extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ecsData: null,
      newTenure: {},
      oldTenure: {},
      showMinipopup: false,
      miniPopupText: "",
      miniPopupTitle: "",
      newPreminum: {},
      oldPremium: {},
      block_combo_old: 0,
      block_combo_new: 0,
      isCombo: false,
      ecs_allowed_standalone_old: 0,
      ecs_allowed_standalone_new: 0
    };
  }

  componentDidMount() {
    this.fetchData();
  }

  // fetch data

  async fetchData() {
    try {
      console.log("*props data*", this.props);
      const payload = {
        data_city: this.props.selectCityArrDetails[0],
        campId: this.props.match.params.campId
      };

      // premium package

      if (this.props.match.params.campId == 54) {
        Promise.all([
          this.props.fetchEcsPremiumPackage(payload),
          this.props.fetchEcsAllowed(payload)
        ]).then(() => {
          console.log(
            "**response premium***",
            this.props.ecsPremiumData,
            this.props.ecsAllowedData
          );
          this.setState({
            newPreminum: this.props.ecsPremiumData,
            oldPremium: this.props.ecsPremiumData
          });
          this.setState({
            block_combo_new: this.props.ecsAllowedData[0].block_ecs_combo,
            block_combo_old: this.props.ecsAllowedData[0].block_ecs_combo
          });
        });
      }
      // stand alone
      if (
        this.props.match.params.campId == 103 ||
        this.props.match.params.campId == 104 ||
        this.props.match.params.campId == 111
      ) {
        Promise.all([this.props.fetchEcsAllowed(payload)]).then(() => {
          console.log("**response stand alone***", this.props.ecsAllowedData);

          this.setState({
            ecs_allowed_standalone_new: this.props.ecsAllowedData[0]
              .ecs_allowed,
            ecs_allowed_standalone_old: this.props.ecsAllowedData[0].ecs_allowed
          });
        });
      }
      // other pacakge
      else {
        Promise.all([this.props.fetchEcsAllowed(payload)]).then(() => {
          console.log(
            "==>response from ecs allowed==>",
            this.props.ecsAllowedData
          );

          let temp = {};
          const tenureRes = JSON.parse(
            this.props.ecsAllowedData[0].tenure_option
          );
          this.setState({ oldTenure: tenureRes });
          Object.keys(tenureRes).map(ele => {
            if (tenureRes[ele]["ecs_allowed"] != 5) {
              temp[ele] = tenureRes[ele];
            }
          });
          delete tenureRes["downsell_allowed"];
          console.log("tenure options", temp);
          this.setState({ newTenure: temp });
          this.setState({ ecsData: this.props.ecsAllowedData[0] });
        });
      }
    } catch (err) {
      console.log("err", err);
    }
  }

  choosePlan(key, value, type) {
    console.log("value", value);
    if (type == "premium") {
      let newPreminum = this.state.newPreminum;
      newPreminum[key] = !value;
      this.setState({ newPreminum });
    } else if (type == "combo") {
      value = value == 0 ? 1 : 0;
      this.setState({ block_combo_new: value, isCombo: true });
    } else if (type == "stand") {
      value = value == 0 ? 1 : 0;
      this.setState({ ecs_allowed_standalone_new: value });
    } else {
      let _obj = this.state.newTenure;
      _obj[key].ecs_allowed = value == 0 ? 1 : 0;
      this.setState({ newTenure: _obj });
    }
  }

  async updateEcsData() {
    try {
      const { campId } = this.props.match.params;

      if (campId == 54 && this.state.isCombo) {
        let reqPay = {
          cityNames: this.props.selectCityArrDetails,
          empcode: EMPCODE,
          username: "",
          prev_value: this.state.block_combo_old,
          camp_id: this.props.match.params.campId,
          new_value: this.state.block_combo_new,
          isCombo: true
        };

        Promise.all([this.props.updateEcsData(reqPay)]).then(() => {
          return;
        });
      }
      if (
        this.props.match.params.campId == 103 ||
        this.props.match.params.campId == 104 ||
        this.props.match.params.campId == 111
      ) {
        console.log(
          "update",
          this.state.ecs_allowed_standalone_old,
          this.state.ecs_allowed_standalone_new
        );
        let reqPay = {
          cityNames: this.props.selectCityArrDetails,
          empcode: EMPCODE,
          username: "",
          prev_value: this.state.ecs_allowed_standalone_old,
          camp_id: this.props.match.params.campId,
          new_value: this.state.ecs_allowed_standalone_new
        };
        Promise.all([this.props.updateEcsData(reqPay)]).then(() => {
          if (this.props.ecsRes && this.props.ecsRes.isUpdate == 1) {
            this.setState(
              {
                miniPopupText: "Tenure has been succesfully updated",
                showMinipopup: true
              },
              () => {
                document.getElementsByClassName(
                  "hdrWrp hdrDetail hdrWhiteBg"
                )[0].style.visibility = "hidden";
              }
            );
            return;
          }
        });
      }

      if (campId == 54) {
        console.log("old value new value", this.state.newPreminum);
        let reqPay = {
          cityNames: this.props.selectCityArrDetails,
          empcode: EMPCODE,
          username: "",
          prev_value: this.state.oldPremium,
          camp_id: this.props.match.params.campId,
          new_value: this.state.newPreminum
        };
        Promise.all([this.props.updateEcsPremium(reqPay)]).then(() => {
          if (
            this.props.ecsPremiumUpdateRes &&
            this.props.ecsPremiumUpdateRes.isUpdate == 1
          ) {
            this.setState(
              {
                miniPopupText: "Tenure has been succesfully updated",
                showMinipopup: true
              },
              () => {
                document.getElementsByClassName(
                  "hdrWrp hdrDetail hdrWhiteBg"
                )[0].style.visibility = "hidden";
              }
            );
            return;
          }
        });
      }
      if (
        this.props.match.params.campId != 103 &&
        this.props.match.params.campId != 104 &&
        this.props.match.params.campId != 111 &&
        !this.state.isCombo &&
        campId != 54
      ) {
        console.log("update else");
        const payload = {
          cityNames: this.props.selectCityArrDetails,
          empcode: EMPCODE,
          username: "",
          prev_value: JSON.stringify(this.state.oldTenure),
          camp_id: this.props.match.params.campId,
          new_value: JSON.stringify({
            ...this.state.oldTenure,
            ...this.state.newTenure
          })
        };
        Promise.all([this.props.updateEcsData(payload)]).then(() => {
          if (this.props.ecsRes && this.props.ecsRes.isUpdate == 1) {
            this.setState(
              {
                miniPopupText: "Tenure has been succesfully updated",
                showMinipopup: true
              },
              () => {
                document.getElementsByClassName(
                  "hdrWrp hdrDetail hdrWhiteBg"
                )[0].style.visibility = "hidden";
              }
            );
            return;
          }
        });
      }
    } catch (err) {
      console.log("err", err);
    }
  }

  closeAlert = () => {
    if (this.state.miniPopupText == "Tenure has been succesfully updated") {
      this.props.history.push("/select-users");
      document.getElementsByClassName(
        "hdrWrp hdrDetail hdrWhiteBg"
      )[0].style.visibility = "visible";
    } else {
      this.setState({ showMinipopup: false });
    }
  };

  render() {
    const { campId } = this.props.match.params;
    if (this.state.showMinipopup) {
      return (
        <Minipopup
          title={this.state.miniPopupTitle}
          text={this.state.miniPopupText}
          handleOk={this.closeAlert}
          okPopup={true}
        />
      );
    }
    const isShowEmi =
      campId == 111
        ? true
        : campId == 103
        ? true
        : campId == 104
        ? true
        : false;
    return (
      <>
        <div className="p-20">
          <div className="font14 color111 pb-15">
            Selected Cities: {this.props.selectCityArrDetails.join(", ")}
          </div>

          {/* stand alone */}
          {isShowEmi && (
            <div className="slct_tnur_wpr pt-20 pb-20 pl-15 pr-15">
              <div className="color111 font14 pb-10 text_center">
                Select Tenure
              </div>
              <ul className="font14 color111">
                <li>
                  <div className="dtable">
                    <div className="dtablecell">
                      <span className="font14 fw600"> EMI </span>
                    </div>
                    <div className="dtablecell switchwidth text-right">
                      <label className="dtablecell switch">
                        <input
                          type="checkbox"
                          value="true"
                          checked={
                            this.state.ecs_allowed_standalone_new == 1
                              ? true
                              : false
                          }
                          onChange={e =>
                            this.choosePlan(
                              null,
                              this.state.ecs_allowed_standalone_new,
                              "stand"
                            )
                          }
                        />
                        <span className="slider"></span>
                      </label>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          )}

          {/* other package */}
          {Object.keys(this.state.newTenure).length > 0 ||
          Object.keys(this.state.newPreminum).length > 0 ? (
            <div className="slct_tnur_wpr pt-20 pb-20 pl-15 pr-15">
              <div className="color111 font14 pb-10 text_center">
                Select Tenure
              </div>
              <ul className="font14 color111">
                {campId == 54
                  ? Object.keys(this.state.newPreminum).map((item, index) => {
                      return (
                        <li key={index}>
                          <div className="dtable">
                            <div className="dtablecell">
                              <span className="font14 fw600">
                                {" "}
                                {item / 365 + " Year"}{" "}
                              </span>
                            </div>
                            <div className="dtablecell switchwidth text-right">
                              <label className="dtablecell switch">
                                <input
                                  type="checkbox"
                                  value="true"
                                  checked={this.state.newPreminum[item]}
                                  onChange={e =>
                                    this.choosePlan(
                                      item,
                                      this.state.newPreminum[item],
                                      "premium"
                                    )
                                  }
                                />
                                <span className="slider"></span>
                              </label>
                            </div>
                          </div>
                        </li>
                      );
                    })
                  : Object.keys(this.state.newTenure).map((item, index) => {
                      if (item == 12) {
                        return (
                          <li key={index}>
                            <div className="dtable">
                              <div className="dtablecell">
                                <span className="font14 fw600">
                                  {" "}
                                  {item >= 12
                                    ? item / 12 + " Year"
                                    : item + " Months"}{" "}
                                </span>
                              </div>
                              <div className="dtablecell switchwidth text-right">
                                <label className="dtablecell switch">
                                  <input
                                    type="checkbox"
                                    value="true"
                                    checked={
                                      this.state.newTenure[item][
                                        "ecs_allowed"
                                      ] == 1
                                        ? true
                                        : false
                                    }
                                    onChange={e =>
                                      this.choosePlan(
                                        item,
                                        this.state.newTenure[item][
                                          "ecs_allowed"
                                        ]
                                      )
                                    }
                                  />
                                  <span className="slider"></span>
                                </label>
                              </div>
                            </div>
                          </li>
                        );
                      }
                    })}
                {campId == 54 && (
                  <li>
                    <div className="dtable">
                      <div className="dtablecell">
                        <span className="font14 fw600"> Combo package </span>
                      </div>
                      <div className="dtablecell switchwidth text-right">
                        <label className="dtablecell switch">
                          <input
                            type="checkbox"
                            value="true"
                            checked={
                              this.state.block_combo_new == 0 ? true : false
                            }
                            onChange={e =>
                              this.choosePlan(
                                null,
                                this.state.block_combo_new,
                                "combo"
                              )
                            }
                          />
                          <span className="slider"></span>
                        </label>
                      </div>
                    </div>
                  </li>
                )}
              </ul>
            </div>
          ) : (
            !isShowEmi && (
              <div
                style={{ textAlign: "center" }}
                className="font14 fw600 pl-20 pr-20 pt-20"
              >
                No data found
              </div>
            )
          )}
        </div>

        <div className="updatebtn_wpr">
          <button className="font16" onClick={() => this.updateEcsData()}>
            Update
          </button>
        </div>
      </>
    );
  }
}
function mapStateToProps(state, props) {
  return {
    ecsAllowedData: state.jd_store.ecsAllowedData,
    selectCityArrDetails: state.jd_store.selectCityArrData,
    ecsRes: state.jd_store.ecsRes,
    ecsPremiumData: state.jd_store.ecsPremiumData,
    ecsPremiumUpdateRes: state.jd_store.ecsPremiumUpdateRes
  };
}

const mapDispatchToProps = dispatch => {
  return {
    fetchEcsAllowed: params => dispatch(fetchEcsAllowed(params)),
    fetchEcsPremiumPackage: params => dispatch(fetchEcsPremiumPackage(params)),
    updateEcsData: params => dispatch(updateEcsData(params)),
    updateEcsPremium: params => dispatch(updateEcsPremium(params))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(EcsFlow);
