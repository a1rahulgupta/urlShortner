import React, { Component } from "react";
import { connect } from "react-redux";
import ErrorPage from "./common/ErrorPage.jsx";
import SearchBar from "./common/SearchBar.jsx";
import { ComponentLoader, ContentLoader } from "./common/ComponentLoader";
import { ucWords } from "./../utilities/helperFunctions";

import { applyFilters } from "./../redux/actions/userActions";

class Filter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      FilterLoader: true,
      hasError: false,
      filter_campaign: [],
      filter_type: [],
      filter_source: []
    };
  }

  componentDidMount() {
    this.setState({ FilterLoader: false });
  }
  static getDerivedStateFromError(error) {
    // Update state so the next render will show the fallback UI.
    return { hasError: true };
  }
  filterByCampaign = type => {
    let filterArray = this.state.filter_campaign;
    if (filterArray.includes(type)) {
      let index = filterArray.indexOf(type);
      filterArray.splice(index, 1);
    } else {
      filterArray.push(type);
    }
    // console.log(filterArray);

    this.setState({ filter_campaign: filterArray });
  };
  filterByType = type => {
    let filterArray = this.state.filter_type;
    if (filterArray.includes(type)) {
      let index = filterArray.indexOf(type);
      filterArray.splice(index, 1);
    } else {
      filterArray.push(type);
    }
    // console.log(filterArray);

    this.setState({ filter_type: filterArray });
  };
  filterBySource = type => {
    let filterArray = this.state.filter_source;
    if (filterArray.includes(type)) {
      let index = filterArray.indexOf(type);
      filterArray.splice(index, 1);
    } else {
      filterArray.push(type);
    }
    // console.log(filterArray);

    this.setState({ filter_source: filterArray });
  };

  clearFilters = () => {
    Promise.all([
      this.props.applyFilters({
        filter_campaign: [],
        filter_type: [],
        filter_source: []
      })
    ]).then(() => {
      this.setState({
        filter_campaign: [],
        filter_type: [],
        filter_source: []
      });
    });
  };
  applyFilters = () => {
    this.props.applyFilters({
      filter_campaign: this.state.filter_campaign,
      filter_type: this.state.filter_type,
      filter_source: this.state.filter_source
    });
  };

  render() {
    if (this.state.hasError) {
      // You can render any custom fallback UI
      return <h1>Something went wrong.</h1>;
    }
    console.log(this.props);

    const { error, loading, user, location, history } = this.props;
    var component_error = this.props.component_error || null;
    // if (error) {
    // 	return <ErrorPage error={error} />;
    // }
    // if (loading || this.state.FilterLoader == true) {
    // 	return <ComponentLoader LoaderName="FilterLoader" />;
    // }

    var empcode = user.empcode || "";
    var that = this;
    var campaignList = [
      "Fixed Position",
      "Supreme Campaigns",
      "National Listing",
      "Jd Verified",
      "Jd Trusted",
      "JDRR Certificate",
      "Banner National Listing",
      "Booster",
      "Rotaional Web banner",
      "Rotaional Mobile banner",
      "Your Own Website",
      "Android App",
      "Iphone App",
      "SMS Promo"
    ];
    var filterTypes = ["mask", "freez"];
    var filterSources = {
      "Join Free": "joinfree_campaign",
      "Ad Programs": "adprograms_campaign",
      "Web Edit Listing": "webeditlistin_campaign",
      "IRO Deferred": "irodeferred_campaign",
      "searches SMS": "searchesSmsEm_campaign"
    };

    return (
      <div>
        <div className="divider" />
        <div className="filterwpr">
          <div className="filterprnt">
            <div className="filtertitle font13">Campaigns</div>
            <ul className="fltrtabs font12">
              {Object.values(campaignList).map((campaign, key) => {
                let isActive = this.state.filter_campaign.includes(campaign)
                  ? "active"
                  : "";
                return (
                  <li
                    className={isActive}
                    key={"campaign_" + key}
                    onClick={() => this.filterByCampaign(campaign)}
                  >
                    {campaign}
                  </li>
                );
              })}
            </ul>
          </div>
          <div className="filterprnt">
            <div className="filtertitle font13">By Type</div>
            <ul className="fltrtabs font12">
              {Object.values(filterTypes).map((filterType, key) => {
                let isActive = this.state.filter_type.includes(filterType)
                  ? "active"
                  : "";
                return (
                  <li
                    className={isActive}
                    key={"filtertype_" + key}
                    onClick={() => this.filterByType(filterType)}
                  >
                    {ucWords(filterType)}
                  </li>
                );
              })}
            </ul>
          </div>
          {location.pathname == "/assignments/hot-data" && (
            <div className="filterprnt">
              <div className="filtertitle font13">By Source</div>
              <ul className="fltrtabs font12">
                {Object.keys(filterSources).map((filterSourceKey, index) => {
                  let filterSourceValue = filterSources[filterSourceKey];
                  let isActive = this.state.filter_source.includes(
                    filterSourceValue
                  )
                    ? "active"
                    : "";
                  return (
                    <li
                      className={isActive}
                      key={"source_" + filterSourceValue}
                      onClick={() => this.filterBySource(filterSourceValue)}
                    >
                      {ucWords(filterSourceKey)}
                    </li>
                  );
                })}
              </ul>
            </div>
          )}
        </div>
        <div className="fltrbtnswpr" style={{ bottom: "55px" }}>
          <button
            className="fltrbtns font16"
            onClick={() => this.clearFilters()}
          >
            Clear
          </button>
          <button
            className="fltrbtns font16 fltrbluebtns"
            onClick={() => this.applyFilters()}
          >
            Apply
          </button>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    empcode: state.jd_store.empcode,
    user: state.jd_store.user,
    contract_filter: state.jd_store.contract_filter
  };
}

const mapDispatchToProps = dispatch => {
  return {
    // dispatching plain actions
    applyFilters: params => dispatch(applyFilters(params))
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Filter);
