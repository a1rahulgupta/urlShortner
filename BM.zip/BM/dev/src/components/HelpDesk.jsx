import React, { Component } from "react";
import { connect } from "react-redux";
import ErrorPage from "./common/ErrorPage.jsx";
import { ComponentLoader, ContentLoader } from "./common/ComponentLoader";

import Dropzone from "react-dropzone";
const Compress = require("compress.js");

class HelpDesk extends Component {
  constructor(props) {
    super(props);
    this.state = {
      Loader: true,
      hasError: false,
      helpdeskForm: {
        email: this.props.user.email_id,
        mobile: this.props.user.mobile_num,
        city: this.props.user.city,
        subject: "",
        message: "",
        photo: ""
      },
      filePath: ""
    };
  }

  componentDidMount() {
    this.setState({ Loader: false });
  }
  static getDerivedStateFromError(error) {
    // Update state so the next render will show the fallback UI.
    return { hasError: true };
  }
  formChangetHandler = (e, type) => {
    console.log(type, e);

    let newVals = this.state.helpdeskForm;
    // e.preventDefault();
    //let val = e.target.value;
    //	console.log(e.target.files);

    switch (type) {
      case "email":
        newVals.email = e.target.value;
        this.setState({ helpdeskForm: newVals });
        break;
      case "city":
        newVals["city"] = e.target.value;
        this.setState({ helpdeskForm: newVals });
        break;
      case "mobile":
        newVals.mobile = e.target.value;
        this.setState({ helpdeskForm: newVals });
        break;
      case "subject":
        newVals.subject = e.target.value;
        this.setState({ helpdeskForm: newVals });
        break;
      case "message":
        newVals.message = e.target.value;
        this.setState({ helpdeskForm: newVals });
        break;
      case "photo":
        let thisObj = this;
        let reader = new FileReader();
        reader.readAsDataURL(e.target.files[0]);
        reader.onload = function(e) {
          newVals.photo = reader.result;
          thisObj.setState({ helpdeskForm: newVals });
        };
        break;
    }
  };
  formSubmitHandler() {
    let thisObj = this;
    for (let val in this.state.helpdeskForm) {
      if (thisObj.state.helpdeskForm[val] == "" && val != "photo") {
        alert(`Please enter ${val}`);
        return false;
      }
    }
  }

  render() {
    if (this.state.hasError) {
      // You can render any custom fallback UI
      return <h1>Something went wrong.</h1>;
    }
    console.log(this.props);

    const { error, loading, user } = this.props;
    var component_error = this.props.component_error || null;
    if (error) {
      return <ErrorPage error={error} />;
    }
    if (loading || this.state.Loader == true) {
      return <ComponentLoader LoaderName="Loader" />;
    }

    var empcode = user.empcode || "";
    var that = this;
    const { history } = this.props;
    return (
      <>
        <div>
          <div className="divider" />
          <div className="helpdeskwpr">
            <div className="helpdesktitle font14">
              For all your genio/geniolite related queries
            </div>
            <div className="helpdeskform">
              <div className="group">
                <input
                  className="inputMaterial font16 inputdisabled"
                  type="text"
                  onChange={e => this.formChangetHandler(e, "email")}
                  value={this.props.user.email_id}
                />
                <span className="bar" />
                <label className="label-wrap font16">Email (From)</label>
              </div>
              <div className="group">
                <input
                  className="inputMaterial font16 inputdisabled"
                  type="text"
                  onChange={e => this.formChangetHandler(e, "mobile")}
                  value={this.props.user.mobile_num}
                />
                <span className="bar" />
                <label className="label-wrap font16">Contact Number</label>
              </div>
              <div className="group">
                <input
                  className="inputMaterial font16 inputdisabled"
                  type="text"
                  onChange={e => this.formChangetHandler(e, "city")}
                  value={this.props.user.city}
                />
                <span className="bar" />
                <label className="label-wrap font16">City Name</label>
              </div>
              <div className="group">
                <input
                  className="inputMaterial font16"
                  type="text"
                  onChange={e => this.formChangetHandler(e, "subject")}
                />
                <span className="bar" />
                <label className="label-wrap font16">
                  Enter Subject of your message
                </label>
              </div>
              <div className="group">
                <input
                  className="inputMaterial font16"
                  type="text"
                  onChange={e => this.formChangetHandler(e, "message")}
                />
                <span className="bar" />
                <label className="label-wrap font16">Message</label>
              </div>
              <div className="sendattachwpr">
                <span className="attachphoto">
                  <input
                    id="upload"
                    type="file"
                    name
                    accept="image/x-png,image/gif,image/jpeg"
                    onChange={() => this.formChangetHandler(this, "photo")}
                  />
                  <span className="addphoto font10">
                    <span className="gno_camera" />
                    <span className="addphototext font10">Add Photo</span>
                  </span>
                  <span className="">
                    <img src={this.state.helpdeskForm["photo"]} />
                  </span>
                </span>
              </div>
            </div>
          </div>
          <div className="submitwpr" onClick={() => this.formSubmitHandler()}>
            <button className="font16">Submit</button>
          </div>
        </div>
      </>
    );
  }
}

function mapStateToProps(state) {
  return {
    empcode: state.jd_store.empcode,
    user: state.jd_store.user,
    helpdeskForm: state.jd_store.helpdeskForm
  };
}

const mapDispatchToProps = dispatch => {
  return {
    // dispatching plain actions
  };
};
export default connect(mapStateToProps, {})(HelpDesk);
