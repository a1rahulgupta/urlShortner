import React, { Component } from "react";
import { Route, Switch, withRouter, Link } from "react-router-dom";
import { connect } from "react-redux";
import {
  getAppointments,
  getLastDisposition,
  getMyRecordings,
  toggleHistory,
  fetchAppointmentInfo
} from "./../redux/actions/userActions";
import { getServerCity } from "./../utilities/helperFunctions";

import SearchBar from "./common/SearchBar.jsx";

/**import components */
// import SearchBar from "./common/SearchBar.jsx";

import { ComponentLoader, ContentLoader } from "./common/ComponentLoader";
import ContractModal from "./common/ContractModal.jsx";
// import Appointments from "./Appointments.jsx";
import RecordingList from "../components/RecordingList";

class Allocations extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showAppointments: false,
      showNewBusiness: false,
      Loader: true,
      searchStr: "",
      expand: false,
      pageShow: 0,
      dayselect: 0,
      showCallHistory: false,
      recordingList: null,
      loadMore: true
    };
  }

  componentDidMount() {
    const {
      getAppointments,
      getLastDisposition,
      fetchAppointmentInfo,
      fetchAppointment,
      pendingAppointments,
      datacity,
      typeofemployee
    } = { ...this.props };
    const servercity = getServerCity(datacity);
    Promise.all([
      fetchAppointmentInfo({
        jwt_ucode: EMPCODE,
        data_city: datacity,
        server_city: servercity,
        module: typeofemployee,
        empcode: EMPCODE
      })
    ]).then(() => {
      if (pendingAppointments.length > 0) {
        this.props.history.push("/dispose-appointment");
        return false;
      }
    });
    Promise.all([
      getAppointments({
        jwt_ucode: EMPCODE,
        dataArr: {},
        pageShow: this.state.pageShow || 0,
        city: datacity,
        data_city: datacity,
        server_city: servercity,
        action: "AllocContracts",
        module: typeofemployee,
        empcode: EMPCODE,
        data_flag: 0,
        srchData: "",
        user_type: typeofemployee,
        bypass: typeofemployee == "ME" ? "0" : "1"
      })
      // getLastDisposition({
      //     "data_city": "MUMBAI",
      //     "empcode": "10083404",
      //     "paridStr": "PXX22.XX22.200520103532.H3V5,PXX22.XX22.200619193505.S9Q4,PXX22.XX22.200716170729.X4U3,PXX22.XX22.200528205640.K6T9"
      // })
    ]).then(() => {
      this.setState({ showAppointments: true, Loader: false });
    });
  }
  clearSearch = () => {
    const { datacity, typeofemployee } = { ...this.props };
    const servercity = getServerCity(datacity);

    Promise.all([
      this.props.getAppointments({
        jwt_ucode: EMPCODE,
        dataArr: {},
        pageShow: "0",
        city: datacity,
        data_city: datacity,
        server_city: servercity,
        action: "AllocContracts",
        module: typeofemployee,
        empcode: EMPCODE,
        data_flag: 0,
        srchData: "",
        user_type: typeofemployee,
        bypass: typeofemployee == "ME" ? "0" : "1"
      })
      // getLastDisposition({
      //     "data_city": "MUMBAI",
      //     "empcode": "10083404",
      //     "paridStr": "PXX22.XX22.200520103532.H3V5,PXX22.XX22.200619193505.S9Q4,PXX22.XX22.200716170729.X4U3,PXX22.XX22.200528205640.K6T9"
      // })
    ]).then(() => {
      this.setState({ showAppointments: true, Loader: false });
    });
  };
  handleExpand = () => {
    this.setState({ ...this.expand, expand: !this.state.expand });
  };

  handleLoadMore = e => {
    e.preventDefault();
    const { datacity, typeofemployee } = { ...this.props };
    const servercity = getServerCity(datacity);

    Promise.all([
      this.props.getAppointments({
        jwt_ucode: EMPCODE,
        dataArr:
          this.state.searchStr == ""
            ? {}
            : {
                filterType: "company",
                srchData: this.state.searchStr
              },
        pageShow: (parseInt(this.state.pageShow) + 1).toString(),
        city: datacity,
        data_city: datacity,
        server_city: servercity,
        action: "AllocContracts",
        module: typeofemployee,
        empcode: EMPCODE,
        data_flag: 0,
        srchData: this.state.searchStr == "" ? "" : this.state.searchStr,
        user_type: typeofemployee,
        bypass: typeofemployee == "ME" ? "0" : "1"
      })
    ]).then(() => {
      this.setState({
        showAppointments: true,
        DashboardLoader: false,
        pageShow: parseInt(this.state.pageShow) + 1,
        loadMore: !this.state.loadMore
      });
    });
  };

  // getAppointTabs = () => {};

  // getParentIdStr = () => {
  // 	return "PXX22.XX22.191016134336.C7H5";
  // };
  clearInput = () => {
    this.setState({ searchStr: "" }, this.clearSearch);
  };
  searchBarHandler = e => {
    e.preventDefault();
    const { datacity, typeofemployee } = { ...this.props };
    const servercity = getServerCity(datacity);

    let searchStr = e.target.value;
    let reg = new RegExp("^\\d+$");
    let strType = reg.test(searchStr) ? "mobile" : "name"; //search by mobile/compname

    this.setState({ searchStr }, () => {
      if (searchStr.length < 3) {
        this.clearSearch();
      } else {
        //dynamic payload to replace this once landing page redux state is set
        const payload = {
          clearFlag: false,
          jwt_ucode: EMPCODE,
          dataArr: {
            filterType: "company",
            srchData: this.state.searchStr
          },
          pageShow: "0",
          city: datacity,
          data_city: datacity,
          server_city: servercity,
          action: "AllocContracts",
          module: typeofemployee,
          empcode: EMPCODE,
          data_flag: 0,
          srchData: this.state.searchStr,
          user_type: typeofemployee,
          bypass: "1"
        };
        this.props.getAppointments(payload);
      }
    });
  };

  getAppointTabs = () => {
    return (
      <div className="appinttabs appointsticky">
        <ul className="font13">
          <li>
            {/* <a href="" className="act">Appointments</a> */}
            <Link to={"/todays-allocations"} className="act">
              Appointments
            </Link>
          </li>
          <li>
            {/* <a href="#">New Business</a> */}
            <Link to={"/new-business"}>New Business</Link>
            {/* <a href="#">New Business</a> */}
          </li>
          <li className="axpandallwpr">
            <a
              className="moredtllink font11"
              onClick={() => this.handleExpand()}
            >
              {!this.state.expand ? "Expand All" : "Collapse All"}
            </a>
          </li>
        </ul>
      </div>
    );
  };
  handleDaySelect = e => {
    e.preventDefault();
    this.setState({ dayselect: !this.state.dayselect });
  };

  getAppointStats = () => {
    return (
      <div className="appinttotalwpr">
        <div className="appinttotalprnt">
          <div className="appinttotaltbl">
            <span className="appinttotalcell font13">Appointments</span>
            <span className="appinttotalcell dayselectwpr">
              <div
                className="dayselect font10"
                onClick={e => this.handleDaySelect(e)}
              >
                All
                <div
                  className={
                    this.state.dayselect == 1 ? "allslctprnt" : "allslctprnt dn"
                  }
                >
                  <ul className="font13">
                    <li className="act">
                      <Link to={"/allocations"}>
                        <span className="gno_tickblue" /> All
                      </Link>
                    </li>
                    <li>
                      <Link to={"/todays-allocations"}>
                        <span className="gno_tickblue" /> Todays
                      </Link>
                    </li>
                  </ul>
                </div>
              </div>
              <div
                className={
                  this.state.dayselect == 1
                    ? "selectpopupwpr"
                    : "selectpopupwpr dn"
                }
              />
            </span>
          </div>
          <div className="cataloguetbl dn">
            <span className="cataloguetblcell font13">Catalogue Data</span>
            <span className="cataloguetblcell expandlink">
              <a href="#" className="font12">
                Expand All
              </a>
            </span>
          </div>
          <div className="cataloguetbl dn">
            <span className="cataloguetblcell font13">Deal Closed</span>
            <span className="cataloguetblcell expandlink">
              <a href="#" className="font12">
                Expand All
              </a>
            </span>
          </div>
          <div className="totalgraphtbl">
            <span className="totalgraphcell font15">
              {this.props.appintmentTotal}{" "}
              <span className="disblock font11">Total</span>
            </span>
            <span className="totalgraphcell yellowtext font15">
              {this.props.pendingAppointments.length}{" "}
              <span className="disblock font11">Pending</span>
            </span>
            <span className="totalgraphcell greentext font15">
              {this.props.appintmentTotal -
                this.props.pendingAppointments.length}{" "}
              <span className="disblock font11">Completed</span>
            </span>
          </div>
        </div>
      </div>
    );
  };

  //getRecordings
  getRecordings = (e, parentId, compname) => {
    e.preventDefault();
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
    Promise.all([
      this.props.getMyRecordings({
        blockFlag: 1,
        data_city: this.props.datacity,
        jwt_ucode: this.props.EMPCODE,
        module: this.props.typeofemployee,
        parentid: parentId
      })
    ])
      .then(() => {
        this.props.toggleHistory();
        this.setState({
          RecordingList: RecordingList({
            ...this.props,
            parentId,
            compname,
            my_recording: this.props.my_recording
          })
        });
      })
      .catch(error => {
        console.log(error);
      });
  };

  // Cancel RecordingPage
  cancelHistory = () => {};

  // getParentIdStr = () => {
  // 	return "PXX22.XX22.191016134336.C7H5";
  // };
  render() {
    if (this.state.Loader != undefined && this.state.Loader == true) {
      //return <ComponentLoader LoaderName="Loader" />;
    }
    console.log(
      this.props.pendingAppointments,
      this.props.pendingAppointments.length
    );

    if (this.props.pendingAppointments.length > 0) {
      this.props.history.push("/dispose-appointment");
      return false;
    }

    const { appintmentData, filter } = this.props;
    //console.log(this.props);

    //console.log("-----Appointments----", appintmentData);
    return (
      <>
        {!filter && (
          <SearchBar
            pageName="searchBusiness"
            placeholder="Select Business"
            value={this.state.searchStr}
            handleOnchange={e => this.searchBarHandler(e)}
            suggestionSelected={this.onSuggestionSelected}
            clearInput={this.clearInput}
          />
        )}
        {!filter && (
          <div className="mainwpr">
            {this.getAppointTabs()}
            {this.props.appintmentData && this.props.appintmentData.length > 0 && (
              <>
                <div
                  style={
                    this.props.toggleHistoryButton ? { display: "none" } : {}
                  }
                >
                  {this.getAppointStats()}
                  <ContractModal
                    history={this.props.history}
                    expand={this.state.expand}
                    contractData={appintmentData}
                    handleLoadMore={this.handleLoadMore}
                    showCallHistory={this.getRecordings}
                    totalContractData={this.props.appintmentTotal}
                    loadMore={this.state.loadMore}
                  />
                </div>
                <div
                  style={
                    !this.props.toggleHistoryButton ? { display: "none" } : {}
                  }
                >
                  {this.state.RecordingList}
                </div>
              </>
            )}
            {!(
              this.props.appintmentData && this.props.appintmentData.length > 0
            ) &&
              this.props.dataLoaded != undefined &&
              this.props.dataLoaded == 0 && (
                <>
                  {this.getAppointStats()}
                  <div className="fnotfoundwpr" style={{ height: "60vh" }}>
                    <div className="fnotfoundprnt">
                      <img
                        src={PATH_INFO + "/dev/src/media/img/filenotfound.svg"}
                      />
                      <div className="fnotfoundtext font18">Data Not Found</div>
                    </div>
                  </div>
                </>
              )}
            {!(
              this.props.appintmentData && this.props.appintmentData.length > 0
            ) &&
              this.props.dataLoaded == undefined && (
                <>
                  {this.getAppointStats()}
                  <ContentLoader />
                </>
              )}
          </div>
        )}
      </>
    );
  }
}

function mapStateToProps(state) {
  return {
    user: state.jd_store.user || "",
    typeofemployee: state.jd_store.typeofemployee,
    datacity: state.jd_store.datacity,
    appintmentData: state.jd_store.appintmentData || [],
    appintmentTotal: state.jd_store.appintmentTotal || 0,
    lastDispositionData: state.jd_store.lastDispositionData || "",
    filter: state.jd_store.filter,
    toggleHistoryButton: state.jd_store.toggleHistory,
    my_recording: state.jd_store.recording_Data || [],
    dataLoaded: state.jd_store.dataLoaded,
    fetchAppointment: state.jd_store.fetchAppointment,
    pendingAppointments: state.jd_store.pendingAppointments
  };
}

const mapDispatchToProps = dispatch => {
  return {
    getAppointments: params => dispatch(getAppointments(params)),
    getLastDisposition: params => dispatch(getLastDisposition(params)),
    getMyRecordings: params => dispatch(getMyRecordings(params)),
    toggleHistory: params => dispatch(toggleHistory(params)),
    fetchAppointmentInfo: params => dispatch(fetchAppointmentInfo(params))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Allocations);
