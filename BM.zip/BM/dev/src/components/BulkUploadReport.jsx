import React, { Component } from "react";
import { Link } from "react-router-dom";
import { withRouter } from "react-router-dom";
import Minipopup from "./common/Minipopup";
import {} from "./../redux/actions/userActions";
import { connect } from "react-redux";
import { ComponentLoader } from "./common/ComponentLoader";

class BulkUpload extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: {}
    };
  }
  componentDidMount() {
    console.log("this.props", this.props);
    if (
      this.props.location &&
      this.props.location.state &&
      this.props.location.state.data
    ) {
      this.setState({ data: this.props.location.state.data });
    }
  }

  goToBack() {
    this.props.history.push("/select-users");
  }

  capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }

  render() {
    const { isProceed, data } = this.state;

    let thisObj = this;
    return (
      <>
        {Object.keys(data).length > 0 && (
          <div className="p-20">
            <div className="bulkupload_rprt p-10">
              <div className="bulkupload_tbl">
                <div className="bulkupload_tbl_cell">
                  <div className="font12 color788">Type of upload</div>
                  <div className="font13 color1a1 fw600">Bulk</div>
                </div>
                <div className="bulkupload_tbl_cell">
                  <div className="font12 color788">Total cities</div>
                  <div className="font13 color1a1 fw600">
                    {data.data.length}
                  </div>
                </div>
              </div>
              <div className="bulkupload_tbl mt-20">
                <div className="bulkupload_tbl_cell">
                  <div className="font12 color788">Campaign budget</div>
                  <div className="font13 color1a1 fw600">
                    <span>{data.campname}</span>
                    {/* {data.data && data.data.map((item, key) => { return (<span className="ml-5">{"Days " + item['Tenure (Days)']}:{item['Budget']}</span>) })} */}
                  </div>
                </div>
              </div>
              <div className="bulkupload_tbl mt-20">
                <div className="bulkupload_tbl_cell">
                  <div className="font12 color788">Failed cities</div>
                  <div className="font13 color1a1 fw600">
                    {data.failedcities.length}
                  </div>
                </div>
                <div className="bulkupload_tbl_cell">
                  <div className="font12 color788">Success cities</div>
                  <div className="font13 color1a1 fw600">
                    {data.successcities.length}
                  </div>
                </div>
              </div>
              <div className="bulkupload_tbl mt-20">
                <div className="bulkupload_tbl_cell">
                  <div className="font12 color788">Failed cities list</div>
                  {data.failedcities.length == 0 ? (
                    <div className="font13 color1a1 fw600">{"NA"}</div>
                  ) : (
                    data.failedcities.map((city, key) => {
                      console.log("fialied cities", city);
                      return (
                        <div className="font13 color1a1 fw600">
                          {this.capitalizeFirstLetter(city)}
                          {key == data.failedcities.length - 1 ? "" : ", "}
                        </div>
                      );
                    })
                  )}
                </div>
                <div className="bulkupload_tbl_cell">
                  <div className="font12 color788">Success cities list</div>
                  {data.successcities &&
                    data.successcities.map((item, key) => {
                      console.log("successcities cities", item);

                      return (
                        <div key={key} className="font13 color1a1 fw600">
                          {this.capitalizeFirstLetter(item)}
                          {key == data.successcities.length - 1 ? "" : ", "}
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          </div>
        )}
        <div
          className="submitwpr"
          style={{ width: "100%", borderRadius: 0 }}
          onClick={() => this.goToBack()}
        >
          <button className="font16" style={{ borderRadius: 0 }}>
            OK
          </button>
        </div>
      </>
    );
  }
}

function mapStateToProps(state, props) {
  return {};
}

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(BulkUpload);
