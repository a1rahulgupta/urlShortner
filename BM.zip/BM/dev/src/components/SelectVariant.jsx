import React, { Component } from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import {
  fetchCampaignList,
  activeInactiveCampaign
} from "./../redux/actions/userActions";

class SelectVariant extends Component {
  constructor(props) {
    super(props);
    this.state = {
      variantObj: [],
      // isTempBudget: false,
      resInactiveCampaigns: []
    };
    this.activeInactiveCampaignHandler = this.activeInactiveCampaignHandler.bind(
      this
    );
    this.proceedToNext = this.proceedToNext.bind(this);
  }
  componentDidMount() {
    this.fetchCampaignListHandler();

    if (
      this.props.tempBudgetWindow &&
      this.props.tempBudgetWindow.data.budget_timming.length > 0
    ) {
      this.setState({
        // isTempBudget: this.props.tempBudgetWindow.data.budget_timming.is_active
      });
    }
  }
  fetchCampaignListHandler = () => {
    let params = {
      // isTempBudget: localStorage.getItem('isTempBudget'),
      selectedCity: this.props.selectCityArrDetails
    };
    Promise.all([this.props.fetchCampaignList(params)]).then(() => {
      if (this.props.CampaignList && this.props.CampaignList.data) {
        const arr = this.props.CampaignList.data.resSqlQueryForAll;
        var obj = {
          arr
        };
        var variantObj = obj.arr.filter(function(el) {
          return el.campid >= 54 && el.campid < 57;
        });
        this.setState({
          variantObj: variantObj
          // resInactiveCampaigns: this.props.CampaignList.data.resInactiveCampaigns.length > 0 ? this.props.CampaignList.data.resInactiveCampaigns : []
        });
      }
    });
  };

  fetchTempBudgetWindowHandler = () => {
    Promise.all([
      this.props.fetchTempBudgetWindow({
        data_city: this.state.dataCity
      })
    ]).then(() => {});
  };

  activeInactiveCampaignHandler(e, campaign_id) {
    let active_flag = e == 1 ? 0 : 1;

    if (this.state.resInactiveCampaigns.includes(campaign_id)) {
      active_flag = 1;
    }

    Promise.all([
      this.props.activeInactiveCampaign({
        active_flag: active_flag,
        campaign_id: campaign_id
      })
    ]).then(() => {
      this.fetchCampaignListHandler();
    });
  }
  proceedToNext(newVal, type) {
    // this.props.history.push("/plan-budget/" + newVal.campid)
    if (type == "emi") {
      this.props.history.push({
        pathname: "/emi-disable-enable/" + 54,
        state: {
          hasPdg: false,
          campid: 54
        }
      });
    } else if (type == "dp") {
      this.props.history.push({
        pathname: "/dpCount/" + 54,
        state: {
          hasPdg: false,
          campid: 54
        }
      });
    } else {
      this.props.history.push({
        pathname: "/plan-budget/" + newVal.campid,
        state: {
          campname: "Premium Package",
          variantType: newVal.campid == "54" ? "Standard" : newVal.campname,
          campid: newVal.campid
        }
      });
    }
  }

  render() {
    return (
      <div className=" wrapper-block pb-30">
        <div className="font14 fw600 pl-20 pr-20 pt-20">
          {" "}
          Selected Cities: {this.props.selectCityArrDetails.join(", ")}{" "}
        </div>
        <div className="font14 color414 fw600 pl-20 pr-20 pt-20">
          {" "}
          Please Select Varient{" "}
        </div>
        <div className="wrapper-block p-20">
          <ul className="wrapper-block pb-30">
            {this.state.variantObj.map((newVal, newKey) => {
              return (
                <li
                  key={newKey}
                  className="selUserLi dtable  color363 pl-15  csrpntr"
                  onClick={() => this.proceedToNext(newVal)}
                >
                  {/* <div className="dtablecell switchwidth">
										<label className="dtablecell switch">
											<input type="checkbox" value="true" defaultChecked={(newVal.active_flag == 1 && !this.state.resInactiveCampaigns.includes(newVal.campid)) ? true : false} onClick={() => this.activeInactiveCampaignHandler(newVal.active_flag, newVal.campid)} />
											<span className="slider"></span>
										</label>
									</div> */}
                  <div className="dtablecell">
                    <span className="font14 fw600">
                      {" "}
                      {newVal.campid == "54"
                        ? "Standard"
                        : newVal.campname}{" "}
                    </span>
                  </div>
                  <div className="dtablecell rtArrowBx text-right ">
                    <i className="rightBlkarrow icon-common"> </i>
                    {/* <Link to={"/plan-budget/" + newVal.campid}> <i className="rightBlkarrow icon-common"> </i>
										</Link> */}
                  </div>
                </li>
              );
            })}
            <li
              className="selUserLi dtable  color363 pl-15  csrpntr"
              onClick={() => this.proceedToNext(null, "emi")}
            >
              <div className="dtablecell">
                <span className="font14 fw600">EMI disable/enable</span>
              </div>
              <div className="dtablecell rtArrowBx text-right ">
                <i className="rightBlkarrow icon-common"> </i>
              </div>
            </li>
            {/* <li
                            className="selUserLi dtable  color363 pl-15  csrpntr"
                            onClick={() => this.proceedToNext(null, "dp")}
                        >
                            <div className="dtablecell">
                                <span className="font14 fw600">
                                    Dp Count

                                </span>
                            </div>
                            <div className="dtablecell rtArrowBx text-right ">
                                <i className="rightBlkarrow icon-common"> </i>
                            </div>
                        </li> */}
          </ul>
        </div>
      </div>
    );
  }
}
function mapStateToProps(state, props) {
  return {
    CampaignList: state.jd_store.fetchCampaignListData,
    selectCityArrDetails: state.jd_store.selectCityArrData,
    tempBudgetWindow: state.jd_store.tempBudgetWindow
  };
}

const mapDispatchToProps = dispatch => {
  return {
    fetchCampaignList: params => dispatch(fetchCampaignList(params)),
    activeInactiveCampaign: params => dispatch(activeInactiveCampaign(params)),
    fetchTempBudgetWindow: params => dispatch(fetchTempBudgetWindow(params))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(SelectVariant);
