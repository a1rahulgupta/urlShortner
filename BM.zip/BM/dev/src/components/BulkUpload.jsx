import React, { Component } from "react";
import { Link } from "react-router-dom";
import { withRouter } from "react-router-dom";
import Minipopup from "./common/Minipopup";
import { getVersion, downloadXlsx } from "./../redux/actions/userActions";
import Dropzone from "react-dropzone";
import { ComponentLoader } from "./common/ComponentLoader";
import { connect } from "react-redux";

const Compress = require("compress.js");
const XLSX = require("xlsx");
let xlsx = require("json-as-xlsx");
class BulkUpload extends Component {
  constructor(props) {
    super(props);
    this.state = {
      Loader: 0,
      filePath: [],
      alertPop: 0,
      alertMsg: "",
      docId: "",
      version: "",
      isUpload: 0,
      filename: "",
      isProceed: false
    };
    this.popupHandleOk = this.popupHandleOk.bind(this);
    this.handleOnDrop = this.handleOnDrop.bind(this);
    this.uploadDocuments = this.uploadDocuments.bind(this);
  }
  componentDidMount() {
    // this.getTableData();
  }

  async getTableData() {
    try {
      const { parentid } = this.props.match.params;

      let allocid = getLocalStorage("allocId");

      // get version

      const version_res = await getVersion(parentid);
      console.log("version res", version_res);
      let version =
        version_res && version_res.version ? version_res.version : "13";
      this.setState({ version: version });
    } catch (err) {
      this.setState({ Loader: 0 });
      console.log(err);
    }
  }
  popupHandleOk = () => {
    this.setState({ alertPop: 0, alertMsg: "" });
  };
  async downloadSample() {
    let filename = "sample.xlsx";
    let data = [{ "Tenure (Days)": "", City: "", Budget: "" }];
    const res = await downloadXlsx(data);
    var blob = new Blob([res], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    });
    var objectUrl = URL.createObjectURL(blob);
    var tempLinkEle = document.createElement("a");
    tempLinkEle.href = objectUrl;
    tempLinkEle.setAttribute("download", filename);
    tempLinkEle.click();
  }

  checkExtension(filename) {
    let exedata = /[^.]+$/.exec(filename);
    if (exedata[0] == "xlsx") {
      return true;
    } else {
      this.setState({
        alertPop: 1,
        alertMsg: `Please upload file in .xlsx extension`,
        Loader: 0
      });
      return false;
    }
  }

  skip() {
    console.log("props", this.props);
    this.props.history.goBack();
  }

  async submit(key) {
    try {
      if (key == "upload" && this.state.isUpload == 0) {
        this.setState({
          isProceed: false,
          alertPop: 1,
          alertMsg: "Please upload file."
        });
      } else if (key == "upload" && this.state.isUpload == 1) {
        this.setState({ isProceed: true });
      }
    } catch (err) {
      console.log("err", err);
    }
  }

  findDuplicates = arr => {
    var valueArr = arr.map(function(item) {
      return item["City"].toLowerCase();
    });
    var isDuplicate = valueArr.some(function(item, idx) {
      return valueArr.indexOf(item) != idx;
    });
    return isDuplicate;
  };
  checkForNum(arr, key) {
    let regx = /^\d+$/;
    let count = 0;
    for (let i = 0; i < arr.length; i++) {
      if (!regx.test(arr[i][key])) {
        count++;
      }
    }
    return count;
  }

  checkValueForZero(arr) {
    let index = arr.findIndex(x => x["Budget"] == 0);
    return index > -1;
  }

  async handleOnDrop(files) {
    let that = this;
    console.log("gile", files);
    that.setState({ Loader: 1 });

    for (var keyImg in files) {
      if (files.hasOwnProperty(keyImg) && files[keyImg] instanceof File) {
        let file = files[keyImg];
        if (this.checkExtension(file.name)) {
          let reader = new FileReader();
          const rABS = !!reader.readAsBinaryString; // !! converts object to boolean

          console.log("file extension", file);
          reader.onload = function(e) {
            var data = e.target.result;
            var workbook = XLSX.read(data, {
              type: "binary"
            });

            workbook.SheetNames.forEach(function(sheetName) {
              // Here is your object
              var XL_row_object = XLSX.utils.sheet_to_row_object_array(
                workbook.Sheets[sheetName]
              );
              var json_object = JSON.stringify(XL_row_object);
              console.log(XL_row_object);
              that.setState({ Loader: 0 });
              let definedKeys = ["Tenure (Days)", "City", "Budget"];
              let keys = Object.keys(XL_row_object[0]);
              let duplicateCheck = that.findDuplicates(XL_row_object);
              let numCheckBudget = that.checkForNum(XL_row_object, "Budget");
              let numCheckTenur = that.checkForNum(
                XL_row_object,
                "Tenure (Days)"
              );
              let checkZero = that.checkValueForZero(XL_row_object);
              // console.log("city duplicate", numCheck, duplicateCheck);
              var checkKey = keys.every(function(val) {
                return definedKeys.indexOf(val) !== -1;
              });

              console.log("rtesult success", keys, definedKeys, checkKey);
              // console.log("check not number", XL_row_object, that.checkNaN(XL_row_object))
              if (XL_row_object[0]["Tenure (Days)"] == "") {
                that.setState({
                  alertPop: 1,
                  alertMsg: "Atleast one entry should be there"
                });
                return false;
              } else if (XL_row_object.length > 500) {
                that.setState({
                  alertPop: 1,
                  alertMsg: "Only 500 records uploaded at one time."
                });
                return false;
              } else if (!checkKey) {
                that.setState({
                  alertPop: 1,
                  alertMsg:
                    "Please upload title with same name as provided in sample."
                });
                return false;
              } else if (numCheckBudget > 0) {
                that.setState({
                  alertPop: 1,
                  alertMsg: "Please upload budget with numeric values."
                });
                return false;
              } else if (numCheckTenur > 0) {
                that.setState({
                  alertPop: 1,
                  alertMsg: "Please upload tenure with numeric values."
                });
                return false;
              } else if (duplicateCheck) {
                that.setState({
                  alertPop: 1,
                  alertMsg: "Duplicate entry in city."
                });
                return false;
              } else if (checkZero) {
                that.setState({
                  alertPop: 1,
                  alertMsg: "Budget with zero value not allowed."
                });
                return false;
              } else {
                that.setState({ filename: file.name });
                that.uploadDocuments(XL_row_object);
              }
            });
          };

          reader.onerror = function(ex) {
            console.log(ex);
          };

          reader.readAsBinaryString(file);
        }
      }
    }
  }
  async uploadDocuments(data) {
    try {
      console.log("user==>,user", this.props);
      let req = {
        data: data,
        empcode: EMPCODE,
        empname:
          this.props.user && this.props.user.empname
            ? this.props.user.empname
            : ""
      };
      console.log("re1==>", req);
      localStorage.setItem("bulkUploadData", JSON.stringify(req));
      this.setState({ isUpload: 1, Loader: 0 });
    } catch (err) {
      console.log("err", err);
    }
  }

  render() {
    const {
      Loader,
      formData,
      alertMsg,
      alertPop,
      isUpload,
      isProceed,
      filename
    } = this.state;

    let thisObj = this;
    return (
      <>
        {Loader == 1 ? (
          <ComponentLoader LoaderName="DashboardLoader" />
        ) : (
          <div className="newbusinesswpr pb-70">
            <div className="font13 color1a1">
              Upload file containing details of proposed campaign budget
            </div>
            <Dropzone
              onDrop={acceptedFiles => this.handleOnDrop(acceptedFiles)}
            >
              {({ getRootProps, getInputProps }) => (
                <div
                  className="uploadbox_wpr borderradius15 mt-30"
                  {...getRootProps()}
                >
                  <input {...getInputProps()} />

                  <div className="uploadbox_button_wpr">
                    <button>Upload Excel</button>
                  </div>
                </div>
              )}
            </Dropzone>
            <div className="mt-10 tright">
              {
                <div>
                  <span className="color007 font11">{filename}</span>
                </div>
              }
              <div className="mt-10">
                <a className="color007 font11" onClick={this.downloadSample}>
                  Download the Excel sample
                </a>
              </div>
            </div>
          </div>
        )}
        <div className="submitwpr skipbtn_wpr">
          <button
            style={{ width: "100%" }}
            className="font16"
            onClick={() => this.submit("upload")}
          >
            Proceed
          </button>
        </div>
        {isProceed && (
          <div className="bulkupload_popup_wpr">
            <div className="bulkupload_popup_outer p-20">
              <div className="font13 color1a1">
                Are you sure, you want to bulk upload
              </div>

              <div className="yesnobtn_wpr mt-30">
                <button
                  onClick={() => {
                    this.props.history.push("/campaign-selection");
                    this.setState({ isProceed: false });
                  }}
                >
                  Yes
                </button>{" "}
                <button
                  className="nobtn ml-20"
                  onClick={() => this.setState({ isProceed: false })}
                >
                  No
                </button>
              </div>
            </div>
          </div>
        )}
        {alertPop == 1 && (
          <Minipopup
            text={alertMsg}
            handleOk={this.popupHandleOk}
            okPopup={true}
          />
        )}
      </>
    );
  }
}

function mapStateToProps(state, props) {
  return {
    user: state.jd_store.user || {}
  };
}

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(BulkUpload);
