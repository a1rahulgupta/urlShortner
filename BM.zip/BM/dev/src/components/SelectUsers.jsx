import React, { Component } from "react";
import { Link } from "react-router-dom";
import { withRouter } from "react-router-dom";
import Minipopup from "./common/Minipopup";

class SelectUsers extends Component {
  constructor(props) {
    super(props);
  }
  componentDidMount() {
    //console.log("EMPCODE", this.state.empcode);
    console.log("inside Select user");
    if (this.props.match.params.empcode) {
      localStorage.setItem(
        "budget_admin_empcode",
        this.props.match.params.empcode
      );
    } else {
      return (
        <Minipopup
          title={"Unauthorized"}
          text={"You are not authorized to access this Module!"}
          handleOk={this.closeUnauthorizedAlert}
          okPopup={true}
        />
      );
    }
  }
  render() {
    return (
      <div className=" wrapper-block pb-30">
        <div className="wrapper-block p-20">
          <ul className="wrapper-block pb-30">
            <Link to={"/select-cities"}>
              <li className="selUserLi dtable  color363 pl-15  csrpntr">
                <div className="dtablecell">
                  <span className="font14 fw600"> Select Cities </span>
                </div>
                <div className="dtablecell rtArrowBx text-right ">
                  <i className="rightBlkarrow icon-common"> </i>{" "}
                </div>
              </li>
            </Link>
            <Link to={"/bulk-upload"}>
              <li className="selUserLi dtable  color363 pl-15  csrpntr">
                <div className="dtablecell">
                  <span className="font14 fw600"> Bulk upload </span>
                </div>
                <div className="dtablecell rtArrowBx text-right ">
                  <i className="rightBlkarrow icon-common"> </i>{" "}
                </div>
              </li>
            </Link>
            {/* <li className="selUserLi dtable  color363 pl-15  csrpntr">
                        <div className="dtablecell"> 
                            <span className="font14 fw600"> Select Contract Ids </span>
                        </div>
                        <div className="dtablecell rtArrowBx text-right "> <i className="rightBlkarrow icon-common"> </i> </div>
                    </li>
                    <li className="selUserLi dtable  color363 pl-15  csrpntr">
                        <div className="dtablecell"> 
                            <span className="font14 fw600"> Select Employees </span>
                        </div>
                        <div className="dtablecell rtArrowBx text-right "> <i className="rightBlkarrow icon-common"> </i> </div>
                    </li>			 */}
          </ul>
        </div>

        {/* <div className="btmFixBtn">
                <button className="ftrBlueBtn font16"> Proceed </button>
            </div> */}
      </div>
    );
  }
}

export default withRouter(SelectUsers);
