import React, { Component } from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import {
  fetchTempBudgetWindow,
  updateTempBudgetWindow
} from "./../redux/actions/userActions";
import Moment from "moment";
import Minipopup from "./common/Minipopup";

class BudgetWindowTime extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isActive: false,
      dataCity: "",
      startDate: "",
      endDate: "",
      startTime: "",
      endTime: "",
      tempBudgetWindow: {},
      isReadonly: true,
      proceedPopup: false
    };
    this.checkBoxChangeHandler = this.checkBoxChangeHandler.bind(this);
    this.dateChangeHandler = this.dateChangeHandler.bind(this);
    this.timeChangeHandler = this.timeChangeHandler.bind(this);
    this.updateTempBudgetWindowHandler = this.updateTempBudgetWindowHandler.bind(
      this
    );
    this.proceedTo = this.proceedTo.bind(this);
  }
  componentDidMount() {
    if (
      this.props.selectCityArrDetails &&
      this.props.selectCityArrDetails.length > 0
    ) {
      this.state.dataCity = this.props.selectCityArrDetails[0];
      this.fetchTempBudgetWindowHandler();
    }
  }

  getTimingArr() {
    var timingArr = {};

    var globalEmpcodeTestFlag = 0;

    for (var i = 6; i <= 23; i++) {
      var hour12 = this.formatTime(i);
      var suffix = i >= 12 ? "PM" : "AM";
      if (i < 10) {
        if (i == 0) {
          timingArr["0" + i + ":" + "00:00"] = "00:00(Mid Night)";
        } else {
          timingArr["0" + i + ":" + "00:00"] = hour12 + ":" + "00" + suffix;
        }

        /*if(globalEmpcodeTestFlag != -1)
				{
					// added by Rahul Sreedhar as per Taiga user story 4264
					timingArr["0" + i + ":" + "15"] = hour12 + ":" + "15" + suffix; // handling 15 45 minutes
				}*/

        timingArr["0" + i + ":" + "30:00"] = hour12 + ":" + "30" + suffix;

        /*if(globalEmpcodeTestFlag != -1)
				{
					// added by Rahul Sreedhar as per Taiga user story 4264
					timingArr["0" + i + ":" + "45"] = hour12 + ":" + "45" + suffix; // handling 15 45 minutes
				}*/
      } else {
        timingArr[i + ":" + "00:00"] = hour12 + ":" + "00" + suffix;

        /*if(globalEmpcodeTestFlag != -1)
				{
					// added by Rahul Sreedhar as per Taiga user story 4264
					timingArr[i + ":" + "15"] = hour12 + ":" + "15" + suffix; // handling 15 45 minutes
				}*/

        timingArr[i + ":" + "30:00"] = hour12 + ":" + "30" + suffix;

        /*if(globalEmpcodeTestFlag != -1)
				{	
					// added by Rahul Sreedhar as per Taiga user story 4264
					timingArr[i + ":" + "45"] = hour12 + ":" + "45" + suffix; // handling 15 45 minutes
				}*/
      }
    }

    // as per taiga ticket from nishant we are showing morning time at the end
    for (var i = 0; i < 6; i++) {
      var hour12 = this.formatTime(i);
      var suffix = i >= 12 ? "PM" : "AM";
      if (i < 10) {
        if (i == 0) {
          timingArr["0" + i + ":" + "00:00"] = "12:00 (Mid Night)";
        } else {
          timingArr["0" + i + ":" + "00:00"] = hour12 + ":" + "00" + suffix;
        }

        /*if(globalEmpcodeTestFlag != -1)
				{
					// added by Rahul Sreedhar as per Taiga user story 4264
					timingArr["0" + i + ":" + "15"] = hour12 + ":" + "15" + suffix; // handling 15 45 minutes
				}*/

        timingArr["0" + i + ":" + "30:00"] = hour12 + ":" + "30" + suffix;

        /*if(globalEmpcodeTestFlag != -1)
				{
					// added by Rahul Sreedhar as per Taiga user story 4264
					timingArr["0" + i + ":" + "45"] = hour12 + ":" + "45" + suffix; // handling 15 45 minutes
				}*/
      } else {
        timingArr[i + ":" + "00:00"] = hour12 + ":" + "00" + suffix;

        /*if(globalEmpcodeTestFlag != -1)
				{
					// added by Rahul Sreedhar as per Taiga user story 4264
					timingArr[i + ":" + "15"] = hour12 + ":" + "15" + suffix; // handling 15 45 minutes
				}*/

        timingArr[i + ":" + "30:00"] = hour12 + ":" + "30" + suffix;

        /*if(globalEmpcodeTestFlag != -1)
				{
					// added by Rahul Sreedhar as per Taiga user story 4264
					timingArr[i + ":" + "45"] = hour12 + ":" + "45" + suffix; // handling 15 45 minutes
				}*/
      }
    }
    timingArr["00:30:00"] = "12:30 (Mid Night)";

    /*if(globalEmpcodeTestFlag != -1)
		{
			// added by Rahul Sreedhar as per Taiga user story 4264
			timingArr["00:15"] = "12:15 (Mid Night)";  // handling 15 45 minutes
		}*/

    timingArr["12:00:00"] = "12:00 (Noon)";

    /*if(globalEmpcodeTestFlag != -1)
		{
			// added by Rahul Sreedhar as per Taiga user story 4264
			timingArr["12:15"] = "12:15 (Noon)";  // handling 15 45 minutes
		}*/

    timingArr["12:30:00"] = "12:30 (Noon)";
    //timingArr["Open 24 Hrs"] = "Open 24 Hours";
    return timingArr;
  }
  formatTime(hours) {
    hours = ((hours + 11) % 12) + 1;
    return hours;
  }

  fetchTempBudgetWindowHandler = () => {
    Promise.all([
      this.props.fetchTempBudgetWindow({
        data_city: this.state.dataCity
      })
    ]).then(() => {
      if (this.props.tempBudgetWindow && this.props.tempBudgetWindow.data) {
        if (this.props.tempBudgetWindow.data.budget_timming) {
          this.setState({
            isActive: this.props.tempBudgetWindow.data.budget_timming.is_active,
            startDate: this.props.tempBudgetWindow.data.budget_timming
              .start_date,
            startTime: this.props.tempBudgetWindow.data.budget_timming
              .start_time,
            endDate: this.props.tempBudgetWindow.data.budget_timming.end_date,
            endTime: this.props.tempBudgetWindow.data.budget_timming.end_time,
            isReadonly: this.props.tempBudgetWindow.data.budget_timming
              .is_active
              ? false
              : true
          });
        }
      }
    });
  };

  checkBoxChangeHandler = e => {
    this.setState({
      isActive: e.target.checked,
      isReadonly: !e.target.checked
    });
  };

  dateChangeHandler = e => {
    this.setState({
      [e.target.name]: e.target.value
    });
  };

  timeChangeHandler = e => {
    this.setState({
      [e.target.name]: e.target.value
    });
  };

  updateTempBudgetWindowHandler = e => {
    let params = {
      empcode: EMPCODE,
      username: "",
      data_city: this.props.selectCityArrDetails,
      start_date: this.state.startDate,
      start_time: this.state.startTime,
      end_date: this.state.endDate,
      end_time: this.state.endTime,
      is_active: this.state.isActive
    };

    Promise.all([this.props.updateTempBudgetWindow(params)]).then(() => {
      localStorage.setItem("isTempBudget", 1);
      this.props.history.push({
        pathname: "/select-campaign",
        state: { isTempBudget: true }
      });
    });
  };

  proceedTo = () => {
    if (
      this.state.isActive &&
      (!this.state.startDate ||
        !this.state.endDate ||
        !this.state.startTime ||
        !this.state.endTime)
    ) {
      this.setState({ proceedPopup: true });
    } else if (this.state.isActive) {
      this.updateTempBudgetWindowHandler();
    } else {
      localStorage.setItem("isTempBudget", 0);
      this.props.history.push({
        pathname: "/select-campaign",
        state: { isTempBudget: false }
      });
    }
  };

  closeAlert = () => {
    this.setState({ proceedPopup: false });
  };

  render() {
    var timingGetArr = this.getTimingArr();

    if (this.state.proceedPopup) {
      return (
        <Minipopup
          title={"Select Temporary budget window time"}
          text={"Please select temporaray budget start & end time"}
          handleOk={this.closeAlert}
          okPopup={true}
        />
      );
    }
    return (
      <div className=" wrapper-block pb-30">
        <div className="wrapper-block ">
          <div className="animwrap  ">
            <label className="animcheck">
              <input
                className="animinput"
                checked={this.state.isActive}
                type="checkbox"
                value={this.state.isActive}
                onChange={this.checkBoxChangeHandler}
              />
              <div className="animlabel dtablecell w100 pl-20 pr-20 pb-10">
                <span className="animicon"></span>
                <span className="animtext font16 fw600 color1a1">
                  {" "}
                  Temporary Window{" "}
                </span>
              </div>
            </label>
          </div>

          <div className="dtable pt-10 pl-20 pr-20">
            <div className="dtablecell pr-5">
              <div className="group">
                <input
                  type="date"
                  name="startDate"
                  className="inputMaterial fw600"
                  value={this.state.startDate}
                  onChange={this.dateChangeHandler}
                  readOnly={this.state.isReadonly}
                />
                <span className="bar"></span>
                <label className="label-wrap ">Start Date</label>
              </div>
            </div>
            <div className="dtablecell pl-5">
              <div className="group selectgroup ">
                <select
                  className="inputMaterial font16 fw600"
                  required=""
                  value={this.state.startTime}
                  name="startTime"
                  onChange={this.timeChangeHandler}
                  disabled={this.state.isReadonly}
                >
                  <option value="">Select</option>
                  {Object.keys(timingGetArr).map(function(value, key) {
                    return (
                      <option key={key} value={value}>
                        {timingGetArr[value]}
                      </option>
                    );
                  })}
                </select>
                <i className="selectarrow"></i>
                <span className="bar"></span>
                <label className="label-wrap color1a1 font16">Time</label>
              </div>
            </div>
          </div>
          <div className="dtable pt-10 pl-20 pr-20">
            <div className="dtablecell pr-5">
              <div className="group">
                <input
                  type="date"
                  name="endDate"
                  className="inputMaterial fw600"
                  value={this.state.endDate}
                  onChange={this.dateChangeHandler}
                  readOnly={this.state.isReadonly}
                />
                <span className="bar"></span>
                <label className="label-wrap ">End Date</label>
              </div>
            </div>
            <div className="dtablecell pl-5">
              <div className="group selectgroup">
                <select
                  name="endTime"
                  className="inputMaterial font16 fw600"
                  name="endTime"
                  required=""
                  value={this.state.endTime}
                  onChange={this.timeChangeHandler}
                  disabled={this.state.isReadonly}
                >
                  <option value="">Select</option>
                  {Object.keys(timingGetArr).map(function(value, key) {
                    return (
                      <option key={key} value={value}>
                        {timingGetArr[value]}
                      </option>
                    );
                  })}
                </select>
                <i className="selectarrow"></i>
                <span className="bar"></span>
                <label className="label-wrap color1a1 font16">Time</label>
              </div>
            </div>
          </div>
        </div>
        {/*<Link to={"/select-users"}>*/}
        <div className="btmFixBtn">
          <button className="ftrBlueBtn font16" onClick={this.proceedTo}>
            {" "}
            Proceed{" "}
          </button>
        </div>
        {/*</Link>*/}
      </div>
    );
  }
}

function mapStateToProps(state, props) {
  return {
    tempBudgetWindow: state.jd_store.tempBudgetWindow,
    selectCityArrDetails: state.jd_store.selectCityArrData
  };
}

const mapDispatchToProps = dispatch => {
  return {
    fetchTempBudgetWindow: params => dispatch(fetchTempBudgetWindow(params)),
    updateTempBudgetWindow: params => dispatch(updateTempBudgetWindow(params))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(BudgetWindowTime);
