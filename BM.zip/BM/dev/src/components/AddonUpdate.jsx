import React, { Component } from "react";
import { Link, Redirect } from "react-router-dom";
import { connect } from "react-redux";
import {
  fetchTop5Plans,
  updateTop5Plans
} from "./../redux/actions/userActions";
import Minipopup from "./common/Minipopup";

class AddOnUpdate extends Component {
  constructor(props) {
    super(props);

    this.state = {
      emiOptionArr: [],
      emi_options: [],
      dataCity: "",
      dataCityArr: [],
      flatAmt: true,
      dpCount: false,
      paramsValue: "",
      showMinipopup: false,
      miniPopupText: "",
      miniPopupTitle: "",
      upfront: "",
      ecs: "",
      plansObj: {},
      stateObj: {},
      prevValue: {}
    };
  }
  componentDidMount() {
    if (
      this.props.selectCityArrDetails &&
      this.props.selectCityArrDetails.length > 0
    ) {
      (this.state.dataCity = this.props.selectCityArrDetails[0]),
        (this.state.dataCityArr = this.props.selectCityArrDetails);
    }
    if (this.props.match.params.variant) {
    }

    console.log("==props==>", this.props);
    let stateObj = {};
    if (this.props.location.state) {
      stateObj = this.props.location.state;
    }

    this.setState({ stateObj: stateObj });

    let params = {
      // isTempBudget: localStorage.getItem('isTempBudget'),
      selectedCity: this.props.selectCityArrDetails
    };
    console.log("==camp=", this.props.selectCampData);
    if (this.props.selectCampData) {
      this.fetchPlans(this.props.selectCampData["campid"]);
    }
  }

  closeAlert = () => {
    if (this.state.miniPopupText == "Plans has been succesfully updated") {
      this.props.history.push("/select-users");
      document.getElementsByClassName(
        "hdrWrp hdrDetail hdrWhiteBg"
      )[0].style.visibility = "visible";
    } else {
      this.setState({ showMinipopup: false });
    }
  };
  updateValue(e, key, type) {
    let plan_obj = this.state.plansObj;
    plan_obj[key][type] = parseFloat(e.target.value);
    this.setState({ plansObj: plan_obj });
    console.log("updated value", plan_obj);
  }

  async update() {
    console.log("selected plan", this.state.plansObj);

    let params = {
      cityNames: this.props.selectCityArrDetails,
      camp_id: this.state.stateObj.campid,
      tenure_options: this.state.plansObj,
      empcode: EMPCODE,
      username: "",
      prev_value: this.state.prevValue
    };

    Promise.all([this.props.updateTop5Plans(params)]).then(() => {
      console.log("updates", this.props.resUpdate);
      if (this.props.resUpdate && this.props.resUpdate.isUpdate == 1) {
        this.setState(
          {
            miniPopupText: "Plans has been succesfully updated",
            showMinipopup: true
          },
          () => {
            document.getElementsByClassName(
              "hdrWrp hdrDetail hdrWhiteBg"
            )[0].style.visibility = "hidden";
          }
        );
        return;
      }
    });
  }

  async fetchPlans(campid) {
    let params = {
      city: this.props.selectCityArrDetails[0],
      camp_id: campid
    };
    Promise.all([this.props.fetchTop5Plans(params)]).then(() => {
      console.log("plans==>", this.props.top5Plans);
      this.setState({
        plansObj: this.props.top5Plans,
        prevValue: this.props.top5Plans
      });
    });
  }

  proceedToNext(type) {
    if (type == "emi") {
      this.props.history.push({
        pathname: "/emi-disable-enable/" + this.state.stateObj.campid,
        state: {
          campid: this.state.stateObj.campid
        }
      });
    } else if (type == "dp") {
      this.props.history.push({
        pathname: "/dpCount/" + this.state.stateObj.campid,
        state: {
          campid: this.state.stateObj.campid
        }
      });
    }
  }

  render() {
    if (this.state.showMinipopup) {
      return (
        <Minipopup
          title={this.state.miniPopupTitle}
          text={this.state.miniPopupText}
          handleOk={this.closeAlert}
          okPopup={true}
        />
      );
    }
    const showEmi =
      this.state.stateObj.campid == 4
        ? false
        : this.state.stateObj.campid == 8
        ? false
        : this.state.stateObj.campid == 9
        ? false
        : true;
    return (
      <div className=" wrapper-block pb-30 ftrSpace">
        {this.state.plansObj && Object.keys(this.state.plansObj).length > 0 && (
          <div>
            <div className="pl-20 pr-20 pt-20">
              <ul className="wrapper-block pb-30">
                {showEmi && (
                  <li
                    className="selUserLi dtable  color363 pl-15  csrpntr"
                    onClick={() => this.proceedToNext("emi")}
                  >
                    <div className="dtablecell">
                      <span className="font14 fw600">EMI disable/enable</span>
                    </div>
                    <div className="dtablecell rtArrowBx text-right ">
                      <i className="rightBlkarrow icon-common"> </i>
                    </div>
                  </li>
                )}
                {/* <li
                  className="selUserLi dtable  color363 pl-15  csrpntr"
                  onClick={() => this.proceedToNext("dp")}
                >
                  <div className="dtablecell">
                    <span className="font14 fw600">
                      Dp Count

                    </span>
                  </div>
                  <div className="dtablecell rtArrowBx text-right ">
                    <i className="rightBlkarrow icon-common"> </i>
                  </div>
                </li> */}
              </ul>
            </div>
            <div className="font14 color414 fw600 pl-20 pr-20 pt-20">
              Add on update
            </div>
            {this.state.plansObj &&
              Object.keys(this.state.plansObj).length > 0 &&
              Object.keys(this.state.plansObj).map((key, index) => (
                <div key={index} className="wrapper-block pl-20 pr-20 pt-20">
                  <div className="font14 color414 fw600 p-20">
                    {" "}
                    {this.state.plansObj[key]?.tenure_name}{" "}
                  </div>

                  <ul className="typeAWrp wrapper-block ">
                    {this.state.plansObj[key] &&
                      this.state.plansObj[key].ecs != null && (
                        <li className="selUserLi dtable  color1a1 pl-15  csrpntr">
                          <div className="dtable ">
                            <div className="group">
                              <input
                                className="inputMaterial fw600"
                                type="text"
                                maxLength="8"
                                value={
                                  this.state.plansObj[key] &&
                                  this.state.plansObj[key].ecs
                                    ? this.state.plansObj[key].ecs
                                    : ""
                                }
                                onChange={e => this.updateValue(e, key, "ecs")}
                              />
                              <span className="bar"></span>
                              <label className="label-wrap ">ECS</label>
                            </div>
                          </div>
                        </li>
                      )}

                    <li className="selUserLi dtable  color1a1 pl-15  csrpntr">
                      <div className="dtable ">
                        <div className="group">
                          <input
                            className="inputMaterial  fw600"
                            maxLength="8"
                            type="text"
                            required=""
                            value={
                              this.state.plansObj[key] &&
                              this.state.plansObj[key].upfront
                                ? this.state.plansObj[key].upfront
                                : ""
                            }
                            onChange={e => this.updateValue(e, key, "upfront")}
                          />
                          <span className="bar"></span>
                          <label className="label-wrap ">Upfront</label>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
              ))}

            <div className="btmFixBtn">
              <button
                className="ftrBlueBtn font16"
                onClick={() => this.update()}
              >
                {" "}
                Update{" "}
              </button>
            </div>
          </div>
        )}
        {this.state.plansObj && Object.keys(this.state.plansObj).length == 0 && (
          <div className="font14 color414 fw600 pl-20 pr-20 pt-20">
            <div className="text-center">No data found</div>
          </div>
        )}
      </div>
    );
  }
}
function mapStateToProps(state, props) {
  return {
    selectCityArrDetails: state.jd_store.selectCityArrData,
    top5Plans: state.jd_store.fetchTop5Plans,
    resUpdate: state.jd_store.updateTop5Plans,
    selectCampData: state.jd_store.selectCampData
  };
}

const mapDispatchToProps = dispatch => {
  return {
    fetchTop5Plans: params => dispatch(fetchTop5Plans(params)),
    updateTop5Plans: params => dispatch(updateTop5Plans(params))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(AddOnUpdate);
