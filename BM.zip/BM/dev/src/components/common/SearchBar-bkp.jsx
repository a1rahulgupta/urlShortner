import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Route, Switch, withRouter, Redirect } from "react-router-dom";

const SearchBar = props => {
  return (
    <>
      <div className="mainsearch">
        <div className="inputouter">
          <input
            className="inputarea font16 "
            type="text"
            placeholder={props.placeholder}
            value={props.value}
            onChange={props.handleOnchange}
          />
          <span className="searchIcon" />
          {props.value && props.value.length > 0 && (
            <span className="gno_clear" onClick={props.handleClearInput}></span>
          )}
        </div>
      </div>
      <div>
        <div className="divider" />
        <div className="ecssrch_rsltwpr">
          <ul>
            {props.suggestions &&
              props.suggestions.map((suggestion, index) => (
                <li
                  key={index}
                  onClick={() => props.saveCity(suggestion.ct_name)}
                >
                  <div className="srchtitle font15">{suggestion.ct_name}</div>
                  <div className="srchtitle_id font12">
                    {suggestion.state_name}
                  </div>
                </li>
              ))}
          </ul>
        </div>
      </div>
    </>
  );
};

SearchBar.propTypes = {
  pageName: PropTypes.string.isRequired,
  placeholder: PropTypes.string.isRequired,
  value: PropTypes.string,
  handleOnchange: PropTypes.func.isRequired,
  suggestions: PropTypes.array.isRequired
};

export default withRouter(SearchBar);
