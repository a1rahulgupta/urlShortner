import React from "react";

let ComponentErrorSuccess = props => {
  return (
    <div>
      {props.formError && (
        <div
          className={
            props.formError
              ? " alert alert_danger fadeIn"
              : " alert alert_success fadeIn"
          }
          data-wow-duration="0.55s"
          style={{
            zIndex: 9
          }}
          //onClick={props.handleClearError}
        >
          {props.formError ? props.formError : props.formSuccess}
        </div>
      )}
    </div>
  );
};

export default ComponentErrorSuccess;
