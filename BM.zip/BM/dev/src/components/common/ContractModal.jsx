import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Link, Redirect } from "react-router-dom";
import Minipopup from "./Minipopup";
import JdAppStatusPopup from "./JdAppStatusPopup";
import JdMartStatusPopup from "./JdMartStatusPopup";
import { ComponentLoader, ContentLoader } from "./ComponentLoader";
import {
  getAppointments,
  getLastDisposition,
  getActionData,
  getMobileNumber,
  cancelDownsellRequest,
  getShadowData,
  fetchLiveData,
  getWebRedirectToken,
  chkContractEditAccess,
  JDAppdownloadstatus,
  JDMartdownloadstatus
} from "../../redux/actions/userActions";
import {
  GET_RATINGS,
  GET_ACTIVE_CAPMS,
  GET_FULLADDRESS
} from "../../redux/actions/actionTypes";
import {
  urlencode,
  handleGenioLiteRedirect
} from "../../utilities/helperFunctions";
import * as helperFn from "./HelperFunc";

import Moment, { calendarFormat } from "moment";
import {
  setLocalStorage,
  getLocalStorage
} from "./../../utilities/localStorage";

import SmsEmail from "../SmsEmail.jsx";

// const ContractModal = ({contractData}) => {
class ContractModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      DashboardLoader: true,
      parentidExpand: [],
      loadMoreDetails: [],
      showMinipopup: false,
      miniPopupTitle: "",
      miniPopupText: "",
      call_dropdown: "",
      call_dropdown_html: "",
      jdAppStatusShow: "",
      jdMartStatusShow: "",
      loadMoreDisable: false
      //jd_app_download_status: {},
    };
  }

  componentDidMount() {
    // const { empcode, getLastDisposition, parentIdStr, contractData } = { ...this.props };
    const {
      empcode,
      getLastDisposition,
      contractData,
      getActionData,
      typeofemployee,
      JDAppdownloadstatus,
      JDMartdownloadstatus
    } = { ...this.props };
    var currLink = window.location.hash.replace("#", "");
    setLocalStorage("currLink", currLink);

    if (contractData && contractData.length > 0) {
      const parentIdStr = this.getParentIdStr(contractData);
      Promise.all([
        getLastDisposition({
          data_city: this.props.datacity,
          empcode: empcode,
          paridStr: parentIdStr,
          pageShow: 0
        }),
        getActionData(
          {
            data_city: this.props.datacity,
            emp_code: empcode,
            paridStr: parentIdStr,
            module: typeofemployee,
            bypass: typeofemployee == "ME" ? "0" : "1",
            pageShow: 0
          },
          GET_RATINGS,
          "/contract/getRatingsAPI"
        ),
        getActionData(
          {
            data_city: this.props.datacity,
            emp_code: empcode,
            paridStr: parentIdStr,
            module: typeofemployee,
            bypass: typeofemployee == "ME" ? "0" : "1",
            pageShow: 0
          },
          GET_FULLADDRESS,
          "/geniosales/getFullAddressDataBeta"
        ),
        getActionData(
          {
            data_city: this.props.datacity,
            emp_code: empcode,
            parentid: parentIdStr,
            module: typeofemployee,
            bypass: typeofemployee == "ME" ? "0" : "1",
            pageShow: 0
          },
          GET_ACTIVE_CAPMS,
          "/campaignInfo/getPopCatsNdActiveCamps"
        )
      ]).then(() => {
        JDAppdownloadstatus({
          jwt_ucode: EMPCODE,
          data_city: this.props.datacity,
          module: typeofemployee,
          mobileNo: this.props.mobile_str
        });
        JDMartdownloadstatus({
          jwt_ucode: EMPCODE,
          data_city: this.props.datacity,
          module: typeofemployee,
          mobileNo: this.props.mobile_str
        });
        this.setState({ DashboardLoader: false });
      });
    } else {
      this.setState({ DashboardLoader: false });
      return false;
    }
  }

  componentDidUpdate(prevProps, prevState) {
    let prevContracts = this.getParentIdStr(prevProps.contractData);
    let nextContracts = this.getParentIdStr(this.props.contractData);
    if (
      prevProps.expand != this.props.expand ||
      prevProps.loadMore != this.props.loadMore
    ) {
      if (this.props.contractData && this.props.contractData.length > 0) {
        if (this.props.expand) {
          let parentidExpand = [];
          let loadMoreDetails = [];
          this.props.contractData.map((contract, index) =>
            parentidExpand.push(contract.parentid)
          );
          this.props.contractData.map((contract, index) =>
            loadMoreDetails.push({
              parentid: contract.parentid,
              instrumentid: contract.instrumentid
            })
          );
          this.setState({ parentidExpand, loadMoreDetails });
        } else {
          this.setState({ parentidExpand: [], loadMoreDetails: [] });
        }
      }
    }
    if (prevProps != this.props && prevContracts != nextContracts) {
      const {
        empcode,
        getLastDisposition,
        contractData,
        getActionData,
        typeofemployee,
        JDAppdownloadstatus,
        JDMartdownloadstatus
      } = { ...this.props };

      if (contractData && contractData.length > 0) {
        const parentIdStr = this.getParentIdStr(contractData);
        Promise.all([
          getLastDisposition({
            data_city: this.props.datacity,
            empcode: empcode,
            paridStr: parentIdStr,
            pageShow: 1
          }),
          getActionData(
            {
              data_city: this.props.datacity,
              emp_code: empcode,
              paridStr: parentIdStr,
              module: typeofemployee,
              bypass: typeofemployee == "TME" ? "1" : "0",
              pageShow: 1
            },
            GET_RATINGS,
            "/contract/getRatingsAPI"
          ),
          getActionData(
            {
              data_city: this.props.datacity,
              emp_code: empcode,
              paridStr: parentIdStr,
              module: typeofemployee,
              bypass: typeofemployee == "ME" ? "0" : "1",
              pageShow: 1
            },
            GET_FULLADDRESS,
            "/geniosales/getFullAddressDataBeta"
          ),
          getActionData(
            {
              data_city: this.props.datacity,
              emp_code: empcode,
              parentid: parentIdStr,
              module: typeofemployee,
              bypass: typeofemployee == "TME" ? "1" : "0",
              pageShow: 1
            },
            GET_ACTIVE_CAPMS,
            "/campaignInfo/getPopCatsNdActiveCamps"
          )
        ]).then(() => {
          JDAppdownloadstatus({
            jwt_ucode: EMPCODE,
            data_city: this.props.datacity,
            module: typeofemployee,
            mobileNo: this.props.mobile_str
          });
          JDMartdownloadstatus({
            jwt_ucode: EMPCODE,
            data_city: this.props.datacity,
            module: typeofemployee,
            mobileNo: this.props.mobile_str
          });
          this.setState({ DashboardLoader: false });
        });
      } else {
        this.setState({ DashboardLoader: false });
        return false;
      }
    }
  }

  getParentIdStr = contractData => {
    return contractData
      .reduce((currentArr, currentData) => {
        currentArr.push(currentData["parentid"]);
        return currentArr;
      }, [])
      .join();
  };

  getDispositionData = (parentid, value) => {
    const { lastDispositionData } = { ...this.props };

    let finalData = "";
    if (lastDispositionData.length > 0) {
      lastDispositionData.forEach(data => {
        if (data["contractCode"] == parentid) {
          switch (value) {
            case "mename":
              finalData = data["mename"];
              break;
            case "me_mobile_number":
              finalData = data["me_mobile_number"];
              break;
            case "tmename":
              finalData = data["tmename"];
              break;
            case "tme_mob_num":
              finalData = data["tme_mob_num"];
              break;
            case "disposition_name":
              finalData = data["disposition_name"];
              break;
            case "diposition_date":
              finalData = data["allocationTime"];
              break;
          }
        }
      });
    }
    return finalData;
  };

  getRatings = (data, parentId) => {
    const ratingsObject = {
      totalRating: 0,
      ratstar: 0.0,
      star: []
    };
    for (let [key, value] of Object.entries(data)) {
      if (key == parentId) {
        if (value["rating"] && value["rating"]["totrates"]) {
          ratingsObject["totalRating"] = value["rating"]["totrates"];
          ratingsObject["ratstar"] = value["rating"]["ratstar"];
          ratingsObject["star"] = value["rating"]["result"]["star"];
        }
        break;
      }
    }
    return ratingsObject;
  };

  getActiveCampaignDetails = (data, parentId) => {
    const activeCampaignDetails = {
      businessKeywords: "NA",
      activeCampaign: "NA",
      active_for: "NA",
      expiry_status: "NA",
      fin_paid: 0,
      website: ""
    };
    for (let [key, value] of Object.entries(data)) {
      if (key == parentId) {
        activeCampaignDetails["businessKeywords"] = value["catName"];
        activeCampaignDetails["activeCampaign"] = value["campaignName"];
        activeCampaignDetails["active_for"] = value["active_for"];
        activeCampaignDetails["expiry_status"] = value["expiry_status"];
        activeCampaignDetails["fin_paid"] = value["fin_paid"];
        activeCampaignDetails["website"] = value["website"]
          ? value["website"]
          : "";
        break;
      }
    }
    return activeCampaignDetails;
  };

  getFullAddressDetail = (data, parentId) => {
    const fullAddressDetails = { full_address: "", mobile_str: [] };
    for (let [key, value] of Object.entries(data)) {
      if (key == parentId) {
        fullAddressDetails["full_address"] = value["full_address"];
        fullAddressDetails["mobile_str"] = value["mobile"]
          ? value["mobile"].split(",")
          : value["mobile"];
        break;
      }
    }
    return fullAddressDetails;
  };

  handleParentIdExpand = (e, parentId, show, instrumentid) => {
    e.preventDefault();
    let parentidExpand = [...this.state.parentidExpand];
    let loadMoreDetails = [...this.state.loadMoreDetails];
    if (show) {
      parentidExpand.push(parentId);
    } else {
      parentidExpand = parentidExpand.filter(element => element != parentId);
      loadMoreDetails = loadMoreDetails.filter(
        ele => ele.parentid != parentId || ele.instrumentid != instrumentid
      );
    }
    this.setState({ parentidExpand, loadMoreDetails });
  };

  handleMoreDetails = (e, parentid, instrumentid, show) => {
    e.preventDefault();
    let loadMoreDetails = [...this.state.loadMoreDetails];
    if (show) {
      loadMoreDetails.push({ parentid, instrumentid });
    } else {
      console.log(
        loadMoreDetails.filter(
          ele => ele.parentid != parentid || ele.instrumentid != instrumentid
        )
      );
      loadMoreDetails = loadMoreDetails.filter(
        ele => ele.parentid != parentid || ele.instrumentid != instrumentid
      );
    }
    this.setState({ loadMoreDetails });
  };

  handleClickToCall = parentid => {
    if (this.state.call_dropdown == "call_" + parentid) {
      this.setState({ call_dropdown: "", call_dropdown_html: "" });
    } else {
      Promise.all([
        this.props.getMobileNumber({
          jwt_ucode: EMPCODE,
          data_city: this.props.datacity,
          parentid: parentid,
          module: this.props.typeofemployee,
          table: "tbl_companymaster_generalinfo_shadow",
          blockFlag: 1
        })
      ]).then(() => {
        let mobArr = this.props.clickCallMobileNumber.split(",");
        let html = (
          <span id={"call_" + parentid}>
            <ul className="call_dropdown">
              {helperFn.isMobile() &&
                mobArr.map(function(val, key) {
                  console.log("val111", val);
                  return (
                    <li key={"clickcalltell_" + key}>
                      <a
                        className="clickcalltel"
                        onClick={() => helperFn.CallMobile(val)}
                      >
                        {val}
                      </a>
                    </li>
                  );
                })}

              {!helperFn.isMobile() &&
                mobArr.map(function(val, key) {
                  console.log("val222", val);

                  return (
                    <li key={"clickcalltell_" + key}>
                      <a className="clickcalltel" href={"tel:" + val}>
                        {val}
                      </a>
                    </li>
                  );
                })}
            </ul>
          </span>
        );
        this.setState({
          call_dropdown: "call_" + parentid,
          call_dropdown_html: html
        });
      });
    }
  };

  handleCpmRedirect = parentid => {
    let CPM_URL =
      "../genio_lite/setEmpRedirect.php?data_city=" +
      this.props.datacity +
      "&parentid=" +
      parentid +
      "&user_type=" +
      getLocalStorage("user_type") +
      "&empcode=" +
      EMPCODE +
      "&deal=10&new_genio_redirect=" +
      urlencode("../genio_cpm/#/" + this.props.datacity + "/" + parentid + "/");
    localStorage.setItem("lite_url", window.location.href);
    window.location.href = CPM_URL;
  };

  handleEditListingRedirect = async parentid => {
    const { user, datacity, typeofemployee } = { ...this.props };
    let backUrl = window.location.href;

    let editAccessCheckParams = {
      jwt_ucode: EMPCODE,
      server_city: datacity,
      user_type: typeofemployee,
      onboarding_flag: "0",
      allocid: null,
      contractdata: {
        empcode: EMPCODE,
        parentid: parentid,
        data_city: datacity
      }
    };

    let editAccessRes = await chkContractEditAccess(editAccessCheckParams);

    if (editAccessRes.errorCode == 0 || editAccessRes.errorCode == 2) {
      let params = {
        jwt_ucode: EMPCODE,
        data_city: datacity,
        server_city: datacity,
        module: typeofemployee,
        objData: {
          empcode: EMPCODE,
          parentid: parentid,
          mobile: user.mobile_num,
          empname: user.empname,
          source: "allocation",
          url: backUrl
        },
        user_type: typeofemployee,
        allocid: getLocalStorage("allocId"),
        host: "sales.genio.in",
        urlflag: this.props.history.location.pathname
      };

      if (backUrl.includes("new-business")) {
        params.objData.newBusinessFlag = 1;
        getWebRedirectToken(params);
      } else {
        let shadowParams = {
          jwt_ucode: EMPCODE,
          data: parentid,
          server_city: datacity,
          empcode: EMPCODE,
          countrycode: 98,
          module: typeofemployee,
          parentid: parentid,
          getAllData: "",
          data_city: datacity,
          allocid: "S",
          bypass: typeofemployee == "ME" ? "0" : "1",
          user_type: typeofemployee
        };

        let shadowRes = await getShadowData(shadowParams);

        if (
          shadowRes != undefined &&
          shadowRes.tableData != undefined &&
          shadowRes.tableData.errorCode == 0
        ) {
          params.objData.data = shadowRes;
          getWebRedirectToken(params);
        } else {
          let liveParams = {
            jwt_ucode: EMPCODE,
            parentid: parentid,
            userid: EMPCODE,
            username: user.empname,
            server_city: datacity,
            minibform: "0",
            user_type: typeofemployee
          };
          let liveRes = await fetchLiveData(liveParams);
          if (liveRes.error.code == 0) {
            getWebRedirectToken(params);
          }
        }
      }
    } else if (editAccessRes.errorCode == 3) {
      console.log("freezed popup");
      this.setState({
        showMinipopup: true,
        miniPopupTitle: "Alert",
        miniPopupText: editAccessRes.freezeMsg
      });
    } else if (editAccessRes.errorCode == 4) {
      console.log("blocked popup");
      this.setState({
        showMinipopup: true,
        miniPopupTitle: "Alert",
        miniPopupText: editAccessRes.errorMsg
      });
    } else if (editAccessRes.errorCode == 5) {
      console.log("national listing redirect");
      console.log(editAccessRes);
    } else {
      console.log("edit access denied popup");
      //todo: reject downsell part is remaining
      this.setState({
        showMinipopup: true,
        miniPopupTitle: "Alert",
        miniPopupText: editAccessRes.errorMsg
      });
    }
  };

  popupHandleOk = () => {
    this.setState({
      showMinipopup: false,
      miniPopupTitle: "",
      miniPopupText: ""
    });
  };

  comingSoon = () => {
    this.setState({
      showMinipopup: true,
      miniPopupTitle: "Alert",
      miniPopupText: "COMING SOON..."
    });
  };

  instructionPopup = (companyname, miniPopupText) => {
    this.setState({
      showMinipopup: true,
      miniPopupTitle: companyname,
      miniPopupText
    });
  };

  showJdappStatus = index => {
    if (index || index == 0) {
      this.setState({ jdAppStatusShow: index });
    } else {
      this.setState({ jdAppStatusShow: "" });
    }
  };

  showJdmartStatus = index => {
    if (index || index == 0) {
      this.setState({ jdMartStatusShow: index });
    } else {
      this.setState({ jdMartStatusShow: "" });
    }
  };

  dealsPendingDeleteLink = parentid => {
    this.setState({
      showMinipopup: true,
      miniPopupTitle: "Alert",
      miniPopupText: "COMING SOON..."
    });
    //this.setState({ showMinipopup: true, miniPopupTitle: "Confirmation", miniPopupText: "Are you sure you want to delete JD pay link ?" });
  };

  dealsPendingResendLink = parentid => {
    const { datacity, typeofemployee } = { ...this.props };
    //const { resendJdPayLink } = { ...this.props };
    //http://sales.genio.in/genio_services/genio/resendJdPayLink
    // resendJdPayLink({
    // 	jwt_ucode: EMPCODE,
    // 	dataArr: { parentid: parentid, blockFlag: 1 },
    // 	data_city: datacity,
    // 	module: typeofemployee,
    // }).than((rdx_resendJdPayLink) => {
    // 	//let rdx_resendJdPayLink = this.props.resendJdPayLink;
    // 	console.log("rdx_resendJdPayLink", rdx_resendJdPayLink);
    // 	if (rdx_resendJdPayLink["errorCode"] == 0) {
    // 		this.setState({ showMinipopup: true, miniPopupTitle: "Success", miniPopupText: "JD Pay Link Resend Successfully" });
    // 	} else {
    // 		this.setState({ showMinipopup: true, miniPopupTitle: "Fail", miniPopupText: rdx_resendJdPayLink["errorStatus"] });
    // 	}
    // });
    this.setState({
      showMinipopup: true,
      miniPopupTitle: "Alert",
      miniPopupText: "COMING SOON..."
    });
    return true;
  };

  handleLoadMore = e => {
    this.props.handleLoadMore(e);
    this.setState({ loadMoreDisable: true }, () => {
      setTimeout(() => {
        this.setState({ loadMoreDisable: false });
      }, 700);
    });
  };

  render() {
    var that = this;
    const {
      contractData,
      lastDispositionData,
      empcode,
      ratings,
      full_addresses,
      campaignDetails,
      datacity,
      typeofemployee,
      history,
      dispositionReportType
    } = { ...this.props };

    let last_app_url = DOMAIN_INFO + that.props.history.location.pathname;
    last_app_url = last_app_url.replace(/\/\/+/g, "/");

    let currLink = getLocalStorage("currLink");
    let { DashboardLoader, parentidExpand, loadMoreDetails } = {
      ...this.state
    };
    if (DashboardLoader) {
      return <ContentLoader />;
    }

    if (contractData && contractData.length > 0) {
      let contractDataHtml = contractData.map((contract, index) => {
        let {
          compname,
          parentid,
          allocationTime,
          actionTime,
          actual_amt,
          proposed_amt,
          created_at,
          status,
          catalogue_url,
          companyname,
          instrumentAmount,
          tdsAmount,
          bouncedate,
          instrumentid,
          instrumentType,
          chequeNo,
          chequeDate,
          bankName,
          paymentType,
          PaymentPlan,
          tmename,
          reason,
          tme_mob_num,
          uptDate,
          exec_tmename,
          exec_tmecode,
          exec_mename,
          exec_mecode,
          dealcloseddt,
          is_jdpay_pending,
          status_text,
          instruction,
          cust_name,
          cust_id,
          updated_by,
          updated_at,
          master_transaction_id,
          bankClearanceRemarks
        } = { ...contract };
        //console.log("contract", catalogue_url);
        const downsell_module = contract.module;

        if (contractData.module == "bounce") {
          let { companyname, instrumentAmount } = { ...contract };

          compname = companyname;
          instrumentAmount = console.log("instrumentAmount", instrumentAmount);

          console.log("402", compname);
        }
        const { totalRating, ratstar, star } = {
          ...this.getRatings(ratings, parentid)
        };
        const { full_address, mobile_str } = {
          ...this.getFullAddressDetail(full_addresses, parentid)
        };
        const {
          businessKeywords,
          activeCampaign,
          active_for,
          expiry_status,
          fin_paid,
          website
        } = { ...this.getActiveCampaignDetails(campaignDetails, parentid) };

        var jdAppStatus = 0;
        if (
          mobile_str != undefined &&
          that.props.jd_app_download_status != undefined &&
          that.props.jd_app_download_status != ""
        ) {
          Object.keys(that.props.jd_app_download_status).map(num => {
            if (mobile_str.indexOf(num) > -1) {
              jdAppStatus = 1;
            }
          });
        }
        var jdMartStatus = 0;
        if (
          mobile_str != undefined &&
          that.props.jd_mart_download_status != undefined &&
          that.props.jd_mart_download_status != ""
        ) {
          Object.keys(that.props.jd_mart_download_status).map(num => {
            if (mobile_str.indexOf(num) > -1) {
              jdMartStatus = 1;
            }
          });
        }

        const disposition_name = this.getDispositionData(
          parentid,
          "disposition_name"
        );
        const diposition_date = this.getDispositionData(
          parentid,
          "diposition_date"
        );
        const mename = this.getDispositionData(parentid, "mename");
        //const tmename = this.getDispositionData(parentid, "tmename");
        const me_mobile_number = this.getDispositionData(
          parentid,
          "me_mobile_number"
        );
        //const tme_mob_num = this.getDispositionData(parentid, "tme_mob_num");
        const allocatedTo = contract.mename;
        const allocatedToEmpcode = contract.empcode;

        const uri =
          "https://sales.genio.in/genio_lite/#/whatsApp-msg/" +
          parentid +
          "/product";
        const uri_add_on_payment =
          "https://sales.genio.in/genio_lite/#/addon-payment/" + parentid + "/";
        const uri_external_mandate =
          "https://sales.genio.in/genio_lite/#/mandate-history/" +
          parentid +
          "/";
        const uri_booster =
          "https://sales.genio.in/genio_lite/#/booster/" + parentid + "/";
        const sr_no = index + 1;

        var currLink = window.location.hash.replace("#", "");

        let shouldLoadMore = loadMoreDetails.some(
          ele => ele.parentid == parentid && ele.instrumentid == instrumentid
        );

        return (
          <div className="appintlistwpr" key={parentid + "_" + index}>
            {this.state.jdAppStatusShow === index && (
              <JdAppStatusPopup
                showJdappStatus={this.showJdappStatus}
                mobile_str={mobile_str}
                jd_app_download_status={this.props.jd_app_download_status}
              />
            )}
            {this.state.jdMartStatusShow === index && (
              <JdMartStatusPopup
                showJdmartStatus={this.showJdmartStatus}
                mobile_str={mobile_str}
                jd_mart_download_status={this.props.jd_mart_download_status}
              />
            )}

            <div className="appintlistprnt">
              <div className="listhdrtbl">
                <div className="listhdrcell">
                  <div
                    className="listhdrname font15"
                    onClick={() => this.handleEditListingRedirect(parentid)}
                  >
                    {sr_no + ". " + compname}
                  </div>
                  <div className="listcontact font12">{parentid}</div>
                </div>
                <div className="listhdrcell listrighticon">
                  {fin_paid != undefined && fin_paid == 1 && (
                    <span className="gno_jdverifiedicn"></span>
                  )}
                  <span
                    className="gno_resultcall"
                    onClick={() => this.handleClickToCall(parentid)}
                  ></span>

                  {//click to call html
                  this.state.call_dropdown == "call_" + parentid &&
                    this.state.call_dropdown_html}
                </div>
              </div>
              {/* {full_address ? <div className="addresswpr font12">{full_address}</div> : <div className="addresswpr font12">hello</div>} */}
              {full_address && (
                <div className="addresswpr font12">{full_address}</div>
              )}
              {this.props.reportType != "downsell" &&
                contractData.module != "bounce" && (
                  <div className="strratingwpr">
                    <div className="rsltratnw">
                      <span className="rsltpoint font14">
                        {ratstar
                          ? Number(ratstar).toFixed(1)
                          : Number(0).toFixed(1)}
                      </span>
                      <span className="rsltstarnw">
                        {star &&
                          star.map((starVal, index) => (
                            <a key={index} className={`str${starVal}`}></a>
                          ))}
                        {/* <a className="str10"></a>
											<a className="str10"></a>
											<a className="str10"></a>
											<a className="str6"></a>
											<a className="str0"></a> */}
                      </span>
                      <div className="rsltrattxt font12">
                        {totalRating}&nbsp;Ratings
                      </div>
                    </div>
                  </div>
                )}
              {instrumentAmount &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr alignlist">
                    <span className="comnlisttext font11">
                      Instrument Amount :
                    </span>
                    <span className="comnlistprnt font12 leftalign">
                      {instrumentAmount ? instrumentAmount : "NA"}
                    </span>
                  </div>
                )}

              {this.props.reportType != "bounceReport" &&
                this.props.reportType != "downsell" &&
                mobile_str &&
                mobile_str.length > 0 && (
                  <div className="jdappdownload font12">
                    <i
                      className={
                        jdAppStatus == 1 ? "gno_checkbtn" : "gno_closebtn"
                      }
                    />{" "}
                    JD App Download Status
                    <i
                      className="info"
                      onClick={() => that.showJdappStatus(index)}
                    >
                      i
                    </i>
                  </div>
                )}

              {this.props.reportType != "downsell" &&
                mobile_str &&
                mobile_str.length > 0 && (
                  <div className="jdappdownload font12">
                    <i
                      className={
                        jdMartStatus == 1 ? "gno_checkbtn" : "gno_closebtn"
                      }
                    />{" "}
                    JD Mart Download Status
                    <i
                      className="info"
                      onClick={() => that.showJdmartStatus(index)}
                    >
                      i
                    </i>
                  </div>
                )}

              {tdsAmount !== null &&
                tdsAmount !== undefined &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr alignlist">
                    <div className="comnlisttext font11">TDS Amount :</div>
                    <div className="comnlistprnt font12 leftalign">
                      {tdsAmount !== null || tdsAmount !== undefined
                        ? tdsAmount
                        : "NA"}
                    </div>
                  </div>
                )}

              {bankClearanceRemarks &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr alignlist">
                    <div className="comnlisttext font11">Bounce Reason :</div>
                    <div className="comnlistprnt font12 leftalign">
                      {bankClearanceRemarks ? bankClearanceRemarks : "NA"}
                    </div>
                  </div>
                )}

              {bouncedate &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr alignlist">
                    <div className="comnlisttext font11">Bounce Date :</div>
                    <div className="comnlistprnt font12 leftalign">
                      {bouncedate ? bouncedate : "NA"}
                    </div>
                  </div>
                )}
              {shouldLoadMore &&
                instrumentid &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr alignlist">
                    <div className="comnlisttext font11">Bill desk ID :</div>
                    <div className="comnlistprnt font12 leftalign">
                      {instrumentid ? instrumentid : "NA"}
                    </div>
                  </div>
                )}

              {instrumentid &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr alignlist">
                    <div className="comnlisttext font11">Instrument Id :</div>
                    <div className="comnlistprnt font12 leftalign">
                      {instrumentid ? instrumentid : "NA"}
                    </div>
                  </div>
                )}

              {instrumentType &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr alignlist">
                    <div className="comnlisttext font11">Instrument Type :</div>
                    <div className="comnlistprnt font12 leftalign">
                      {instrumentType ? instrumentType : "NA"}
                    </div>

                    {/* <div className="comnlistprnt font12">{instrumentType ? instrumentType : "NA"}</div> */}
                  </div>
                )}
              {chequeNo &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr alignlist">
                    <div className="comnlisttext font11">Cheque No :</div>
                    <div className="comnlistprnt font12 leftalign">
                      {chequeNo ? chequeNo : "NA"}
                    </div>
                  </div>
                )}
              {chequeDate &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr alignlist">
                    <div className="comnlisttext font11">Cheque Date :</div>
                    <div className="comnlistprnt font12 leftalign">
                      {chequeDate ? chequeDate : "NA"}
                    </div>
                  </div>
                )}
              {chequeDate &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr alignlist">
                    <div className="comnlisttext font11">Deposite Date :</div>
                    <div className="comnlistprnt font12 leftalign">
                      {chequeDate ? chequeDate : "NA"}
                    </div>
                  </div>
                )}

              {bankName &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr alignlist">
                    <div className="comnlisttext font11">Bank Name :</div>
                    <div className="comnlistprnt font12 leftalign">
                      {bankName ? bankName : "NA"}
                    </div>
                  </div>
                )}

              {paymentType &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr alignlist">
                    <div className="comnlisttext font11">Payment Type :</div>
                    <div className="comnlistprnt font12 leftalign">
                      {paymentType ? paymentType : "NA"}
                    </div>
                  </div>
                )}

              {PaymentPlan &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr alignlist">
                    <div className="comnlisttext font11">Payment Plan :</div>
                    <div className="comnlistprnt font12 leftalign">
                      {PaymentPlan ? PaymentPlan : "NA"}
                    </div>
                  </div>
                )}

              {exec_tmename &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">Campaign Name:</div>
                    <div className="comnlistprnt font12">
                      TME : {exec_tmename ? exec_tmename : "NA"} |{" "}
                      {exec_tmecode ? exec_tmecode : "NA"}
                    </div>
                    <div className="comnlistprnt font12">
                      ME : {exec_mename ? exec_mename : "NA"} |{" "}
                      {exec_mecode ? exec_mecode : "NA"}
                    </div>
                    <div className="comnlisttext font11">
                      Deal closed date : {dealcloseddt ? dealcloseddt : "NA"}
                    </div>
                  </div>
                )}
              {actionTime && (
                <div className="comnlistwpr">
                  <div className="comnlisttext font11">
                    {dispositionReportType && dispositionReportType == 22
                      ? "Call Back"
                      : dispositionReportType && dispositionReportType == 24
                      ? "Follow Up"
                      : "Appointment"}{" "}
                    Date & Time
                  </div>
                  <div className="comnlistprnt font12">
                    {actionTime
                      ? Moment(actionTime).format("DD MMM YYYY | hh:mm A")
                      : "NA"}
                    &nbsp;|&nbsp;
                    {instruction && (
                      <a
                        className=""
                        onClick={() =>
                          this.instructionPopup(compname, instruction)
                        }
                        disabled={instruction == "" ? true : false}
                      >
                        Instructions
                      </a>
                    )}
                    {actionTime && (
                      <span
                        className="gno_soundicon"
                        onClick={e =>
                          this.props.showCallHistory(e, parentid, compname)
                        }
                      />
                    )}
                  </div>
                </div>
              )}
              {window.location.href.includes("disposition-report") && (
                <div className="comnlistwpr">
                  <div className="comnlisttext font11">Appointment Status</div>
                  <div className="comnlistprnt font12">
                    {contract["allocationType"] != undefined &&
                      (contract["allocationType"] == "25" ||
                        contract["allocationType"] == "99") &&
                      contract["cancel_flag"] != undefined &&
                      contract["cancel_flag"] == 1 && <span>Cancelled</span>}
                    {contract["cancel_flag"] != undefined &&
                      contract["cancel_flag"] != 1 && <span>NA</span>}
                  </div>
                </div>
              )}
              {allocatedTo &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">
                      Appointment Allocated To
                    </div>
                    <div className="comnlistprnt font12">
                      {allocatedTo ? allocatedTo : "NA"} |{" "}
                      {allocatedToEmpcode ? allocatedToEmpcode : "NA"}
                    </div>
                  </div>
                )}

              {allocationTime &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">
                      {dispositionReportType &&
                      [22, 24].indexOf(dispositionReportType) == -1
                        ? "Disposition Date & Time"
                        : "Appointment Allocated on"}
                    </div>
                    <div className="comnlistprnt font12">
                      {allocationTime
                        ? Moment(allocationTime).format("DD MMM YYYY | hh:mm A")
                        : "NA"}
                    </div>
                  </div>
                )}
              {(parentidExpand.includes(parentid) || shouldLoadMore) && (
                <div className="comnlistwpr">
                  <div className="comnlisttext font11">Business Keywords</div>
                  <div className="comnlistprnt font12">
                    {businessKeywords ? businessKeywords : "NA"}
                  </div>
                </div>
              )}
              {(parentidExpand.includes(parentid) || shouldLoadMore) &&
                currLink != "/deals-pending" &&
                currLink != "/deal-closed" && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">Active Campaigns</div>
                    <div className="comnlistprnt font12">
                      {activeCampaign ? activeCampaign : "NA"}
                    </div>
                  </div>
                )}

              {this.props.reportType != "bounceReport" &&
                website &&
                this.props.reportType != "downsell" &&
                (parentidExpand.includes(parentid) || shouldLoadMore) &&
                currLink != "/deals-pending" &&
                currLink != "/deal-closed" &&
                website.split(",").map((websiteUrl, index) => {
                  return (
                    <div className="comnlistwpr">
                      <div className="comnlisttext font11">Website URL</div>
                      {!helperFn.isMobile() && (
                        <a
                          href={"http://" + websiteUrl + "/?OPEN_OUTSIDE_APP=1"}
                        >
                          <div
                            className="comnlistprnt font12"
                            style={{ color: "#1274c0" }}
                          >
                            {websiteUrl}
                          </div>
                        </a>
                      )}
                      {helperFn.isMobile() && (
                        <a
                          href="javascript:void(0)"
                          onClick={() =>
                            helperFn.openInSide(
                              "http://" + websiteUrl,
                              "outside_app",
                              last_app_url
                            )
                          }
                        >
                          <div
                            className="comnlistprnt font12"
                            style={{ color: "#1274c0" }}
                          >
                            {websiteUrl}
                          </div>
                        </a>
                      )}
                    </div>
                  );
                })}
              {actual_amt &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">Actual Amount</div>
                    <div className="comnlistprnt font12">
                      {actual_amt ? actual_amt : "NA"}
                    </div>
                  </div>
                )}
              {proposed_amt &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">Proposed Amount</div>
                    <div className="comnlistprnt font12">
                      {proposed_amt ? proposed_amt : "NA"}
                    </div>
                  </div>
                )}
              {created_at &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">Requested on </div>
                    <div className="comnlistprnt font12">
                      {created_at
                        ? Moment(created_at).format("ddd Do MMM YYYY , hh:mm A")
                        : "NA"}
                    </div>
                  </div>
                )}
              {cust_name &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">Requested By :</div>
                    <div className="comnlistprnt font12">
                      {cust_name} | {cust_id}
                    </div>
                  </div>
                )}
              {!!status &&
                (parentidExpand.includes(parentid) || shouldLoadMore) &&
                currLink != "/deals-pending" && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">Status</div>
                    <div
                      className="comnlistprnt font12"
                      style={{
                        color:
                          status == 1
                            ? "#228b22"
                            : status == 2
                            ? "#ff0000"
                            : "#bdb600"
                      }}
                    >
                      {status == 1
                        ? "Approved"
                        : status == 2
                        ? "Rejected"
                        : "Pending for deal close"}
                      {status == 0 && (
                        <a
                          href="javscript:void(0)"
                          onClick={e => this.cancelDownsellRequest(e, parentid)}
                          style={{ color: "#1274c0" }}
                        >
                          {" "}
                          | Cancel Request
                        </a>
                      )}
                    </div>
                  </div>
                )}

              {this.props.reportType == "downsell" &&
                status == 0 &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">Status</div>
                    <div
                      className="comnlistprnt font12"
                      style={{
                        color:
                          status == 1
                            ? "#228b22"
                            : status == 2
                            ? "#ff0000"
                            : "#bdb600"
                      }}
                    >
                      {status == 1
                        ? "Approved"
                        : status == 2
                        ? "Rejected"
                        : "Pending"}
                      {!status && (
                        // <span style={{'color': '#4175d5','cursor':'pointer'}} onClick={this.pendingStatusCancelRequest()}> | Cancel Request </span>
                        <a
                          onClick={() =>
                            this.props.pendingStatusCancelRequest(
                              contract.id,
                              parentid,
                              contract.data_city,
                              contract.master_transaction_id,
                              contract.source
                            )
                          }
                          style={{ color: "#1274c0" }}
                        >
                          {" "}
                          | Cancel Request
                        </a> //this,loopData['contractid'],loopData['id'],loopData['master_transaction_id']
                      )}
                    </div>
                  </div>
                )}

              {this.props.reportType == "downsell" &&
                status == 2 &&
                parentidExpand.includes(parentid) && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">Reason</div>
                    <div className="comnlistprnt font12">
                      {reason ? reason : "N/A"}
                    </div>
                  </div>
                )}

              {updated_by &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">Updated By :</div>
                    <div className="comnlistprnt font12">{updated_by}</div>
                  </div>
                )}
              {updated_at &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">Updated On :</div>
                    <div className="comnlistprnt font12">{updated_at}</div>
                  </div>
                )}
              {downsell_module &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">
                      Downsell done through :{" "}
                    </div>
                    <div className="comnlistprnt font12">{downsell_module}</div>
                  </div>
                )}
              {expiry_status &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">Expiry Status</div>
                    <div className="comnlistprnt font12">
                      {expiry_status ? expiry_status : "NA"}
                    </div>
                  </div>
                )}

              {active_for &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">Active For</div>
                    <div className="comnlistprnt font12">
                      {active_for ? active_for : "NA"}
                    </div>
                  </div>
                )}

              {status_text &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">Status</div>
                    <div className="comnlistprnt font12">
                      {status_text ? status_text : "NA"}
                      {currLink == "/deals-pending" && (
                        <span
                          className=""
                          onClick={e =>
                            this.props.fetchPaymentSummary(
                              parentid,
                              master_transaction_id
                            )
                          }
                        >
                          <a className="moredtllink font11">
                            &nbsp;&nbsp;View Payment Details
                          </a>
                        </span>
                      )}
                    </div>
                  </div>
                )}

              {this.props.reportType != "downsell" &&
                currLink != "/disposition-report" &&
                contractData.module != "bounce" &&
                disposition_name &&
                (parentidExpand.includes(parentid) || shouldLoadMore) &&
                currLink != "/deals-pending" &&
                currLink != "/deal-closed" && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">Last Disposition</div>
                    <div className="comnlistprnt font12">
                      {/* {this.getDispositionData(parentid, "disposition_name")}| {this.getDispositionData(parentid, "diposition_date")} */}
                      {disposition_name ? disposition_name : "NA"} |{" "}
                      {diposition_date
                        ? Moment(diposition_date).format(
                            "DD MMM YYYY | hh:mm A"
                          )
                        : "NA"}
                    </div>
                  </div>
                )}

              {this.props.reportType != "bounceReport" &&
                this.props.reportType != "downsell" &&
                currLink != "/disposition-report" &&
                currLink != "/deals-pending" &&
                currLink != "/deal-closed" &&
                mename &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">Disposed By</div>
                    <div className="comnlistprnt font12">
                      {/* {this.getDispositionData(parentid, "mename")} | {this.getDispositionData(parentid, "mename") ? "ME" : ""} <span className="gno_resultcallwithcircle"></span> */}
                      {mename ? mename : "NA"}{" "}
                      {helperFn.isMobile() && me_mobile_number && (
                        <a
                          className="gno_resultcallwithcircle"
                          onClick={() => helperFn.CallMobile(me_mobile_number)}
                        >
                          &nbsp;
                        </a>
                      )}
                      {!helperFn.isMobile() && me_mobile_number && (
                        <a
                          className="gno_resultcallwithcircle"
                          href={"tel:" + me_mobile_number}
                        >
                          &nbsp;
                        </a>
                      )}
                    </div>
                  </div>
                )}
              {tmename &&
                (parentidExpand.includes(parentid) || shouldLoadMore) && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">TME Details</div>
                    <div className="comnlistprnt font12">
                      {/* {this.getDispositionData(parentid, "tmename")} <span className="gno_resultcallwithcircle"></span> */}
                      {tmename ? tmename : "NA"}{" "}
                      {helperFn.isMobile() && tme_mob_num && (
                        <a
                          className="gno_resultcallwithcircle"
                          onClick={() => helperFn.CallMobile(tme_mob_num)}
                        >
                          &nbsp;
                        </a>
                      )}
                      {!helperFn.isMobile() && tme_mob_num && (
                        <a
                          className="gno_resultcallwithcircle"
                          href={"tel:" + tme_mob_num}
                        >
                          &nbsp;
                        </a>
                      )}
                    </div>
                  </div>
                )}
              {currLink == "/allocations" ||
                (currLink == "/todays-allocations" &&
                  actionTime &&
                  (parentidExpand.includes(parentid) || shouldLoadMore) && (
                    <div className="comnlistwpr">
                      <div className="comnlisttext font11">Last Called:</div>
                      <div className="comnlistprnt font12">
                        {actionTime
                          ? Moment(actionTime).format("DD MMM YYYY | hh:mm A")
                          : "NA"}
                      </div>
                    </div>
                  ))}
              {(currLink == "/deal-closed" || currLink == "/deals-pending") &&
                uptDate &&
                (this.props.expand || parentidExpand == parentid) && (
                  <div className="comnlistwpr">
                    <div className="comnlisttext font11">Deal Date:</div>
                    <div className="comnlistprnt font12">
                      {uptDate
                        ? Moment(uptDate).format("DD MMM YYYY | hh:mm A")
                        : "NA"}
                    </div>
                  </div>
                )}
              {this.props.reportType != "downsell" &&
                (parentidExpand.includes(parentid) || shouldLoadMore) &&
                contractData.module != "bounce" && (
                  <div className="extrasrvswpr">
                    <a
                      onClick={() =>
                        handleGenioLiteRedirect(
                          parentid,
                          EMPCODE,
                          datacity,
                          typeofemployee,
                          uri_add_on_payment
                        )
                      }
                      style={{ color: "#000" }}
                    >
                      <span className="extrasrvslink">Add on Payment</span>
                    </a>
                    {" | "}
                    <a
                      onClick={() =>
                        handleGenioLiteRedirect(
                          parentid,
                          EMPCODE,
                          datacity,
                          typeofemployee,
                          uri_external_mandate
                        )
                      }
                      style={{ color: "#000" }}
                    >
                      <span className="extrasrvslink">External Mandate</span>
                    </a>
                    {" | "}
                    <a
                      onClick={() =>
                        handleGenioLiteRedirect(
                          parentid,
                          EMPCODE,
                          datacity,
                          typeofemployee,
                          uri_booster
                        )
                      }
                      style={{ color: "#000" }}
                    >
                      <span className="extrasrvslink">Booster</span>
                    </a>
                    {window.location.href.includes("disposition-report") && (
                      <div>
                        <a
                          onClick={e =>
                            this.props.tmeUserRedirection(
                              parentid,
                              compname,
                              "tracker-report"
                            )
                          }
                          style={{ color: "#000" }}
                        >
                          <span className="extrasrvslink">Tracker Report</span>
                        </a>
                        {" | "}
                        <a
                          onClick={e => e.preventDefault()}
                          style={{ color: "#000" }}
                        >
                          <span className="extrasrvslink">Statement</span>
                        </a>
                        {" | "}
                        <a
                          onClick={e =>
                            this.props.tmeUserRedirection(
                              parentid,
                              compname,
                              "generateInvoice"
                            )
                          }
                          style={{ color: "#000" }}
                        >
                          <span className="extrasrvslink">
                            Generate Invoice
                          </span>
                        </a>
                      </div>
                    )}
                    {currLink == "/deals-pending" && is_jdpay_pending == 1 && (
                      <span>
                        {" | "}
                        <a
                          onClick={() => this.dealsPendingDeleteLink(parentid)}
                          style={{ color: "#000" }}
                        >
                          <span className="extrasrvslink">
                            Delete Jd Pay Link
                          </span>
                        </a>
                        {" | "}
                        <a
                          onClick={() => this.dealsPendingResendLink(parentid)}
                          style={{ color: "#000" }}
                        >
                          <span className="extrasrvslink">
                            Resend Jd Pay Link
                          </span>
                        </a>
                      </span>
                    )}
                  </div>
                )}

              <div className="moredtlwpr">
                {this.props.reportType != "bounceReport" &&
                  !(parentidExpand.includes(parentid) || shouldLoadMore) && (
                    <div className="moredtltbl">
                      <div
                        className="moredtlcell"
                        onClick={e =>
                          this.handleParentIdExpand(
                            e,
                            parentid,
                            true,
                            instrumentid
                          )
                        }
                      >
                        <a className="moredtllink font11">More Details</a>
                      </div>
                      <div
                        className="moredtlcell settingicnprnt"
                        onClick={() => this.handleCpmRedirect(parentid)}
                      >
                        <span className="gno_settingicn"></span>
                      </div>
                    </div>
                  )}
                {this.props.reportType != "bounceReport" &&
                  (parentidExpand.includes(parentid) || shouldLoadMore) && (
                    <div className="moredtltbl">
                      <div
                        className="moredtlcell"
                        onClick={e =>
                          this.handleParentIdExpand(
                            e,
                            parentid,
                            false,
                            instrumentid
                          )
                        }
                      >
                        <a className="moredtllink font11">Hide Details</a>
                      </div>
                      <div
                        className="moredtlcell settingicnprnt"
                        onClick={() => this.handleCpmRedirect(parentid)}
                      >
                        <span className="gno_settingicn"></span>
                      </div>
                    </div>
                  )}
              </div>

              <div className="moredtlwpr">
                {this.props.reportType == "bounceReport" &&
                  !loadMoreDetails.some(
                    ele =>
                      ele.parentid == parentid &&
                      ele.instrumentid == instrumentid
                  ) && (
                    <div className="moredtltbl">
                      <div
                        className="moredtlcell"
                        onClick={e =>
                          this.handleMoreDetails(
                            e,
                            parentid,
                            instrumentid,
                            true
                          )
                        }
                      >
                        <a className="moredtllink font11">More Details</a>
                      </div>
                      {this.props.reportType != "bounceReport" && (
                        <div
                          className="moredtlcell settingicnprnt"
                          onClick={() => this.handleCpmRedirect(parentid)}
                        >
                          <span className="gno_settingicn"></span>
                        </div>
                      )}
                    </div>
                  )}
                {this.props.reportType == "bounceReport" &&
                  loadMoreDetails.some(function(ele) {
                    return (
                      ele.parentid == parentid &&
                      ele.instrumentid == instrumentid
                    );
                  }) && (
                    <div className="moredtltbl">
                      <div
                        className="moredtlcell"
                        onClick={e =>
                          this.handleMoreDetails(
                            e,
                            parentid,
                            instrumentid,
                            false
                          )
                        }
                      >
                        <a className="moredtllink font11">Hide Details</a>
                      </div>
                      {this.props.reportType != "bounceReport" && (
                        <div
                          className="moredtlcell settingicnprnt"
                          onClick={() => this.handleCpmRedirect(parentid)}
                        >
                          <span className="gno_settingicn"></span>
                        </div>
                      )}
                    </div>
                  )}
              </div>

              {this.props.reportType != "downsell" &&
                contractData.module != "bounce" && (
                  <div className="sociallinkwpr">
                    <span className="sociallinkprnt font11">
                      <a
                        onClick={() => {
                          let companyTitle =
                            compname && compname.length > 26
                              ? compname.substring(0, 26) + "..."
                              : compname;
                          setLocalStorage("whatsap_compname", companyTitle);
                          history.push({
                            pathname:
                              "/whatsapp-msg/" + parentid + "/jdgodigital",
                            state: {
                              parentid: parentid,
                              currLink: currLink,
                              sharevia: "whatsapp"
                            }
                          });
                        }}
                        style={{ color: "#000" }}
                      >
                        <span className="gno_whatsupicon"></span>WhatsApp
                      </a>
                    </span>

                    {/* {["/assignments/digi-cat-email-campaign", "/assignments/catalogue-data", "/assignments/popular-b2b-data"].indexOf(currLink) != "-1" && (
										<span className="sociallinkprnt font11">
											<a
												onClick={() =>
													["/assignments/digi-cat-email-campaign", "/assignments/catalogue-data", "/assignments/popular-b2b-data"].indexOf(currLink) != "-1"
														? history.push({
																pathname: "/whatsapp-msg/" + parentid + "/jdgodigital",
																state: { parentid: parentid, currLink: currLink, sharevia: "sms" },
														  })
														: this.comingSoon()
												}
												style={{ color: "#000" }}
											>
												<span className="gno_smsicon"></span>SMS
											</a>
										</span>
									)}

									{["/assignments/digi-cat-email-campaign", "/assignments/catalogue-data", "/assignments/popular-b2b-data"].indexOf(currLink) != "-1" && (
										<span className="sociallinkprnt font11">
											<a
												onClick={() =>
													["/assignments/digi-cat-email-campaign", "/assignments/catalogue-data", "/assignments/popular-b2b-data"].indexOf(currLink) != "-1"
														? history.push({
																pathname: "/whatsapp-msg/" + parentid + "/jdgodigital",
																state: { parentid: parentid, currLink: currLink, sharevia: "email" },
														  })
														: this.comingSoon()
												}
												style={{ color: "#000" }}
											>
												<span className="gno_emailicon"></span>Email
											</a>
										</span>
									)} */}
                  </div>
                )}
            </div>
          </div>
        );
      });

      let totalContractData = this.props.totalContractData || 0;
      return (
        <div>
          {this.state.showMinipopup && (
            <Minipopup
              title={this.state.miniPopupTitle}
              text={this.state.miniPopupText}
              handleOk={this.popupHandleOk}
              okPopup={true}
            />
          )}
          {contractDataHtml}
          {contractData &&
            contractData.length > 0 &&
            totalContractData != contractData.length && (
              <div className="appintlistwpr">
                <div
                  className="appintlistprnt"
                  onClick={e => this.handleLoadMore(e)}
                  style={{
                    textAlign: "center",
                    color: "#1274c0",
                    fontWeight: 600
                  }}
                >
                  Load More
                </div>
              </div>
            )}
        </div>
      );
    } else {
      return (
        <div className="fnotfoundwpr" style={{ height: "60vh" }}>
          <div className="fnotfoundprnt">
            <img src={PATH_INFO + "/dev/src/media/img/filenotfound.svg"} />
            <div className="fnotfoundtext font18">Data Not Found</div>
          </div>
        </div>
      );
    }
  }
  // )
}

ContractModal.propTypes = {
  contractData: PropTypes.array.isRequired
};

function mapStateToProps(state) {
  return {
    typeofemployee: state.jd_store.typeofemployee,
    lastDispositionData: state.jd_store.lastDispositionData || "",
    empcode: state.jd_store.empcode || "",
    datacity: state.jd_store.datacity,
    ratings: state.jd_store.ratings || [],
    campaignDetails: state.jd_store.campaignDetails || "",
    full_addresses: state.jd_store.full_addresses || [],
    mobile_str: state.jd_store.mobile_str || [],
    jd_app_download_status: state.jd_store.jd_app_download_status || "",
    jd_mart_download_status: state.jd_store.jd_mart_download_status || "",
    clickCallMobileNumber: state.jd_store.clickCallMobileNumber || [],
    user: state.jd_store.user || {},
    dataLoaded: state.jd_store.dataLoaded
  };
}

const mapDispatchToProps = dispatch => {
  return {
    getLastDisposition: params => dispatch(getLastDisposition(params)),
    getActionData: (params, type, apiUrl) =>
      dispatch(getActionData(params, type, apiUrl)),
    getMobileNumber: params => dispatch(getMobileNumber(params)),
    JDAppdownloadstatus: params => dispatch(JDAppdownloadstatus(params)),
    JDMartdownloadstatus: params => dispatch(JDMartdownloadstatus(params))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ContractModal);
