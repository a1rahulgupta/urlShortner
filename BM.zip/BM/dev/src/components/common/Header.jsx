import React, { Component } from "react";
import { Link } from "react-router-dom";

class Header extends Component {
  constructor(props) {
    super(props);
  }
  componentDidMount() {}
  handleLeftHeaderClick = () => {
    this.props.props.goBack();
  };
  render() {
    let stateObj = {};
    if (this.props.props.location.state) {
      stateObj = this.props.props.location.state;
    }

    return (
      <header className="hdrWrp hdrDetail hdrWhiteBg">
        {console.log("====---=-=-=-", stateObj)}
        <div className="header dtable">
          {this.props.pathname != "/select-users" ? (
            <div className="hdrMnuWprleft">
              <div
                className="iconbox hdrMnuback cursorPointer"
                onClick={() => this.handleLeftHeaderClick()}
              ></div>
            </div>
          ) : (
            ""
          )}
          {this.props.pathname.includes("select-users") ? (
            <div className="hdrLogoWpr">
              <div className="font16 color414 fw600 text-center ">
                {" "}
                Select Users{" "}
              </div>
            </div>
          ) : (
            ""
          )}
          {this.props.pathname == "/campaign-selection" ? (
            <div className="hdrLogoWpr">
              <div className="font16 color414 fw600 text-center ">
                Campaign Selection
              </div>
            </div>
          ) : (
            ""
          )}
          {this.props.pathname == "/bulk-upload" ? (
            <div className="hdrLogoWpr">
              <div className="font16 color414 fw600 text-center ">
                Bulk Upload
              </div>
            </div>
          ) : (
            ""
          )}
          {this.props.pathname == "/bulk-upload-report" ? (
            <div className="hdrLogoWpr">
              <div className="font16 color414 fw600 text-center ">
                Bulk Upload Report
              </div>
            </div>
          ) : (
            ""
          )}
          {this.props.pathname == "/select-cities" ? (
            <div className="hdrLogoWpr">
              <div className="font16 color414 fw600 text-center ">
                {" "}
                Select Cities{" "}
              </div>
            </div>
          ) : (
            ""
          )}
          {this.props.pathname == "/select-campaign" ? (
            <div className="hdrLogoWpr">
              <div className="font16 color414 fw600 text-center ">
                {" "}
                Select Campaign{" "}
              </div>
            </div>
          ) : (
            ""
          )}
          {this.props.pathname == "/select-variant" ? (
            <div className="hdrLogoWpr">
              <div className="font16 color414 fw600 text-center ">
                {" "}
                {stateObj?.campname}{" "}
              </div>
            </div>
          ) : (
            ""
          )}
          {this.props.pathname == "/plan-budget/" + stateObj?.campid ? (
            <div className="hdrLogoWpr">
              <div className="font16 color414 fw600 text-center ">
                {" "}
                {stateObj?.campname}-{stateObj?.variantType}{" "}
              </div>
            </div>
          ) : (
            ""
          )}
          {this.props.pathname == "/discount" ? (
            <div className="hdrLogoWpr">
              <div className="font16 color414 fw600 text-center ">
                {" "}
                Discount{" "}
              </div>
            </div>
          ) : (
            ""
          )}
          {this.props.pathname == "/freeAddOn-product" ? (
            <div className="hdrLogoWpr">
              <div className="font16 color414 fw600 text-center ">
                {" "}
                Free Add-on Product{" "}
              </div>
            </div>
          ) : (
            ""
          )}
          {this.props.pathname == "/budget-window-time" ? (
            <div className="hdrLogoWpr">
              <div className="font16 color414 fw600 text-center ">
                {" "}
                Budget Window Time{" "}
              </div>
            </div>
          ) : (
            ""
          )}
          <div className="hdrMnuWprright text-right">
            <div className="iconbox hdrMnuclose cursorPointer dn"> </div>
          </div>
          {this.props.pathname == "/ChooseTop5Plan" ? (
            <div className="hdrLogoWpr">
              <div className="font16 color414 fw600 text-center ">
                {" "}
                Choose Top 5 Plans{" "}
              </div>
            </div>
          ) : (
            ""
          )}

          {this.props.pathname == "/UpdateAddOn/" + stateObj?.campid ? (
            <div className="hdrLogoWpr">
              <div className="font16 color414 fw600 text-center ">
                {" "}
                {stateObj?.campname}
              </div>
            </div>
          ) : (
            ""
          )}
          {this.props.pathname == "/emi-disable-enable/" + stateObj?.campid ? (
            <div className="hdrLogoWpr">
              <div className="font16 color414 fw600 text-center ">
                {" "}
                {"Select  Tenure`"}
              </div>
            </div>
          ) : (
            ""
          )}
          {this.props.pathname == "/dpCount/" + stateObj?.campid ? (
            <div className="hdrLogoWpr">
              <div className="font16 color414 fw600 text-center ">
                {" "}
                {"Select EMIs"}
              </div>
            </div>
          ) : (
            ""
          )}
        </div>
      </header>
    );
  }
}
export default Header;
