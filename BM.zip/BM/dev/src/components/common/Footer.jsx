import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";

import { connect } from "react-redux";
import { handleGenioLiteRedirect } from "../../utilities/helperFunctions";
import * as helperFn from "./HelperFunc";
import { toggleHistory } from "../../redux/actions/userActions";
import CryptoEncryption from "../../utilities/CryptoEncryption";
//nonceValue same as loginToMasterDashboard
var nonceValue = "l45bwsdioHds56lfglstuyuyPlyt23l2m3n";
const cryptoEncryption = new CryptoEncryption();
const enc_empcode = cryptoEncryption.encrypt(
  JSON.stringify({ empcode: EMPCODE, module: "sales_genio" }),
  nonceValue
);

class Footer extends Component {
  constructor(props) {
    super(props);
  }
  redirectHandle = (url, last_app_url) => {
    if (helperFn.isMobile()) {
      helperFn.openInSide(url, "inside_app", last_app_url);
    } else {
      window.location.href = url;
    }
  };

  render() {
    const last_app_url =
      DOMAIN_INFO + "/sales_genio/#" + this.props.location.pathname;
    const { user, typeofemployee, datacity } = { ...this.props };
    const notificationUri = "https://sales.genio.in/notifications/#/";
    const newBusinessUri = "https://sales.genio.in/genio_lite/#/addNewBusiness";
    const learningUri = "https://sales.genio.in/genio_lite/#/learning/";
    const back_uri = window.location.href;
    let currLink = window.location.hash.replace("#", "");
    let activeClass =
      currLink == "/allocations" || "/todays-allocations" ? " act" : "";
    return (
      <div>
        {/*footer*/}
        <div className="footerwpr">
          <div className="ftrtbl">
            <Link
              className={"ftrtblcell" + activeClass}
              to={"/todays-allocations"}
              style={{ color: "#252525" }}
              onClick={() => this.props.toggleHistory({ toggle: false })}
            >
              <span className="gno_homeicon" />
              <span className="ftrtext font10">Home</span>
            </Link>
            <a
              className="ftrtblcell"
              onClick={() =>
                this.redirectHandle(
                  "https://sales.genio.in/sales_genio/Utility/loginToMasterDashboard.php?params=" +
                    enc_empcode,
                  last_app_url
                )
              }
              style={{ color: "#252525" }}
            >
              <span className="gno_dashboard" />
              <span className="ftrtext font10">Dashboard</span>
            </a>
            <a
              className="ftrtblcell"
              onClick={() => this.props.history.push("/create-new-business/")}
            >
              <span className="ftr_pluslink">+</span>
            </a>
            <a
              className="ftrtblcell"
              onClick={() =>
                handleGenioLiteRedirect(
                  "",
                  EMPCODE,
                  datacity,
                  typeofemployee,
                  notificationUri
                )
              }
              style={{ color: "#252525" }}
            >
              <span className="gno_notification" />
              <span className="ftrtext font10">Notification</span>
            </a>
            <a
              className="ftrtblcell"
              onClick={() =>
                handleGenioLiteRedirect(
                  "",
                  EMPCODE,
                  datacity,
                  typeofemployee,
                  learningUri
                )
              }
              style={{ color: "#252525" }}
            >
              <span className="gno_learning" />
              <span className="ftrtext font10">Learning</span>
            </a>
          </div>
        </div>
        {/*footer*/}
      </div>
    );
  }
}

function mapStateToProps(state, props) {
  return {
    user: state.jd_store.user || "",
    typeofemployee: state.jd_store.typeofemployee || "",
    datacity: state.jd_store.datacity
  };
}

const mapDispatchToProps = dispatch => {
  return {
    toggleHistory: params => dispatch(toggleHistory(params))
  };
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Footer));
