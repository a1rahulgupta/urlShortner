import React, { Component } from "react";
import { Route, Switch, withRouter } from "react-router-dom";
import { connect } from "react-redux";
import { ComponentLoader, ContentLoader } from "./common/ComponentLoader";

import { getFAQDetails } from "./../redux/actions/userActions";

function debounce(a, b, c) {
  var d, e;
  return function() {
    function h() {
      (d = null), c || (e = a.apply(f, g));
    }
    var f = this,
      g = arguments;
    return (
      clearTimeout(d), (d = setTimeout(h, b)), c && !d && (e = a.apply(f, g)), e
    );
  };
}

class Faq extends Component {
  constructor(props) {
    super(props);
    this.state = {
      FaqLoader: true,
      expand: "",
      datacity: this.props.datacity,
      empcode: EMPCODE,
      searchInputVal: null
    };
    this.textInput = React.createRef();
  }

  componentDidMount() {
    const { getFAQDetails, datacity } = { ...this.props };
    Promise.all([
      getFAQDetails({
        jwt_ucode: EMPCODE,
        data_city: datacity,
        empcode: EMPCODE
      })
    ]).then(() => {
      this.setState({ ...this.state, FaqLoader: false });
    });
  }

  expandFaq = (e, faq_id) => {
    if (faq_id === this.state.expand)
      this.setState({ ...this.state, expand: "" });
    else this.setState({ ...this.state, expand: faq_id });
  };

  setSearchTerm = debounce(searchTerm => {
    if (!searchTerm) {
      this.handleClear();
    } else {
      this.setState({ FaqLoader: false, searchInputVal: searchTerm });
      var params = {
        jwt_ucode: EMPCODE,
        data_city: this.state.datacity,
        empcode: EMPCODE,
        srchStr: searchTerm
      };
      Promise.all([this.props.getFAQDetails(params)]).then(() => {
        this.setState({ FaqLoader: false });
      });
    }
  }, 700);

  handleClear = e => {
    this.textInput.current.value = "";
    this.textInput.current.focus = true;
    this.setState((state, props) => {
      return {
        searchInputVal: null
      };
    });
    var params = {
      jwt_ucode: EMPCODE,
      data_city: this.state.datacity,
      empcode: EMPCODE
    };
    Promise.all([this.props.getFAQDetails(params)]).then(() => {
      this.setState({ FaqLoader: false });
    });
  };

  render() {
    let { faq_details } = { ...this.props };
    if (this.state.FaqLoader == true) {
      return <ComponentLoader LoaderName="FaqLoader" />;
    }
    let searchInputVal = this.state.searchInputVal || null;
    let faqList = "";
    if (faq_details && faq_details.length > 0) {
      faqList = faq_details.map((faq_detail, index) => {
        let { question, answer, anchor_link } = { ...faq_detail };
        answer = JSON.parse(answer);
        let answers = Object.values(answer);
        let ans_str = "";
        if (answers && answers.length > 0) {
          ans_str = answers.map((ans, index2) => {
            return index2 > 0
              ? "<br/>" + (index2 + 1) + ". " + ans
              : index2 + 1 + ". " + ans;
          });
        }

        return (
          <div className="faqprnt font13" key={"FAQ_" + index}>
            <div
              className="faqtitle"
              onClick={e => this.expandFaq(e, "FAQ_" + index)}
            >
              {question}
              {this.state.expand != undefined &&
              this.state.expand == "FAQ_" + index ? (
                <span className="gno_uparrow" />
              ) : (
                <span className="gno_downarrow" />
              )}
            </div>
            {this.state.expand != undefined &&
              this.state.expand == "FAQ_" + index && (
                <div
                  className={"faqcontent " + "FAQ_" + index}
                  dangerouslySetInnerHTML={{ __html: ans_str }}
                />
              )}
          </div>
        );
      });
    }
    return (
      <>
        <div className="mainsearch">
          <div className="inputouter">
            <input
              type="text"
              className="inputarea font16"
              name="search_box"
              ref={this.textInput}
              //tabIndex="1"
              defaultValue={searchInputVal}
              onChange={e => {
                this.setSearchTerm(e.target.value);
              }}
              placeholder="Search FAQ"
            />
            <span className="searchIcon" />
            {searchInputVal && searchInputVal.length > 0 && (
              <span className="gno_clear" onClick={e => this.handleClear(e)} />
            )}
          </div>
        </div>
        <div className="mainwpr">{faqList}</div>
      </>
    );
  }
}

function mapStateToProps(state, props) {
  return {
    user: state.jd_store.user || "",
    typeofemployee: state.jd_store.typeofemployee || "",
    datacity: state.jd_store.datacity || "",
    faq_details: state.jd_store.faq_details || ""
  };
}

const mapDispatchToProps = dispatch => {
  return {
    getFAQDetails: params => dispatch(getFAQDetails(params))
  };
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Faq));
