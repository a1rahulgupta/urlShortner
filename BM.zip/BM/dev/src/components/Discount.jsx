import React, { Component } from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";

import {
  fetchPlanAndBudgetDetail,
  updateDiscount
} from "./../redux/actions/userActions";
import Minipopup from "./common/Minipopup";

class Discount extends Component {
  constructor(props) {
    super(props);
    this.state = {
      upfront_discount: 0,
      emi_discount: {},
      ecsDiscount: 0,
      dataCity: "",
      dataCityArr: [],
      showMinipopup: false,
      miniPopupText: "",
      miniPopupTitle: ""
    };
    this.onChangeUpfrontDiscount = this.onChangeUpfrontDiscount.bind(this);
    this.onChangeEMIDiscount = this.onChangeEMIDiscount.bind(this);
    this.fetchPlanAndBudgetDetailsHandler = this.fetchPlanAndBudgetDetailsHandler.bind(
      this
    );
    this.skipToNext = this.skipToNext.bind(this);
  }
  componentDidMount() {
    if (
      this.props.selectCityArrDetails &&
      this.props.selectCityArrDetails.length > 0
    ) {
      (this.state.dataCity = this.props.selectCityArrDetails[0]),
        (this.state.dataCityArr = this.props.selectCityArrDetails);
    }

    this.fetchPlanAndBudgetDetailsHandler();
  }
  fetchPlanAndBudgetDetailsHandler = () => {
    Promise.all([
      this.props.fetchPlanAndBudgetDetail({
        data_city: this.state.dataCity,
        variant: this.props.match.params.variant
        // isTempBudget: localStorage.getItem('isTempBudget')
      })
    ]).then(() => {
      if (
        this.props.PlanAndBudgetDetails &&
        this.props.PlanAndBudgetDetails.data[0]
      ) {
        if (this.props.PlanAndBudgetDetails.data[0].maximum_discount) {
          // console.log("this.props.fetPlanAndBudgetData---", this.props.PlanAndBudgetDetails)
          this.setState({
            upfront_discount: this.props.PlanAndBudgetDetails.data[0]
              .maximum_discount
          });
        }
        if (this.props.PlanAndBudgetDetails.data[0].emi_options) {
          // console.log("this.props.fetPlanAndBudgetData---", this.props.PlanAndBudgetDetails)
          this.setState({
            emi_discount: JSON.parse(
              this.props.PlanAndBudgetDetails.data[0].emi_options
            )
          });
        }
      }
    });
  };

  updateDiscountHandler = () => {
    if (this.state.upfront_discount == 0 || this.state.upfront_discount == "") {
      this.setState({
        miniPopupText: "Please enter proper upfront discount amount ",
        showMinipopup: true
      });
      return;
    }
    Promise.all([
      this.props.updateDiscount({
        data_city: this.state.dataCityArr,
        campaign_id: this.props.match.params.variant,
        upfront_discount: this.state.upfront_discount,
        emi_discount: this.state.emi_discount,
        empcode: EMPCODE,
        username: "",
        // isTempBudget: localStorage.getItem('isTempBudget'),
        prev_value: {
          upfront_discount: this.props.PlanAndBudgetDetails.data[0]
            .maximum_discount,
          emi_discount: this.props.PlanAndBudgetDetails.data[0].emi_options
            ? JSON.parse(this.props.PlanAndBudgetDetails.data[0].emi_options)
            : {}
        },
        current_value: {
          upfront_discount: this.state.upfront_discount,
          emi_discount: this.state.emi_discount
        }
      })
    ]).then(() => {
      console.log("props=");
      this.props.history.push(
        "/freeAddOn-product/" + this.props.match.params.variant
      );
    });
  };
  skipToNext() {
    this.props.history.push(
      "/freeAddOn-product/" + this.props.match.params.variant
    );
  }
  onChangeUpfrontDiscount(e) {
    console.log("e==", e);
    this.setState({
      upfront_discount: e.target.validity.valid ? e.target.value : 0
    });
  }
  //  ;
  onChangeEMIDiscount(e, months, key) {
    console.log("e==", e.target.value, key, months);
    let temp = { ...this.state.emi_discount[months] };
    let discountValue = e.target.validity.valid ? e.target.value : 0;
    temp["discount"] = discountValue ? parseInt(discountValue) : 0;
    console.log(temp);
    this.setState(prevState => ({
      emi_discount: { ...prevState.emi_discount, [months]: temp }
    }));
  }

  closeAlert = () => {
    this.setState({ showMinipopup: false });
  };
  render() {
    if (this.state.showMinipopup) {
      return (
        <Minipopup
          title={this.state.miniPopupTitle}
          text={this.state.miniPopupText}
          handleOk={this.closeAlert}
          okPopup={true}
        />
      );
    }
    console.log("====");
    let { emi_discount } = this.state;
    return (
      <div className=" wrapper-block pb-30">
        <div className="font14 color414 fw600 pl-20 pr-20 pt-20">
          {" "}
          Select Discount{" "}
        </div>
        <div className="wrapper-block pl-20 pr-20 pt-20">
          <ul className="typeAWrp wrapper-block ">
            <li className="selUserLi dtable  color1a1 pl-15  csrpntr">
              <div className="dtable pb-20">
                <div className="dtablecell">
                  <span className="font14 fw600"> Upfront Plan (in %) </span>
                </div>
                <div className="dtablecell switchwidth text-right">
                  <label className="dtablecell switch">
                    <input type="checkbox" />
                    <span className="slider"></span>
                  </label>
                </div>
              </div>
              <div className="dtable">
                <div className="leftDiscText font14 color788 fw500">
                  {" "}
                  Enter Discount{" "}
                </div>
                <div className=" rightDiscWidth">
                  <div className="group">
                    <input
                      className="inputMaterial fw600 text-right"
                      pattern="[0-9]*"
                      maxLength="8"
                      type="text"
                      required=""
                      onChange={this.onChangeUpfrontDiscount}
                      value={this.state.upfront_discount}
                    />
                    <span className="bar"></span>
                  </div>
                </div>
              </div>
            </li>
            <li className="selUserLi dtable  color1a1 pl-15  csrpntr">
              <div className="dtable pb-20">
                <div className="dtablecell">
                  <span className="font14 fw600"> EMI Discount (in %) </span>
                </div>
                <div className="dtablecell switchwidth text-right">
                  <label className="dtablecell switch">
                    <input type="checkbox" />
                    <span className="slider"></span>
                  </label>
                </div>
              </div>
              {Object.keys(emi_discount).map((value, key) => {
                console.log("value", value, key);

                return (
                  <div key={key} className="dtable">
                    <div className="leftDiscText font14 color788 fw500">
                      {" "}
                      {emi_discount[value]["emi_months"]} EMIs
                    </div>
                    <div className=" rightDiscWidth">
                      <div className="group">
                        <input
                          className="inputMaterial fw600 text-right"
                          pattern="[0-9]*"
                          maxLength="8"
                          type="text"
                          required=""
                          onChange={e =>
                            this.onChangeEMIDiscount(e, value, key)
                          }
                          value={emi_discount[value]["discount"]}
                        />
                        <span className="bar"></span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </li>
          </ul>
        </div>
        {/* <Link to={"/freeAddOn-product/" + this.props.match.params.variant}>  */}
        <div className="btmFixBtn">
          <button
            className="ftrBlueBtn white font16"
            onClick={() => {
              this.skipToNext();
            }}
          >
            {" "}
            Skip{" "}
          </button>
          <button
            className="ftrBlueBtn font16"
            onClick={() => {
              this.updateDiscountHandler();
            }}
          >
            {" "}
            Proceed{" "}
          </button>
        </div>
        {/* </Link> */}
      </div>
    );
  }
}

function mapStateToProps(state, props) {
  return {
    PlanAndBudgetDetails: state.jd_store.fetPlanAndBudgetData,
    selectCityArrDetails: state.jd_store.selectCityArrData
  };
}

const mapDispatchToProps = dispatch => {
  return {
    fetchPlanAndBudgetDetail: params =>
      dispatch(fetchPlanAndBudgetDetail(params)),
    updateDiscount: params => dispatch(updateDiscount(params))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Discount);
