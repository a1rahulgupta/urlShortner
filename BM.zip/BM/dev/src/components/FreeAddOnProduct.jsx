import React, { Component } from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import {
  updateAddOnPrice,
  fetchCampaignList,
  getCampaignPriceForProduct
} from "./../redux/actions/userActions";

class FreeAddOnProduct extends Component {
  constructor(props) {
    super(props);
    this.state = {
      addon_pricing: {},
      child_data: [],
      dataCity: "",
      dataCityArr: [],
      addons: {
        resSqlQueryForAddOns: [
          {
            campid: 4,
            campname: "JDRR Certificate"
          },
          {
            campid: 7,
            campname: "Mobile Application"
          },
          {
            campid: 8,
            campname: "iPhone App"
          },
          {
            campid: 9,
            campname: "Android App"
          },
          {
            campid: 11,
            campname: "Website & Mobile Site"
          },
          {
            campid: 12,
            campname: "Your Own Website"
          },
          {
            campid: 25,
            campname: "Rotational Web Banner"
          },
          {
            campid: 26,
            campname: "SMS Promo"
          },
          {
            campid: 28,
            campname: "Banner National Listing"
          },
          {
            campid: 29,
            campname: "CRISIL"
          },
          {
            campid: 30,
            campname: "JDRR User Choice"
          },
          {
            campid: 39,
            campname: "Rotational Social Banner"
          },
          {
            campid: 104,
            campname: "Jd Verified"
          },
          {
            campid: 103,
            campname: "Jd Trusted"
          },
          {
            campid: 43,
            campname: "Rotational Mobile Banner"
          }
        ]
      }
    };
    this.onChangeAddOnPrice = this.onChangeAddOnPrice.bind(this);
    this.updateAddOnPriceHandler = this.updateAddOnPriceHandler.bind(this);
    this.selectCampaign = this.selectCampaign.bind(this);
    this.skipToNext = this.skipToNext.bind(this);
  }
  fetchCampaignListHandler = () => {
    Promise.all([this.props.fetchCampaignList({})]).then(() => {
      console.log("this.props", this.props);
      if (this.props.CampaignList && this.props.CampaignList.data) {
        this.getCampaignPricesHandler();
        const object = this.props.CampaignList.data;
        this.setState({
          child_data: this.state.addons.resSqlQueryForAddOns //without api
        });
      }
    });
  };
  componentDidMount() {
    if (
      this.props.selectCityArrDetails &&
      this.props.selectCityArrDetails.length > 0
    ) {
      (this.state.dataCity = this.props.selectCityArrDetails[0]),
        (this.state.dataCityArr = this.props.selectCityArrDetails);
    }

    this.fetchCampaignListHandler();
  }

  onChangeAddOnPrice(e, index, key) {
    console.log("eee", e.target.value);
    let temp = { ...this.state.addon_pricing[index] };
    let upfront_vlaue = e.target.validity.valid ? e.target.value : 0;
    temp["upfront"] = upfront_vlaue ? parseInt(upfront_vlaue) : 0;
    temp["ecs"] = upfront_vlaue ? parseInt(upfront_vlaue) : 0;
    console.log(temp);
    this.setState(
      prevState => ({
        addon_pricing: { ...prevState.addon_pricing, [index]: temp }
      }),
      () => {
        // console.log(this.state.addon_pricing)
      }
    );
  }
  updateAddOnPriceHandler = () => {
    let params = {
      data_city: this.state.dataCityArr,
      campaign_id: this.props.match.params.variant,
      addon_pricing: this.state.addon_pricing,
      empcode: EMPCODE
      // username: '',
      // isTempBudget: localStorage.getItem('isTempBudget'),
    };
    console.log("===", params);
    Promise.all([this.props.updateAddOnPrice(params)]).then(() => {
      console.log("props=");
      this.props.history.push("/select-users");
    });
  };
  skipToNext() {
    this.props.history.push("/select-users");
  }
  getCampaignPricesHandler = () => {
    Promise.all([
      this.props.getCampaignPriceForProduct({
        data_city: this.state.dataCity,
        variant: this.props.match.params.variant
        // isTempBudget: localStorage.getItem('isTempBudget')
      })
    ]).then(() => {
      if (
        this.props.campaignPriceDetails &&
        this.props.campaignPriceDetails.data
      ) {
        const obj = this.props.campaignPriceDetails.data;
        this.setState({
          addon_pricing: obj.addon_pricing
        });
      }
    });
  };
  selectCampaign(e, index) {
    // console.log("ee==", e.target.checked, index, this.state.addon_pricing)
    if (e.target.checked == true) {
      // console.log("ee==", e.target.checked, index, this.state.addon_pricing)
      let temp = { ...this.state.addon_pricing[index] };
      temp["upfront"] = 0;
      temp["ecs"] = 0;
      temp["check"] = true;
      // console.log(temp)
      this.setState(prevState => ({
        addon_pricing: { ...prevState.addon_pricing, [index]: temp }
      }));
    } else {
      // console.log("ee=else=", e.target.checked, index, this.state.addon_pricing)

      let temp = { ...this.state.addon_pricing[index] };

      temp["check"] = false;
      console.log(",,,", temp);
      this.setState(prevState => ({
        addon_pricing: { ...prevState.addon_pricing, [index]: {} }
      }));
    }
  }

  render() {
    return (
      <div className=" wrapper-block pb-30">
        <div className="font14 color414 fw600 pl-20 pr-20 pt-15 pb-15 borderBtmA">
          {" "}
          Select Free Add-On Products{" "}
        </div>
        <div className="wrapper-block addonProduct">
          {this.state.child_data.map((newKey, key) => {
            return (
              <div key={key} className="animwrap borderBtmA ">
                <label className="animcheck">
                  <input
                    className="animinput"
                    type="checkbox"
                    checked={
                      newKey.campid in this.state.addon_pricing &&
                      this.state.addon_pricing[newKey.campid]["check"]
                        ? true
                        : false
                    }
                    onChange={e => this.selectCampaign(e, newKey.campid)}
                  />
                  <div className="animlabel dtablecell w100 pl-20 pr-20 ">
                    <span className="animicon"></span>

                    <span className="animtext font13 fw400 color1a1">
                      {" "}
                      {newKey.campname}
                    </span>
                  </div>

                  <div className="dtablecell  text-right tick-right p-15 ">
                    {newKey.campid in this.state.addon_pricing &&
                    this.state.addon_pricing[newKey.campid]["check"] ? (
                      <div className="flex-vhCenter wh100">
                        {" "}
                        <span className="yesgreenTick"></span>
                      </div>
                    ) : (
                      <div className="flex-vhCenter wh100">
                        {" "}
                        <span className="crossredTick"></span>
                      </div>
                    )}
                  </div>
                  <div className="dtablecell  text-right tick-right p-15 ">
                    {newKey.campid in this.state.addon_pricing &&
                    this.state.addon_pricing[newKey.campid]["check"] ? (
                      // <div className="flex-vhCenter wh100">{this.state.addon_pricing[newKey]["upfront"]}
                      // </div>
                      <input
                        className="inputMaterial fw600 text-right freeAddonNum"
                        name={
                          this.state.addon_pricing[newKey.campid]["upfront"]
                        }
                        type="text"
                        required=""
                        maxLength="8"
                        pattern="[0-9]*"
                        onChange={e =>
                          this.onChangeAddOnPrice(e, newKey.campid, key)
                        }
                        value={
                          this.state.addon_pricing[newKey.campid]["upfront"]
                        }
                      />
                    ) : (
                      <input
                        className="inputMaterial fw600 text-right freeAddonNum"
                        type="text"
                        required=""
                        value=""
                        maxLength="8"
                        pattern="[0-9]*"
                        onChange={e =>
                          this.onChangeAddOnPrice(e, newKey.campid, key)
                        }
                      />
                    )}
                  </div>
                </label>
              </div>
            );
          })}
        </div>
        {/* <Link to={"/select-users/"+ this.props.match.params.variant}>  */}
        <div className="btmFixBtn">
          <button
            className="ftrBlueBtn white font16"
            onClick={() => this.skipToNext()}
          >
            {" "}
            Skip{" "}
          </button>
          <button
            className="ftrBlueBtn font16"
            onClick={() => this.updateAddOnPriceHandler()}
          >
            {" "}
            Proceed{" "}
          </button>
        </div>
        {/* </Link> */}
      </div>
    );
  }
}
function mapStateToProps(state, props) {
  return {
    CampaignList: state.jd_store.fetchCampaignListData,
    campaignPriceDetails: state.jd_store.campaignPriceDataForProduct,
    selectCityArrDetails: state.jd_store.selectCityArrData
  };
}

const mapDispatchToProps = dispatch => {
  return {
    updateAddOnPrice: params => dispatch(updateAddOnPrice(params)),
    fetchCampaignList: params => dispatch(fetchCampaignList(params)),
    getCampaignPriceForProduct: params =>
      dispatch(getCampaignPriceForProduct(params))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(FreeAddOnProduct);
