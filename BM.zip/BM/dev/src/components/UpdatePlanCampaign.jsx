import React, { Component } from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import {
  getCampaignPrice,
  updatePlanApi
} from "./../redux/actions/userActions";
import helperFunc from "./../utilities/helperFunctions";

class UpdatePlanCampaign extends Component {
  constructor(props) {
    super(props);
    this.state = {
      variantObj: [],
      formData: {
        single: { features: {} },
        multiple: {
          Basic: { features: {} },
          Standard: { features: {} },
          Premium: { features: {} }
        }
      },
      dataCityArr: [],
      dataCity: "",
      urlParams: this.props.match.params.type
    };
    this.onChangeValues = this.onChangeValues.bind(this);
    this.onChangeValuesFeatures = this.onChangeValuesFeatures.bind(this);
    this.updatePlan = this.updatePlan.bind(this);
  }
  componentDidMount() {
    if (
      this.props.selectCityArrDetails &&
      this.props.selectCityArrDetails.length > 0
    ) {
      (this.state.dataCity = this.props.selectCityArrDetails[0]),
        (this.state.dataCityArr = this.props.selectCityArrDetails);
    }
    this.getCampaignPricesHandler();
  }
  getCampaignPricesHandler = () => {
    this.state.dataCity;
    console.log(
      " this.p this.state.dataCityils---lenghh",
      this.state.dataCity,
      this.props.match.params.type
    );
    Promise.all([
      this.props.getCampaignPrice({
        data_city: this.state.dataCity,
        variant: "95"
      })
    ]).then(() => {
      console.log(
        this.props.campaignPriceDetails && this.props.campaignPriceDetails.data
      );
      if (
        this.props.campaignPriceDetails &&
        this.props.campaignPriceDetails.data &&
        this.props.campaignPriceDetails.data.plans
      ) {
        const singleObj = this.props.campaignPriceDetails.data.plans.single;
        const multipleObj = this.props.campaignPriceDetails.data.plans.multiple;
        this.setState({
          formData: { single: singleObj, multiple: multipleObj }
        });
      }
    });
  };
  updatePlan = () => {
    console.log("000");
    // if (this.state.dataCityArr.length > 0) {
    let params = {
      data_city: this.state.dataCityArr,
      campaign_id: "95",
      formData: this.state.formData,
      type: this.state.urlParams,
      empcode: EMPCODE,
      username: ""
    };
    console.log("params===", params);
    Promise.all([this.props.updatePlanApi(params)]).then(() => {
      console.log("props=");
      // this.props.history.push("/discount/" + this.props.match.params.variant)

      // window.location = "/discount/" + this.props.match.params.variant
    });
    // }
  };
  assign(args) {
    console.log(args);
    var resObj = {};
    for (var key in args) {
      resObj[key] = args[key];
    }
    return resObj;
  }

  onChangeValues(typeVal, evt) {
    if (this.state.urlParams == "single") {
      var newVals = {};
      newVals = this.assign(this.state.formData.single);
      newVals[typeVal] = evt.target.value ? parseInt(evt.target.value) : 0;
      console.log("==single", newVals);
      this.setState({ formData: { single: newVals } });
    } else {
      var newVals = {};
      newVals = this.assign(this.state.formData.multiple[this.state.urlParams]);
      newVals[typeVal] = evt.target.value ? parseInt(evt.target.value) : 0;
      console.log("==", this.state.urlParams, newVals);
      this.setState({
        formData: {
          multiple: {
            [this.state.urlParams]: newVals
          }
        }
      });
    }
  }
  onChangeValuesFeatures(typeVal, evt) {
    if (this.state.urlParams == "single") {
      var newVals = {};

      newVals = this.assign(this.state.formData.single.features);
      newVals[typeVal] = evt.target.value ? parseInt(evt.target.value) : 0;
      console.log("==single", newVals);
      this.setState({ formData: { single: { features: newVals } } });
    } else {
      var newVals = {};
      newVals = this.assign(
        this.state.formData.multiple[this.state.urlParams].features
      );
      newVals[typeVal] = evt.target.value ? parseInt(evt.target.value) : 0;
      console.log("==", this.state.urlParams, newVals);
      this.setState({
        formData: {
          multiple: {
            [this.state.urlParams]: {
              features: newVals
            }
          }
        }
      });
    }
  }

  render() {
    return (
      <div className=" wrapper-block pb-30">
        <div className="font14 color414 fw600 pl-20 pr-20 pt-20">
          {" "}
          Update Plan For {this.state.urlParams}{" "}
        </div>
        <div className="wrapper-block pl-20 pr-20 pt-20">
          <li className="selUserLi dtable  color1a1 pl-15  csrpntr">
            {this.state.urlParams == "single" ? (
              <div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    CCDCEMI One Year Discount Amount
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues(
                            "ccdcemi_oneyear_discount_amount",
                            evt
                          )
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.single
                            .ccdcemi_oneyear_discount_amount || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    CCDCEMI One Year Price{" "}
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("ccdcemi_oneyear_price", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.single.ccdcemi_oneyear_price || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    CCDCEMI One Year Price Discount{" "}
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues(
                            "ccdcemi_oneyear_price_with_dis",
                            evt
                          )
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.single
                            .ccdcemi_oneyear_price_with_dis || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    CCDCEMI One Year Tax{" "}
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("ccdcemi_oneyear_tax", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.single.ccdcemi_oneyear_tax || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    CCDCEMI Two Year Discount Amount
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues(
                            "ccdcemi_twoyear_discount_amount",
                            evt
                          )
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.single
                            .ccdcemi_twoyear_discount_amount || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    CCDCEMI Two Year Price{" "}
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("ccdcemi_twoyear_price", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.single.ccdcemi_twoyear_price || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    CCDCEMI Two Year Discount Price
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues(
                            "ccdcemi_twoyear_price_with_dis",
                            evt
                          )
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.single
                            .ccdcemi_twoyear_price_with_dis || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    CCDCEMI Two Year Tax{" "}
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("ccdcemi_twoyear_tax", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.single.ccdcemi_twoyear_tax || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>

                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    Dep Campaings
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("dep_campaings", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={this.state.formData.single.dep_campaings || 0}
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    Discount Amount{" "}
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("discount_amount", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={this.state.formData.single.discount_amount || 0}
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    ECS Discount
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("ecs_discount", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={this.state.formData.single.ecs_discount || 0}
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    EMI Discount{" "}
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("emi_discount", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={this.state.formData.single.emi_discount || 0}
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    Monthly Price
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("monthly_price", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={this.state.formData.single.monthly_price || 0}
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    Monthly Tax{" "}
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("monthly_tax", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={this.state.formData.single.monthly_tax || 0}
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    Price
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt => this.onChangeValues("price", evt)}
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={this.state.formData.single.price || 0}
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    Upfront Discount{" "}
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("upfront_discount", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={this.state.formData.single.upfront_discount || 0}
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    Yearly Price Text Price
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("yearlyprice_text_price", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.single.yearlyprice_text_price || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    Yearly Price
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("yearly_price", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={this.state.formData.single.yearly_price || 0}
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    Yearly Price with Discount
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("yearly_price_with_dis", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.single.yearly_price_with_dis || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    Yearly Tax
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt => this.onChangeValues("yearly_tax", evt)}
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={this.state.formData.single.yearly_tax || 0}
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>

                {/* --------------------------------------------------------------------------------Features--- */}
                {/* <div>
									<div className="dtable">
										<div className="leftDiscText font14 color788 fw500"> Catalog</div>
										<div className=" rightDiscWidth">
											<div className="group">
												<input className="inputMaterial fw600 text-right"
													onChange={(evt) => this.onChangeValuesFeatures('catalog', evt)}

													pattern="[0-9]*" maxLength="8" type="text" required=""
													value={this.state.formData.single.features.catalog|| 0} />
												<span className="bar"></span>
											</div>
										</div>
									</div>
									<div className="dtable">
										<div className="leftDiscText font14 color788 fw500"> Categories</div>
										<div className=" rightDiscWidth">
											<div className="group">
												<input className="inputMaterial fw600 text-right"
													onChange={(evt) => this.onChangeValuesFeatures('categories', evt)}

													pattern="[0-9]*" maxLength="8" type="text" required=""
													value={this.state.formData.single.features.categories|| 0} />
												<span className="bar"></span>
											</div>
										</div>
									</div>
									<div className="dtable">
										<div className="leftDiscText font14 color788 fw500"> Listing</div>
										<div className=" rightDiscWidth">
											<div className="group">
												<input className="inputMaterial fw600 text-right"
													onChange={(evt) => this.onChangeValuesFeatures('listing', evt)}

													pattern="[0-9]*" maxLength="8" type="text" required=""
													value={this.state.formData.single.features.listing|| 0} />
												<span className="bar"></span>
											</div>
										</div>
									</div>
									<div className="dtable">
										<div className="leftDiscText font14 color788 fw500"> Payment Gateway</div>
										<div className=" rightDiscWidth">
											<div className="group">
												<input className="inputMaterial fw600 text-right"
													onChange={(evt) => this.onChangeValuesFeatures('payment_gateway', evt)}

													pattern="[0-9]*" maxLength="8" type="text" required=""
													value={this.state.formData.single.features.payment_gateway|| 0} />
												<span className="bar"></span>
											</div>
										</div>
									</div>
									<div className="dtable">
										<div className="leftDiscText font14 color788 fw500"> Profile</div>
										<div className=" rightDiscWidth">
											<div className="group">
												<input className="inputMaterial fw600 text-right"
													onChange={(evt) => this.onChangeValuesFeatures('profile', evt)}

													pattern="[0-9]*" maxLength="8" type="text" required=""
													value={this.state.formData.single.features.profile|| 0} />
												<span className="bar"></span>
											</div>
										</div>
									</div>
									<div className="dtable">
										<div className="leftDiscText font14 color788 fw500"> Search</div>
										<div className=" rightDiscWidth">
											<div className="group">
												<input className="inputMaterial fw600 text-right"
													onChange={(evt) => this.onChangeValuesFeatures('search', evt)}

													pattern="[0-9]*" maxLength="8" type="text" required=""
													value={this.state.formData.single.features.search|| 0} />
												<span className="bar"></span>
											</div>
										</div>
									</div>
									<div className="dtable">
										<div className="leftDiscText font14 color788 fw500"> Upfront</div>
										<div className=" rightDiscWidth">
											<div className="group">
												<input className="inputMaterial fw600 text-right"
													onChange={(evt) => this.onChangeValuesFeatures('upfront', evt)}

													pattern="[0-9]*" maxLength="8" type="text" required=""
													value={this.state.formData.single.features.upfront|| 0} />
												<span className="bar"></span>
											</div>
										</div>
									</div>
									<div className="dtable">
										<div className="leftDiscText font14 color788 fw500"> Verified</div>
										<div className=" rightDiscWidth">
											<div className="group">
												<input className="inputMaterial fw600 text-right"
													onChange={(evt) => this.onChangeValuesFeatures('verified', evt)}

													pattern="[0-9]*" maxLength="8" type="text" required=""
													value={this.state.formData.single.features.verified|| 0} />
												<span className="bar"></span>
											</div>
										</div>
									</div>
								</div>
							
							 */}
              </div>
            ) : (
              <div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    Dep Campaings
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("dep_campaings", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.multiple[this.state.urlParams]
                            .dep_campaings || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    Discount Amount{" "}
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("discount_amount", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.multiple[this.state.urlParams]
                            .discount_amount || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    ECS Discount
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("ecs_discount", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.multiple[this.state.urlParams]
                            .ecs_discount || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                {/* <div className="dtable">
									<div className="leftDiscText font14 color788 fw500"> EMI Discount </div>
									<div className=" rightDiscWidth">
										<div className="group">
											<input className="inputMaterial fw600 text-right"
												onChange={(evt) => this.onChangeValues('emi_discount', evt)}

												pattern="[0-9]*" maxLength="8" type="text" required=""
												value={this.state.formData.multiple[this.state.urlParams].emi_discount|| 0} />
											<span className="bar"></span>
										</div>
									</div>
								</div> */}
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    Monthly Price
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("monthly_price", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.multiple[this.state.urlParams]
                            .monthly_price || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    Monthly Tax{" "}
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("monthly_tax", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.multiple[this.state.urlParams]
                            .monthly_tax || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    Price
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt => this.onChangeValues("price", evt)}
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.multiple[this.state.urlParams]
                            .price || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    Upfront Discount{" "}
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("upfront_discount", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.multiple[this.state.urlParams]
                            .upfront_discount || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                {/* <div className="dtable">
									<div className="leftDiscText font14 color788 fw500"> Yearly Price Text Price</div>
									<div className=" rightDiscWidth">
										<div className="group">
											<input className="inputMaterial fw600 text-right"
												onChange={(evt) => this.onChangeValues('yearlyprice_text_price', evt)}

												pattern="[0-9]*" maxLength="8" type="text" required=""
												value={this.state.formData.multiple[this.state.urlParams].yearlyprice_text_price|| 0} />
											<span className="bar"></span>
										</div>
									</div>
								</div> */}
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    Yearly Price
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("yearly_price", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.multiple[this.state.urlParams]
                            .yearly_price || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    Yearly Price with Discount
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt =>
                          this.onChangeValues("yearly_price_with_dis", evt)
                        }
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.multiple[this.state.urlParams]
                            .yearly_price_with_dis || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>
                <div className="dtable">
                  <div className="leftDiscText font14 color788 fw500">
                    {" "}
                    Yearly Tax
                  </div>
                  <div className=" rightDiscWidth">
                    <div className="group">
                      <input
                        className="inputMaterial fw600 text-right"
                        onChange={evt => this.onChangeValues("yearly_tax", evt)}
                        pattern="[0-9]*"
                        maxLength="8"
                        type="text"
                        required=""
                        value={
                          this.state.formData.multiple[this.state.urlParams]
                            .yearly_tax || 0
                        }
                      />
                      <span className="bar"></span>
                    </div>
                  </div>
                </div>

                {/* ----------------multiple feature----------------- */}
                {/* <div className="dtable">
									<div className="leftDiscText font14 color788 fw500"> Catalog</div>
									<div className=" rightDiscWidth">
										<div className="group">
											<input className="inputMaterial fw600 text-right"
												onChange={(evt) => this.onChangeValuesFeatures('catalog', evt)}

												pattern="[0-9]*" maxLength="8" type="text" required=""
												value={this.state.formData.multiple[this.state.urlParams].features.catalog|| 0} />
											<span className="bar"></span>
										</div>
									</div>
								</div>
								<div className="dtable">
									<div className="leftDiscText font14 color788 fw500"> Categories</div>
									<div className=" rightDiscWidth">
										<div className="group">
											<input className="inputMaterial fw600 text-right"
												onChange={(evt) => this.onChangeValuesFeatures('categories', evt)}

												pattern="[0-9]*" maxLength="8" type="text" required=""
												value={this.state.formData.multiple[this.state.urlParams].features.categories|| 0} />
											<span className="bar"></span>
										</div>
									</div>
								</div>
								<div className="dtable">
									<div className="leftDiscText font14 color788 fw500"> Listing</div>
									<div className=" rightDiscWidth">
										<div className="group">
											<input className="inputMaterial fw600 text-right"
												onChange={(evt) => this.onChangeValuesFeatures('listing', evt)}

												pattern="[0-9]*" maxLength="8" type="text" required=""
												value={this.state.formData.multiple[this.state.urlParams].features.listing|| 0} />
											<span className="bar"></span>
										</div>
									</div>
								</div>
								<div className="dtable">
									<div className="leftDiscText font14 color788 fw500"> Payment Gateway</div>
									<div className=" rightDiscWidth">
										<div className="group">
											<input className="inputMaterial fw600 text-right"
												onChange={(evt) => this.onChangeValuesFeatures('payment_gateway', evt)}

												pattern="[0-9]*" maxLength="8" type="text" required=""
												value={this.state.formData.multiple[this.state.urlParams].features.payment_gateway|| 0} />
											<span className="bar"></span>
										</div>
									</div>
								</div>
								<div className="dtable">
									<div className="leftDiscText font14 color788 fw500"> Profile</div>
									<div className=" rightDiscWidth">
										<div className="group">
											<input className="inputMaterial fw600 text-right"
												onChange={(evt) => this.onChangeValuesFeatures('profile', evt)}

												pattern="[0-9]*" maxLength="8" type="text" required=""
												value={this.state.formData.multiple[this.state.urlParams].features.profile|| 0} />
											<span className="bar"></span>
										</div>
									</div>
								</div>
								<div className="dtable">
									<div className="leftDiscText font14 color788 fw500"> Search</div>
									<div className=" rightDiscWidth">
										<div className="group">
											<input className="inputMaterial fw600 text-right"
												onChange={(evt) => this.onChangeValuesFeatures('search', evt)}

												pattern="[0-9]*" maxLength="8" type="text" required=""
												value={this.state.formData.multiple[this.state.urlParams].features.search|| 0} />
											<span className="bar"></span>
										</div>
									</div>
								</div>
								<div className="dtable">
									<div className="leftDiscText font14 color788 fw500"> Upfront</div>
									<div className=" rightDiscWidth">
										<div className="group">
											<input className="inputMaterial fw600 text-right"
												onChange={(evt) => this.onChangeValuesFeatures('upfront', evt)}

												pattern="[0-9]*" maxLength="8" type="text" required=""
												value={this.state.formData.multiple[this.state.urlParams].features.upfront|| 0} />
											<span className="bar"></span>
										</div>
									</div>
								</div>
								<div className="dtable">
									<div className="leftDiscText font14 color788 fw500"> Verified</div>
									<div className=" rightDiscWidth">
										<div className="group">
											<input className="inputMaterial fw600 text-right"
												onChange={(evt) => this.onChangeValuesFeatures('verified', evt)}

												pattern="[0-9]*" maxLength="8" type="text" required=""
												value={this.state.formData.multiple[this.state.urlParams].features.verified|| 0} />
											<span className="bar"></span>
										</div>
									</div> 
								</div>*/}
              </div>
            )}
          </li>
        </div>
        <Link to={"/planCampaign"}>
          <div className="btmFixBtn">
            {/* <button className="ftrBlueBtn white font16"> Skip </button> */}
            <button
              className="ftrBlueBtn font16"
              onClick={() => {
                this.updatePlan();
              }}
            >
              {" "}
              Update{" "}
            </button>
          </div>
        </Link>
      </div>
    );
  }
}
function mapStateToProps(state, props) {
  return {
    selectCityArrDetails: state.jd_store.selectCityArrData,
    campaignPriceDetails: state.jd_store.campaignPriceData,
    user: state.jd_store.user || {}
  };
}

const mapDispatchToProps = dispatch => {
  return {
    getCampaignPrice: params => dispatch(getCampaignPrice(params)),
    updatePlanApi: params => dispatch(updatePlanApi(params))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(UpdatePlanCampaign);
// export default SelectCampaign;
