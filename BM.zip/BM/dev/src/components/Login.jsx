import React, { Component } from "react";
import { Route, Switch, withRouter } from "react-router-dom";
import { connect } from "react-redux";

class Login extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <div className="loginwpr">
        <div className="jdlogowpr">
          <span className="jdlogo_genionew" />
          <span className="logintext font13">
            Login for a seamless experience
          </span>
        </div>
        <div className="logininptwpr">
          <div className="group">
            <input className="inputMaterial font16" type="text" required />
            <span className="bar" />
            <label className="label-wrap font16">User Name / Employee Id</label>
          </div>
          <div className="group">
            <input className="inputMaterial font16" type="text" required />
            <span className="bar" />
            <label className="label-wrap font16">Password</label>
          </div>
          <div className="signinbtnwpr">
            <button className="signinbtn font16">Sign In</button>
          </div>
          <div className="forgotwpr">
            <a href="#" className="font13">
              Forgot Password?
            </a>
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state, props) {
  return {
    user: state.jd_store.user || "",
    typeofemployee: state.jd_store.typeofemployee || ""
  };
}

export default withRouter(connect(mapStateToProps, {})(Login));
