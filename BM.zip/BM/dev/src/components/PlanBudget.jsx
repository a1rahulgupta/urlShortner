import React, { Component } from "react";
import { Link, Redirect } from "react-router-dom";
import { connect } from "react-redux";
import {
  fetchPlanAndBudgetDetail,
  updatePlanAndBudget,
  getCampaignPrice
} from "./../redux/actions/userActions";
import Minipopup from "./common/Minipopup";

class PlanBudget extends Component {
  constructor(props) {
    super(props);

    this.state = {
      emiPopup: 0,
      isChecked: false,
      upfront_budget: 0,
      b2b_upfront_budget: 0,
      expiry_budget: 0,
      emi_budget: 0,
      downPayment: 0,
      selectEmi: 1,
      emiOptions: {},
      emiArray: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
      emiObject: {
        3: { emi_months: 3, premium_percentage: 0, discount: 0, divider: 0 },
        6: { emi_months: 6, premium_percentage: 0, discount: 0, divider: 0 },
        9: { emi_months: 9, premium_percentage: 0, discount: 0, divider: 0 },
        12: { emi_months: 12, premium_percentage: 0, discount: 0, divider: 0 }
      },
      emiOptionArr: [],
      emi_options: [],
      dataCity: "",
      dataCityArr: [],
      flatAmt: true,
      dpCount: false,
      paramsValue: "",
      showMinipopup: false,
      miniPopupText: "",
      miniPopupTitle: "",
      campid: this.props.match.params.variant,
      b2cBudgetEditable: false,
      b2bBudgetEditable: false,
      expiryBudgetEditable: false
    };

    this.onChangeUpfrontBudget = this.onChangeUpfrontBudget.bind(this);
    this.onChangeB2bUpfrontBudget = this.onChangeB2bUpfrontBudget.bind(this);
    this.onChangeExipryBudget = this.onChangeExipryBudget.bind(this);
    this.onChangeEMIBudget = this.onChangeEMIBudget.bind(this);
    this.onChangeMinimumAmount = this.onChangeMinimumAmount.bind(this);
    this.updatePlanAndBudgetHandler = this.updatePlanAndBudgetHandler.bind(
      this
    );
    this.SelectDownPayment = this.SelectDownPayment.bind(this);
    this.skipToNext = this.skipToNext.bind(this);
    this.checkEditable = this.checkEditable.bind(this);
  }
  componentDidMount() {
    if (
      this.props.selectCityArrDetails &&
      this.props.selectCityArrDetails.length > 0
    ) {
      (this.state.dataCity = this.props.selectCityArrDetails[0]),
        (this.state.dataCityArr = this.props.selectCityArrDetails);
    }
    if (this.props.match.params.variant) {
      this.getCampaignPricesHandler();
      this.fetchPlanAndBudgetDetailsHandler();
    }

    if (this.props.CampaignList && this.props.CampaignList.data) {
      const object = this.props.CampaignList.data;
      Object.values(object).map((newVal, newKey) => {
        // if (newVal['name'] == this.props.match.params.variant) {
        //     if(newVal.tenure_options.length){
        //     this.setState({
        //         upfront_budget: newVal.tenure_options[0].upfront,
        //         emi_budget: newVal.tenure_options[0].ecs,
        //     })
        //     }
        // }
      });
    }
  }
  getCampaignPricesHandler = () => {
    this.state.dataCity;
    console.log(
      " this.p this.state.dataCityils---lenghh",
      this.state.dataCity,
      this.state.paramsValue
    );
    console.log("var", this.props.match.params["variant"]);
    Promise.all([
      this.props.getCampaignPrice({
        data_city: this.state.dataCity,
        variant: this.props.match.params["variant"]
        // isTempBudget: localStorage.getItem('isTempBudget')
      })
    ]).then(() => {
      if (
        this.props.campaignPriceDetails &&
        this.props.campaignPriceDetails.data &&
        this.props.campaignPriceDetails.data.tenure_options
      ) {
        const obj = this.props.campaignPriceDetails.data;
        console.log("obj---cam", obj.category_exception);

        this.setState({
          upfront_budget:
            obj.category_exception.rank_range[365]["0-100"].upfront,
          emi_budget: obj.category_exception.rank_range[365]["0-100"].ecs,
          b2b_upfront_budget:
            obj.category_exception.b2b_lead_plan_base_price.ecs,
          expiry_budget: obj.tenure_options[365].expired_ecs
        });
      }
    });
  };

  fetchPlanAndBudgetDetailsHandler = () => {
    Promise.all([
      this.props.fetchPlanAndBudgetDetail({
        data_city: this.state.dataCity,
        variant: this.props.match.params.variant
        // isTempBudget: localStorage.getItem('isTempBudget')
      })
    ]).then(() => {
      if (
        this.props.PlanAndBudgetDetails &&
        this.props.PlanAndBudgetDetails.data[0]
      ) {
        this.setState({
          downPayment: this.props.PlanAndBudgetDetails.data[0].flat_amount,
          selectEmi: this.props.PlanAndBudgetDetails.data[0].dp_count
        });
        if (this.props.PlanAndBudgetDetails.data[0].emi_options) {
          console.log(
            "this.props.fetPlanAndBudgetData---",
            this.props.PlanAndBudgetDetails
          );
          this.setState({
            emiOptions: JSON.parse(
              this.props.PlanAndBudgetDetails.data[0].emi_options
            )
          });
        }
      }
    });
  };

  updatePlanAndBudgetHandler = () => {
    if (this.state.upfront_budget == 0 || this.state.upfront_budget == "") {
      this.setState({
        miniPopupText: "Please enter proper upfront minimum amount ",
        showMinipopup: true
      });
      return;
    }
    if (this.state.emi_budget == 0 || this.state.emi_budget == "") {
      this.setState({
        miniPopupText: "Please enter proper EMI minimum amount",
        showMinipopup: true
      });
      return;
    }
    if (
      this.state.isChecked &&
      this.state.flatAmt == true &&
      (this.state.downPayment == 0 || this.state.downPayment == "")
    ) {
      this.setState({
        miniPopupText: "Please enter proper Down payment minimum amount",
        showMinipopup: true
      });
      return;
    }
    if (
      this.state.b2b_upfront_budget == 0 ||
      this.state.b2b_upfront_budget == ""
    ) {
      this.setState({
        miniPopupText: "Please enter proper B2B upfront minimum amount ",
        showMinipopup: true
      });
      return;
    }
    if (
      (this.state.expiry_budget == 0 || this.state.expiry_budget == "") &&
      this.state.campid == "54"
    ) {
      this.setState({
        miniPopupText: "Please enter proper Expiry minimum amount ",
        showMinipopup: true
      });
      return;
    }

    if (this.state.dataCityArr.length > 0) {
      let params = {
        data_city: this.state.dataCityArr,
        campaign_id: this.props.match.params.variant,
        upfront_budget: this.state.upfront_budget,
        emi_budget: this.state.emi_budget,
        b2b_upfront_budget: this.state.b2b_upfront_budget,
        expiry_budget: this.state.campid == "54" ? this.state.expiry_budget : 0,
        downPayment: this.state.flatAmt ? this.state.downPayment : 0,
        selectEmi: this.state.dpCount ? this.state.selectEmi : 1,
        emi_options: this.state.emi_options,
        empcode: window.atob(localStorage.getItem("budget_admin_empcode")),
        username: "",
        // isTempBudget: localStorage.getItem('isTempBudget'),
        prev_value: {
          downPayment: this.props.PlanAndBudgetDetails.data[0].flat_amount,
          selectEmi: this.props.PlanAndBudgetDetails.data[0].dp_count,
          emiOptions: this.props.PlanAndBudgetDetails.data[0].emi_options
            ? JSON.parse(this.props.PlanAndBudgetDetails.data[0].emi_options)
            : {}
        },
        current_value: {
          downPayment: this.state.flatAmt ? this.state.downPayment : 0,
          selectEmi: this.state.dpCount ? this.state.selectEmi : 1,
          emi_options: this.state.emi_options
        },
        b2cBudgetEditable: this.state.b2cBudgetEditable,
        b2bBudgetEditable: this.state.b2bBudgetEditable,
        expiryBudgetEditable: this.state.expiryBudgetEditable
      };
      console.log("params===", params);

      if (window.confirm("Are you sure you want to update the budget?")) {
        Promise.all([this.props.updatePlanAndBudget(params)]).then(() => {
          console.log("props=");
          // this.props.history.push("/discount/" + this.props.match.params.variant)

          this.setState(
            {
              miniPopupText: "Budget has been succesfully updated",
              showMinipopup: true
            },
            () => {
              document.getElementsByClassName(
                "hdrWrp hdrDetail hdrWhiteBg"
              )[0].style.visibility = "hidden";
            }
          );
          return;

          // window.location = "/discount/" + this.props.match.params.variant
        });
      }
    }
  };

  skipToNext() {
    this.props.history.push("/discount/" + this.props.match.params.variant);
  }

  openEmiPopup() {
    console.log("hello");
    this.setState({ emiPopup: 1 });
  }
  openEmiPopupclose() {
    this.setState({ emiPopup: 0 });
  }
  emiOptionEnable() {
    this.setState({
      isChecked: event.target.checked
    });

    for (var key in this.state.emiOptions) {
      console.log("key===", this.state.emiOptions[key].discount);
      let obj;
      if (key == "11") {
        obj = {
          12: {
            emi_months: 12,
            premium_percentage: 0,
            discount: this.state.emiOptions[key].discount,
            divider: 0
          }
        };
        this.state.emiOptionArr.push("12");
        this.state.emi_options.push(obj);
      } else {
        if (key == "3") {
          obj = {
            3: {
              emi_months: 3,
              premium_percentage: 0,
              discount: this.state.emiOptions[key].discount,
              divider: 0
            }
          };
        }
        if (key == "6") {
          obj = {
            6: {
              emi_months: 6,
              premium_percentage: 0,
              discount: this.state.emiOptions[key].discount,
              divider: 0
            }
          };
        }
        if (key == "9") {
          obj = {
            9: {
              emi_months: 9,
              premium_percentage: 0,
              discount: this.state.emiOptions[key].discount,
              divider: 0
            }
          };
        }
        if (key == "12") {
          obj = {
            12: {
              emi_months: 12,
              premium_percentage: 0,
              discount: this.state.emiOptions[key].discount,
              divider: 0
            }
          };
        }
        this.state.emiOptionArr.push(key);

        this.state.emi_options.push(obj);
      }
    }
  }
  onFieldChange(e) {
    console.log("e==", e.target.value);
    this.setState({
      selectEmi: e.target.value
    });
  }

  filterByType = type => {
    // let type = parseInt(value)
    console.log(type);
    let object;
    let index;
    let filterArray = this.state.emiOptionArr;
    if (filterArray.includes(type)) {
      index = filterArray.indexOf(type);
      filterArray.splice(index, 1);
      this.state.emi_options.splice(index, 1);
    } else {
      filterArray.push(type);

      console.log(typeof type);
      if (type == "3") {
        object = {
          3: { emi_months: 3, premium_percentage: 0, discount: 0, divider: 0 }
        };
      }
      if (type == "6") {
        object = {
          6: { emi_months: 6, premium_percentage: 0, discount: 0, divider: 0 }
        };
      }
      if (type == "9") {
        object = {
          9: { emi_months: 9, premium_percentage: 0, discount: 0, divider: 0 }
        };
      }
      if (type == "12") {
        object = {
          12: { emi_months: 12, premium_percentage: 0, discount: 0, divider: 0 }
        };
      }

      this.state.emi_options.push(object);
    }
    console.log(filterArray);
    this.setState({ emiOptionArr: filterArray });

    console.log("emi_options", this.state.emi_options);
  };
  onChangeUpfrontBudget(e) {
    this.setState({
      upfront_budget: e.target.validity.valid ? e.target.value : 0
    });
  }
  onChangeExipryBudget(e) {
    console.log("expiry_budget", this.state.expiry_budget);

    this.setState({
      expiry_budget: e.target.validity.valid ? e.target.value : 0
    });
  }
  onChangeB2bUpfrontBudget(e) {
    this.setState({
      b2b_upfront_budget: e.target.validity.valid ? e.target.value : 0
    });
  }
  onChangeEMIBudget(e) {
    this.setState({
      emi_budget: e.target.validity.valid ? e.target.value : 0
    });
  }
  onChangeMinimumAmount(e) {
    this.setState({
      downPayment: e.target.validity.valid ? e.target.value : 0
    });
  }
  SelectDownPayment(e) {
    console.log("eeee-", e.target.checked);
    if (e.target.checked == true && e.target.value == "dpCount") {
      this.setState({
        dpCount: true,
        flatAmt: false
      });
    } else {
      this.setState({
        dpCount: false,
        flatAmt: true
      });
    }
    console.log("eeee-", e.target.value);
  }
  closeAlert = () => {
    console.log("miniPopupText", this.state.miniPopupText);
    if (this.state.miniPopupText == "Budget has been succesfully updated") {
      this.props.history.push("/select-users");
      document.getElementsByClassName(
        "hdrWrp hdrDetail hdrWhiteBg"
      )[0].style.visibility = "visible";
    } else {
      this.setState({ showMinipopup: false });
    }
  };

  checkEditable = e => {
    console.log("checkeditable", e.target.value);
    let b2cBudgetEditable = this.state.b2cBudgetEditable;
    let b2bBudgetEditable = this.state.b2bBudgetEditable;
    let expiryBudgetEditable = this.state.expiryBudgetEditable;

    switch (e.target.value) {
      case "b2cBudget":
        b2cBudgetEditable = !b2cBudgetEditable;
        break;

      case "b2bBudget":
        b2bBudgetEditable = !b2bBudgetEditable;
        break;

      case "expiryBudget":
        expiryBudgetEditable = !expiryBudgetEditable;
        break;
    }
    console.log(
      "b2bBudgetEditable",
      b2bBudgetEditable,
      b2cBudgetEditable,
      expiryBudgetEditable
    );
    this.setState({
      b2cBudgetEditable,
      b2bBudgetEditable,
      expiryBudgetEditable
    });
  };

  render() {
    console.log("campid", this.props);
    if (this.state.showMinipopup) {
      return (
        <Minipopup
          title={this.state.miniPopupTitle}
          text={this.state.miniPopupText}
          handleOk={this.closeAlert}
          okPopup={true}
        />
      );
    }
    return (
      <div className=" wrapper-block pb-30 ftrSpace">
        <div className="font14  fw600 pl-20 pr-20 pt-20">
          {" "}
          Selected Cities: {this.state.dataCityArr.join(", ")}{" "}
        </div>
        {/* <div className="font14 color414 fw600 pl-20 pr-20 pt-20"> Plans & Budget </div> */}
        <div className="wrapper-block pl-20 pr-20 pt-20">
          <ul className="typeAWrp wrapper-block ">
            <li className="selUserLi dtable  color1a1 pl-15  csrpntr">
              <div className="dtable pb-20">
                <div className="dtablecell">
                  <span className="font14 fw600"> B2C Budget </span>
                </div>
                <div className="dtablecell switchwidth text-right">
                  <label className="dtablecell switch">
                    <input
                      type="checkbox"
                      value="b2cBudget"
                      onChange={this.checkEditable}
                    />
                    <span className="slider"></span>
                  </label>
                </div>
              </div>
              <div className="dtable ">
                <div className="group">
                  <label className="fw600 ">Minimum Budget</label>
                  <input
                    className="inputMaterial fw600"
                    type="text"
                    pattern="[0-9]*"
                    maxLength="8"
                    value={this.state.upfront_budget}
                    onChange={this.onChangeUpfrontBudget}
                    readOnly={!this.state.b2cBudgetEditable}
                  />
                  <span className="bar"></span>
                </div>
              </div>
            </li>
            <li className="selUserLi dtable  color1a1 pl-15  csrpntr">
              <div className="dtable pb-20">
                <div className="dtablecell">
                  <span className="font14 fw600">B2B Budget </span>
                </div>
                <div className="dtablecell switchwidth text-right">
                  <label className="dtablecell switch">
                    <input
                      type="checkbox"
                      value="b2bBudget"
                      onChange={this.checkEditable}
                    />
                    <span className="slider"></span>
                  </label>
                </div>
              </div>
              <div className="dtable ">
                <div className="group">
                  <label className="fw600 ">Minimum Budget</label>
                  <input
                    className="inputMaterial fw600"
                    type="text"
                    pattern="[0-9]*"
                    maxLength="8"
                    value={this.state.b2b_upfront_budget}
                    onChange={this.onChangeB2bUpfrontBudget}
                    readOnly={!this.state.b2bBudgetEditable}
                  />
                  <span className="bar"></span>
                </div>
              </div>
            </li>
            {this.state.campid == "54" && (
              <li className="selUserLi dtable  color1a1 pl-15  csrpntr">
                <div className="dtable pb-20">
                  <div className="dtablecell">
                    <span className="font14 fw600">Expiry Budget </span>
                  </div>
                  <div className="dtablecell switchwidth text-right">
                    <label className="dtablecell switch">
                      <input
                        type="checkbox"
                        value="expiryBudget"
                        onChange={this.checkEditable}
                      />
                      <span className="slider"></span>
                    </label>
                  </div>
                </div>
                <div className="dtable ">
                  <div className="group">
                    <label className="fw600 ">Minimum Budget</label>
                    <input
                      className="inputMaterial fw600"
                      type="text"
                      pattern="[0-9]*"
                      maxLength="8"
                      value={this.state.expiry_budget}
                      onChange={this.onChangeExipryBudget}
                      readOnly={!this.state.expiryBudgetEditable}
                    />
                    <span className="bar"></span>
                  </div>
                </div>
              </li>
            )}
            {/* <li className="selUserLi dtable  color1a1 pl-15  csrpntr">
                            <div className="dtable pb-20">
                                <div className="dtablecell">
                                    <span className="font14 fw600"> Upfront Plan </span>
                                </div>
                                <div className="dtablecell switchwidth text-right">
                                    <label className="dtablecell switch">
                                        <input type="checkbox" />
                                        <span className="slider"></span>
                                    </label>
                                </div>
                            </div>
                            <div className="dtable ">
                                <div className="group">
                                    <input className="inputMaterial fw600" type="text" pattern="[0-9]*" maxLength="8" value={this.state.upfront_budget} onChange={this.onChangeUpfrontBudget} />
                                    <span className="bar"></span>
                                    <label className="label-wrap ">Minimum Budget</label>
                                </div>
                            </div>

                        </li> */}

            {/* <li className="selUserLi dtable  color1a1 pl-15  csrpntr">
                            <div className="dtable pb-20">
                                <div className="dtablecell">
                                    <span className="font14 fw600"> EMI Plan </span>
                                </div>
                                <div className="dtablecell switchwidth text-right">
                                    <label className="dtablecell switch">
                                        <input type="checkbox" value="emi_plan" onClick={() => this.emiOptionEnable()} />
                                        <span className="slider"></span>
                                    </label>
                                </div>
                            </div>
                            <div className="dtable ">
                                <div className="group">
                                    <input className="inputMaterial  fw600" pattern="[0-9]*" maxLength="8" type="text" required="" onChange={this.onChangeEMIBudget} value={this.state.emi_budget} />
                                    <span className="bar"></span>
                                    <label className="label-wrap ">Minimum Budget</label>
                                </div>
                            </div>
                        </li> */}
          </ul>
        </div>

        {this.state.isChecked ? (
          <div>
            <div className="font14 color414 fw600 pl-20 pr-20 pt-5 pb-10">
              {" "}
              EMI Option{" "}
            </div>
            <div className="wrapper-block radiusTabMainWrp mt-5 mb-10">
              <ul className="radiusTabUl pl-20">
                {Object.keys(this.state.emiObject).map((filterType, key) => {
                  let isActive = this.state.emiOptionArr.includes(filterType)
                    ? "active"
                    : "";
                  return (
                    <li
                      key={key}
                      className={
                        "radiusTab font13 color414 csrpntr " + isActive
                      }
                      onClick={() => this.filterByType(filterType)}
                    >
                      {filterType} EMIs
                    </li>
                  );
                })}
              </ul>
            </div>
            <div className="font14 color414 fw600 pl-20 pr-20 pt-10 pb-10">
              {" "}
              Down Payment for EMI Plan{this.state.faltAmt}
            </div>

            <div className="wrapper-block pl-20 pr-20 pb-10 pt-20">
              <div className="animwrap">
                <label className="animcheck">
                  <input
                    className="animradio"
                    value="flatAmt"
                    checked={this.state.flatAmt}
                    name="downPayment_select"
                    onChange={e => this.SelectDownPayment(e)}
                    type="radio"
                  />
                  <div className="animlabel wrapper-block">
                    <span className="animicon "></span>
                    <span className="animtext font16 fw600 color1a1 wrapper-block">
                      <div className="group">
                        {this.state.flatAmt ? (
                          <input
                            className="inputMaterial  fw600"
                            pattern="[0-9]*"
                            maxLength="8"
                            type="text"
                            value={this.state.downPayment}
                            onChange={this.onChangeMinimumAmount}
                            required=""
                          />
                        ) : (
                          <select></select>
                        )}
                        <span className="bar"></span>

                        <label className="label-wrap color1a1 ">
                          {" "}
                          Minimum Amount
                        </label>
                      </div>
                    </span>
                  </div>
                </label>
                <div className="wrapper-block font13 color788 fw500  pr-20 pl-40">
                  {" "}
                  And Balance Payment in Selected EMIs.
                </div>
              </div>

              <div className="animwrap pt-20">
                <label className="animcheck">
                  {/* <input className="animinput" data-dismiss="modal" data-toggle="modal" onClick={() => this.openEmiPopup()} type="checkbox" /> */}
                  <input
                    className="animradio"
                    type="radio"
                    name="downPayment_select"
                    onChange={e => this.SelectDownPayment(e)}
                    value="dpCount"
                  />
                  <div className="animlabel wrapper-block">
                    <span className="animicon "></span>
                    <span className="animtext font16 fw600 color1a1 wrapper-block">
                      <div className="group selectgroup">
                        {this.state.dpCount ? (
                          <select
                            className="inputMaterial font16 fw600  pb-15"
                            value={this.state.selectEmi}
                            onChange={e => {
                              this.onFieldChange(e);
                            }}
                          >
                            <option value="">Select</option>
                            {this.state.emiArray.map((value, i) => (
                              <option value={value} key={i}>
                                {value} EMIs
                              </option>
                            ))}
                          </select>
                        ) : (
                          <select></select>
                        )}
                        {/* <select className="inputMaterial font16 fw600  pb-15" required=""
                                            >
                                            <option value=""></option>
                                            <option>7EMIs</option>
                                            <option>7EMIs</option>
                                        </select> */}
                        <i className="selectarrow"></i>
                        <span className="bar"></span>
                        <label className="label-wrap color1a1 font16">
                          {" "}
                          Select EMIs
                        </label>
                      </div>
                    </span>
                  </div>
                </label>
              </div>
            </div>
          </div>
        ) : (
          ""
        )}

        {this.state.emiPopup == 1 ? (
          <div className="modal_wrapper dn_">
            <div className="centermodal_wrapper">
              <div className="pb-20 pt-20">
                <div className="wrapper-block font16 color1a1 fw600 pl-20 pr-20 pb-15 borderBtmA">
                  Select EMI
                </div>
                <div className="wrapper-block emiOption pl-20 pr-20">
                  <div className="animwrap dtable">
                    <label className="animcheck dtable">
                      <input className="animradio" type="checkbox" />
                      <div className="animlabel dtable" htmlFor="checkbox-2">
                        <span className="animtext w100">1 EMI </span>
                        <span className="animicon "></span>
                      </div>
                    </label>
                  </div>
                  <div className="animwrap dtable">
                    <label className="animcheck dtable">
                      <input className="animradio" type="checkbox" />
                      <div className="animlabel dtable" htmlFor="checkbox-2">
                        <span className="animtext w100">2 EMIs </span>
                        <span className="animicon "></span>
                      </div>
                    </label>
                  </div>
                  <div className="animwrap dtable">
                    <label className="animcheck dtable">
                      <input className="animradio" type="checkbox" />
                      <div className="animlabel dtable" htmlFor="checkbox-2">
                        <span className="animtext w100">3 EMIs </span>
                        <span className="animicon "></span>
                      </div>
                    </label>
                  </div>
                  <div className="animwrap dtable">
                    <label className="animcheck dtable">
                      <input className="animradio" type="checkbox" />
                      <div className="animlabel dtable" htmlFor="checkbox-2">
                        <span className="animtext w100">4 EMIs </span>
                        <span className="animicon "></span>
                      </div>
                    </label>
                  </div>
                  <div className="animwrap dtable">
                    <label className="animcheck dtable">
                      <input className="animradio" type="checkbox" />
                      <div className="animlabel dtable" htmlFor="checkbox-2">
                        <span className="animtext w100">5 EMIs </span>
                        <span className="animicon "></span>
                      </div>
                    </label>
                  </div>
                  <div className="animwrap dtable">
                    <label className="animcheck dtable">
                      <input className="animradio" type="checkbox" />
                      <div className="animlabel dtable" htmlFor="checkbox-2">
                        <span className="animtext w100">6 EMIs </span>
                        <span className="animicon "></span>
                      </div>
                    </label>
                  </div>
                  <div className="animwrap dtable">
                    <label className="animcheck dtable">
                      <input className="animradio" type="checkbox" />
                      <div className="animlabel dtable" htmlFor="checkbox-2">
                        <span className="animtext w100">7 EMIs </span>
                        <span className="animicon "></span>
                      </div>
                    </label>
                  </div>
                  <div className="animwrap dtable">
                    <label className="animcheck dtable">
                      <input className="animradio" type="checkbox" />
                      <div className="animlabel dtable" htmlFor="checkbox-2">
                        <span className="animtext w100">8 EMIs </span>
                        <span className="animicon "></span>
                      </div>
                    </label>
                  </div>
                  <div className="animwrap dtable">
                    <label className="animcheck dtable">
                      <input className="animradio" type="checkbox" />
                      <div className="animlabel dtable" htmlFor="checkbox-2">
                        <span className="animtext w100">9 EMIs </span>
                        <span className="animicon "></span>
                      </div>
                    </label>
                  </div>
                  <div className="animwrap dtable">
                    <label className="animcheck dtable">
                      <input className="animradio" type="checkbox" />
                      <div className="animlabel dtable" htmlFor="checkbox-2">
                        <span className="animtext w100">10 EMIs </span>
                        <span className="animicon "></span>
                      </div>
                    </label>
                  </div>
                  <div className="animwrap dtable">
                    <label className="animcheck dtable">
                      <input className="animradio" type="checkbox" />
                      <div className="animlabel dtable" htmlFor="checkbox-2">
                        <span className="animtext w100">11 EMIs </span>
                        <span className="animicon "></span>
                      </div>
                    </label>
                  </div>
                  <div className="animwrap dtable">
                    <label className="animcheck dtable">
                      <input
                        className="animradio"
                        onClick={() => this.openEmiPopupclose()}
                        type="checkbox"
                      />
                      <div className="animlabel dtable" htmlFor="checkbox-2">
                        <span className="animtext w100">12 EMIs </span>
                        <span className="animicon "></span>
                      </div>
                    </label>
                  </div>
                  <div className="animwrap dtable">
                    <label className="animcheck dtable">
                      <input className="animradio" type="checkbox" />
                      <div className="animlabel dtable" htmlFor="checkbox-2">
                        <span className="animtext w100">13 EMIs </span>
                        <span className="animicon "></span>
                      </div>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          ""
        )}

        {/* <Link to={"/discount/" + this.props.match.params.variant}> */}
        <div className="btmFixBtn">
          {/* <button className="ftrBlueBtn white font16" onClick={
                        () => this.skipToNext()}> Skip </button>
                    <button className="ftrBlueBtn font16" onClick={
                        () => this.updatePlanAndBudgetHandler()}> Proceed </button> */}
          <button
            className="ftrBlueBtn font16"
            onClick={() => this.updatePlanAndBudgetHandler()}
          >
            {" "}
            Update Budget{" "}
          </button>
        </div>
        {/* </Link> */}
      </div>
    );
  }
}
function mapStateToProps(state, props) {
  return {
    CampaignList: state.jd_store.fetchCampaignListData,
    PlanAndBudgetDetails: state.jd_store.fetPlanAndBudgetData,
    campaignPriceDetails: state.jd_store.campaignPriceData,
    selectCityArrDetails: state.jd_store.selectCityArrData
  };
}

const mapDispatchToProps = dispatch => {
  return {
    fetchPlanAndBudgetDetail: params =>
      dispatch(fetchPlanAndBudgetDetail(params)),
    updatePlanAndBudget: params => dispatch(updatePlanAndBudget(params)),
    getCampaignPrice: params => dispatch(getCampaignPrice(params))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(PlanBudget);
