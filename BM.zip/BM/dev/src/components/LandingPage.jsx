import React, { Component } from "react";
import { Route, Switch, withRouter, Redirect } from "react-router-dom";
import { connect } from "react-redux";
import {
  getServerCity,
  isPlainObjectES6
} from "./../utilities/helperFunctions";
import jsonRoute from "./Route";
import ComponentErrorSuccess from "./common/ComponentErrorSuccess";
import ErrorPage from "./common/ErrorPage";

//import Homepage from "./Homepage.jsx";
import Header from "./common/Header";
import Footer from "./common/Footer";

class LandingPage extends Component {
  constructor(props) {
    super(props);
  }
  getHeaderProps(routes, pathname) {
    let getHeaderPropsObj = {
      pageName: "Home",
      hasMenu: true,
      hasFilter: true,
      backUrl: ""
    };

    return getHeaderPropsObj;
  }

  componentDidMount() {}

  handleClearError = () => {};
  handleErrorSucccessMsg = () => {};

  render() {
    try {
      console.log("componentsuccess", this.props.component_success);
      const routes = jsonRoute.sidebarRoute;
      const { filter, datacity, location, history, error } = this.props;
      const { pageName, hasMenu, hasFooter, hasFilter } = this.getHeaderProps(
        routes,
        pathname
      );
      const { pathname } = location;
      //pathname == "/logout" && this.logout();
      if (error.length > 0) {
        return <ErrorPage error={error} />;
      }
      // if (!isPlainObjectES6(user)) {
      // 	var { type_of_employee } = user;
      // 	var typeofemployee = type_of_employee ? type_of_employee : "ME";
      // }
      //var errorSuccessMsgHtml = <ComponentErrorSuccess formError={"test"} formSuccess={""} handleClearError={this.handleClearError} handleErrorSucccessMsg={this.handleErrorSucccessMsg} />;
      return (
        <div>
          {/* {!isPlainObjectES6(user) && ( */}
          <div>
            {
              //errorSuccessMsgHtml
            }
            <Header
              props={(this.getHeaderProps(routes, pathname), history)}
              pathname={pathname}
            ></Header>
            <Switch>
              {routes.map((prop, key) => {
                let cmp = prop.component || "";
                if (cmp) {
                  return (
                    <Route
                      exact
                      path={prop.path}
                      history={this.props.history}
                      render={props => (
                        <prop.component {...props} myRef={this.myRef} />
                      )}
                      key={key}
                    />
                  );
                } else {
                  return <Route exact path={prop.path} key={key} />;
                }
              })}
              <Route
                exact
                path="/"
                render={() => {
                  //return this.props.location.pathname == "/" && typeofemployee == "ME" ? <Redirect to="/select-users" /> : <Redirect to="/select-users"/>;
                  return (
                    this.props.location.pathname == "/" && (
                      <Redirect to="/select-users" />
                    )
                  );
                }}
              />
            </Switch>
          </div>
          {/* )} */}
        </div>
      );
    } catch (err) {
      console.log("ERROR", err);
    }
  }
}

function mapStateToProps(state, props) {
  return {
    user: state.jd_store.user || "",
    error: state.jd_store.error || "",
    typeofemployee: state.jd_store.typeofemployee || "",
    datacity: state.jd_store.datacity,
    filter: state.jd_store.filter || "",
    component_success: state.jd_store.component_success
  };
}

export default withRouter(connect(mapStateToProps, {})(LandingPage));
