import React, { Component } from "react";
import { Link, withRouter } from "react-router-dom";
import { connect } from "react-redux";
import {
  fetchMainCities,
  fetchRemoteCities,
  fetchTierCities,
  fetchALLCities,
  fetchRemoteCityForFilters,
  selectCityArr
} from "./../redux/actions/userActions";
import { ucWords } from "./../utilities/helperFunctions";
import Minipopup from "./common/Minipopup";
import {
  Alert,
  Modal,
  Popover,
  Overlay,
  OverlayTrigger
} from "react-bootstrap";

class SelectCity extends Component {
  constructor(props) {
    super(props);
    this.state = {
      is11Mains: true,
      isRemote: false,
      isTier1: false,
      isTier2: false,
      isTier3: false,
      isTier4: false,
      filter_type: [],
      cityArr: [],
      searchRemoteText: "",
      searchTier1Text: "",
      searchTier2Text: "",
      searchTier3Text: "",
      searchTier4Text: "",
      authorizedEmp: false
    };
    this.searchRemoteCity = this.searchRemoteCity.bind(this);
    this.searchMainsCity = this.searchMainsCity.bind(this);
    this.searchTier1City = this.searchTier1City.bind(this);
    this.searchTier2City = this.searchTier2City.bind(this);
    this.searchTier3City = this.searchTier3City.bind(this);
    this.searchTier4City = this.searchTier4City.bind(this);
    this.selectCity = this.selectCity.bind(this);
  }

  componentDidMount() {
    this.fetchMainCitiesHandler();
    this.fetchRemoteCityForFiltersHandler();

    let empcode = localStorage.getItem("budget_admin_empcode");
    let allowedEmp = [
      "10102696",
      "10029347",
      "10099605",
      "10015427",
      "10015416",
      "000003",
      "10100392",
      "10083404"
    ];
    if (empcode && allowedEmp.indexOf(window.atob(empcode)) > -1) {
      this.setState({ authorizedEmp: true });
    }
    // if (this.props.selectCityArrDetails && this.props.selectCityArrDetails.length > 0) {
    // 	this.setState({
    // 		cityArr: this.props.selectCityArrDetails
    // 	})
    // }
  }
  fetchRemoteCityForFiltersHandler = () => {
    Promise.all([this.props.fetchRemoteCityForFilters({})]).then(() => {
      console.log("this.props", this.props);
    });
  };
  fetchALLCitiesHandler = () => {
    Promise.all([this.props.fetchALLCities({})]).then(() => {
      console.log("this.props", this.props);
    });
  };
  fetchMainCitiesHandler = () => {
    this.setState({
      is11Mains: true,
      isRemote: false,
      isTier1: false,
      isTier2: false,
      isTier3: false,
      isTier4: false
    });
    let params = {
      mainCity: "Main City"
    };
    Promise.all([this.props.fetchMainCities(params)]).then(() => {
      console.log("this.props", this.props);
    });
  };
  fetchRemoteCitiesHandler = () => {
    console.log("0000-");
    this.setState({
      is11Mains: false,
      isRemote: true,
      isTier1: false,
      isTier2: false,
      isTier3: false,
      isTier4: false
    });
    let params = {
      filterCity: this.state.filter_type,
      remoteCity: "Remote City",
      searchText: this.state.searchRemoteText.trim()
    };
    Promise.all([this.props.fetchRemoteCities(params)]).then(() => {
      this.setState({
        RemoteCities: this.props.RemoteCities
      });
      console.log("this.props.RemoteCities", this.props.RemoteCities);
    });
  };
  fetchTier1CitiesHandler = () => {
    this.setState({
      is11Mains: false,
      isRemote: false,
      isTier1: true,
      isTier2: false,
      isTier3: false,
      isTier4: false
    });
    let params = {
      tier: "Tier 1",
      searchText: this.state.searchTier1Text.trim()
    };
    Promise.all([this.props.fetchTierCities(params)]).then(() => {
      console.log("this.props---", this.props.TierCities);
      this.setState({
        TierCities: this.props.TierCities
      });
    });
  };
  fetchTier2CitiesHandler = () => {
    this.setState({
      is11Mains: false,
      isRemote: false,
      isTier1: false,
      isTier2: true,
      isTier3: false,
      isTier4: false
    });
    let params = {
      tier: "Tier 2",
      searchText: this.state.searchTier2Text.trim()
    };
    Promise.all([this.props.fetchTierCities(params)]).then(() => {
      console.log("this.props", this.props);
      this.setState({
        TierCities: this.props.TierCities
      });
    });
  };
  fetchTier3CitiesHandler = () => {
    this.setState({
      is11Mains: false,
      isRemote: false,
      isTier1: false,
      isTier2: false,
      isTier3: true,
      isTier4: false
    });
    let params = {
      tier: "Tier 3",
      searchText: this.state.searchTier3Text.trim()
    };
    Promise.all([this.props.fetchTierCities(params)]).then(() => {
      console.log("this.props", this.props);
      this.setState({
        TierCities: this.props.TierCities
      });
    });
  };
  fetchTier4CitiesHandler = () => {
    this.setState({
      is11Mains: false,
      isRemote: false,
      isTier1: false,
      isTier2: false,
      isTier3: false,
      isTier4: true
    });
    let params = {
      tier: "Tier 4",
      searchText: this.state.searchTier4Text.trim()
    };
    Promise.all([this.props.fetchTierCities(params)]).then(() => {
      console.log("this.props", this.props);
      this.setState({
        TierCities: this.props.TierCities
      });
    });
  };
  filterByType = type => {
    let index;
    let filterArray = this.state.filter_type;
    if (filterArray.includes(type)) {
      index = filterArray.indexOf(type);
      filterArray.splice(index, 1);
    } else {
      filterArray.push(type);
    }
    console.log(filterArray);
    this.setState({ filter_type: filterArray });
    this.fetchRemoteCitiesHandler();

    // }
  };

  searchRemoteCity(e) {
    console.log(e.target.value);
    this.setState({ searchRemoteText: e.target.value }, () => {
      this.fetchRemoteCitiesHandler();
    });
  }
  searchMainsCity(e) {
    this.setState({
      searchText: e.target.value
    });
    let searchQuery = this.state.mains11Cities.data;
    let searchResult = searchQuery.filter(function(value) {
      return value.City === e.target.value;
    });
    if (searchResult.length > 0) {
      this.state.mains11Cities.data = searchResult;
    } else {
      this.fetchMainCitiesHandler();
    }
  }
  searchTier1City(e) {
    this.setState({ searchTier1Text: e.target.value }, () => {
      this.fetchTier1CitiesHandler();
    });
  }
  searchTier2City(e) {
    this.setState({ searchTier2Text: e.target.value }, () => {
      this.fetchTier2CitiesHandler();
    });
  }
  searchTier3City(e) {
    this.setState({ searchTier3Text: e.target.value }, () => {
      this.fetchTier3CitiesHandler();
    });
  }
  searchTier4City(e) {
    this.setState({ searchTier4Text: e.target.value }, () => {
      this.fetchTier4CitiesHandler();
    });
  }

  selectCity(e, value) {
    let index;
    let cityName = value.toLowerCase();
    let city_arr = this.state.cityArr;
    console.log("cityName", cityName);
    if (city_arr.includes(cityName)) {
      index = city_arr.indexOf(cityName);
      city_arr.splice(index, 1);
    } else {
      city_arr.push(cityName);
    }
    console.log(city_arr);
    this.setState({ cityArr: city_arr });
    let params = {
      data: city_arr
    };
    Promise.all([this.props.selectCityArr(params)]).then(() => {
      console.log("this.props", this.props);
    });
  }

  closeAlert = () => {
    this.setState({ proceedPopup: false });
  };

  closeUnauthorizedAlert = () => {
    this.setState({ proceedPopup: false }, () => {
      window.location.href = "https://sales.genio.in/sales_genio";
    });
  };

  proceedTo() {
    console.log("1====", this.state.cityArr.length == 0);
    if (this.state.cityArr.length == 0) {
      this.setState({ proceedPopup: true });
    } else {
      this.props.history.push("/select-campaign");
    }
  }

  render() {
    if (this.state.proceedPopup) {
      return (
        <Minipopup
          title={"Select Cities"}
          text={"Please select atleast one city"}
          handleOk={this.closeAlert}
          okPopup={true}
        />
      );
    }

    if (!this.state.authorizedEmp) {
      return (
        <Minipopup
          title={"Unauthorized"}
          text={"You are not authorized to access this Module!"}
          handleOk={this.closeUnauthorizedAlert}
          okPopup={true}
        />
      );
    }

    return (
      <div className=" wrapper-block pb-30">
        <div className="wrapper-block ">
          <div className="font14 color414 fw600 p-20">
            {" "}
            Choose Desired Cities{" "}
          </div>
          <div className="myjdprdtbwp mb-10">
            <ul className="myjdprdtbs">
              <li
                className={
                  "font13 tabli csrpntr " +
                  (this.state.is11Mains ? "active" : "")
                }
                onClick={() => this.fetchMainCitiesHandler()}
              >
                9 Mains
              </li>
              <li
                className={
                  "font13 tabli csrpntr " +
                  (this.state.isRemote ? "active" : "")
                }
                onClick={() => this.fetchRemoteCitiesHandler()}
              >
                All Remoters
              </li>
              <li
                className={
                  "font13 tabli csrpntr " + (this.state.isTier1 ? "active" : "")
                }
                onClick={() => this.fetchTier1CitiesHandler()}
              >
                Tier 1
              </li>
              <li
                className={
                  "font13 tabli csrpntr " + (this.state.isTier2 ? "active" : "")
                }
                onClick={() => this.fetchTier2CitiesHandler()}
              >
                Tier 2
              </li>
              <li
                className={
                  "font13 tabli csrpntr " + (this.state.isTier3 ? "active" : "")
                }
                onClick={() => this.fetchTier3CitiesHandler()}
              >
                Tier 3
              </li>
              <li
                className={
                  "font13 tabli csrpntr " + (this.state.isTier4 ? "active" : "")
                }
                onClick={() => this.fetchTier4CitiesHandler()}
              >
                Tier 4
              </li>
            </ul>
          </div>

          {this.state.isRemote ? (
            <div className="wrapper-block radiusTabMainWrp mt-20">
              <ul className="radiusTabUl pl-20">
                {this.props.RemoteForFilter &&
                  this.props.RemoteForFilter.data.map((filterType, key) => {
                    let isActive = this.state.filter_type.includes(
                      filterType.Operating_Branch
                    )
                      ? "active"
                      : "";
                    return (
                      <li
                        className={
                          "radiusTab font13 color414 csrpntr " + isActive
                        }
                        key={"filtertype_" + key}
                        onClick={() =>
                          this.filterByType(filterType.Operating_Branch)
                        }
                      >
                        {filterType.Operating_Branch} Remote
                      </li>
                    );
                  })}
              </ul>
            </div>
          ) : (
            ""
          )}

          {this.state.is11Mains == true ? (
            <div className="wrapper-block pl-20 pr-20 pb-10">
              <div className="animwrap">
                {/* <label className="animcheck">
								<input className="animinput" type="checkbox" />
								<div className="animlabel">
									<span className="animicon"></span>
									<span className="animtext font16 fw600 color1a1"> Select All </span>
								</div>
							</label> */}
                {this.props.mains11Cities &&
                  this.props.mains11Cities.data.map((val, index) => {
                    let isChecked = this.state.cityArr.includes(
                      val.City.toLowerCase()
                    )
                      ? true
                      : false;

                    return (
                      <label key={"filtertype_" + index} className="animcheck">
                        <input
                          className="animinput"
                          type="checkbox"
                          value="true"
                          checked={isChecked}
                          onChange={e => this.selectCity(e, val.City)}
                        />
                        <div className="animlabel">
                          <span className="animicon"></span>
                          <span className="animtext font16 fw600 color1a1">
                            {" "}
                            {val.City}{" "}
                          </span>
                        </div>
                      </label>
                    );
                  })}
              </div>
            </div>
          ) : (
            ""
          )}
          {this.state.isRemote == true ? (
            <div className="pl-20 pr-20 mb-10">
              <div className="wrapper-block  searchinputBox">
                <i className="icon-common searchIcn"> </i>
                <input
                  className="inputBx color414 font15 fw600"
                  autoComplete="off"
                  value={this.state.searchRemoteText}
                  onChange={e => this.searchRemoteCity(e)}
                  placeholder="Search Remote Cities"
                />
              </div>
            </div>
          ) : (
            ""
          )}
          {this.state.isRemote == true ? (
            <div className="wrapper-block pl-20 pr-20 pb-10">
              <div className="animwrap">
                {/* <label className="animcheck">
									<input className="animinput" type="checkbox"  />
									<div className="animlabel">
										<span className="animicon"></span>
										<span className="animtext font16 fw600 color1a1"> Select All </span>
									</div>
								</label> */}
                {this.state.RemoteCities &&
                  this.state.RemoteCities.data.map((val, index) => {
                    let isChecked = this.state.cityArr.includes(
                      val.City.toLowerCase()
                    )
                      ? true
                      : false;
                    return (
                      <label key={"filtertype_" + index} className="animcheck">
                        <input
                          className="animinput"
                          type="checkbox"
                          value="true"
                          checked={isChecked}
                          onChange={e => this.selectCity(e, val.City)}
                        />
                        <div className="animlabel">
                          <span className="animicon"></span>
                          <span className="animtext font16 fw600 color1a1">
                            {" "}
                            {val.City}{" "}
                          </span>
                        </div>
                      </label>
                    );
                  })}
              </div>
            </div>
          ) : (
            ""
          )}
          {this.state.isTier1 == true ? (
            <div className="pl-20 pr-20 mb-10">
              <div className="wrapper-block  searchinputBox">
                <i className="icon-common searchIcn"> </i>
                <input
                  className="inputBx color414 font15 fw600"
                  value={this.state.searchTier1Text}
                  onChange={e => this.searchTier1City(e)}
                  autoComplete="off"
                  placeholder="Search Tier 1"
                />
              </div>
            </div>
          ) : (
            ""
          )}
          {this.state.isTier1 == true ? (
            <div className="wrapper-block pl-20 pr-20 pb-10">
              <div className="animwrap">
                {/* <label className="animcheck">
								<input className="animinput" type="checkbox" />
								<div className="animlabel">
									<span className="animicon"></span>
									<span className="animtext font16 fw600 color1a1"> Select All </span>
								</div>
							</label> */}
                {this.props.TierCities &&
                  this.props.TierCities.data.map((val, index) => {
                    let isChecked = this.state.cityArr.includes(
                      val.City.toLowerCase()
                    )
                      ? true
                      : false;
                    return (
                      <label key={"filtertype_" + index} className="animcheck">
                        <input
                          className="animinput"
                          type="checkbox"
                          value="true"
                          checked={isChecked}
                          onChange={e => this.selectCity(e, val.City)}
                        />
                        <div className="animlabel">
                          <span className="animicon"></span>
                          <span className="animtext font16 fw600 color1a1">
                            {" "}
                            {val.City}{" "}
                          </span>
                        </div>
                      </label>
                    );
                  })}
              </div>
            </div>
          ) : (
            ""
          )}
          {this.state.isTier2 == true ? (
            <div className="pl-20 pr-20 mb-10">
              <div className="wrapper-block  searchinputBox">
                <i className="icon-common searchIcn"> </i>
                <input
                  className="inputBx color414 font15 fw600"
                  value={this.state.searchTier2Text}
                  onChange={e => this.searchTier2City(e)}
                  autoComplete="off"
                  placeholder="Search Tier 2"
                />
              </div>
            </div>
          ) : (
            ""
          )}
          {this.state.isTier2 == true ? (
            <div className="wrapper-block pl-20 pr-20 pb-10">
              <div className="animwrap">
                {/* <label className="animcheck">
								<input className="animinput" type="checkbox"  />
								<div className="animlabel">
									<span className="animicon"></span>
									<span className="animtext font16 fw600 color1a1"> Select All </span>
								</div>
							</label> */}
                {this.props.TierCities &&
                  this.props.TierCities.data.map((val, index) => {
                    let isChecked = this.state.cityArr.includes(
                      val.City.toLowerCase()
                    )
                      ? true
                      : false;
                    return (
                      <label key={"filtertype_" + index} className="animcheck">
                        <input
                          className="animinput"
                          type="checkbox"
                          value="true"
                          checked={isChecked}
                          onChange={e => this.selectCity(e, val.City)}
                        />
                        <div className="animlabel">
                          <span className="animicon"></span>
                          <span className="animtext font16 fw600 color1a1">
                            {" "}
                            {val.City}{" "}
                          </span>
                        </div>
                      </label>
                    );
                  })}
              </div>
            </div>
          ) : (
            ""
          )}
          {this.state.isTier3 == true ? (
            <div className="pl-20 pr-20 mb-10">
              <div className="wrapper-block  searchinputBox">
                <i className="icon-common searchIcn"> </i>
                <input
                  className="inputBx color414 font15 fw600"
                  value={this.state.searchTier3Text}
                  onChange={e => this.searchTier3City(e)}
                  autoComplete="off"
                  placeholder="Search Tier 3"
                />
              </div>
            </div>
          ) : (
            ""
          )}
          {this.state.isTier3 == true ? (
            <div className="wrapper-block pl-20 pr-20 pb-10">
              <div className="animwrap">
                {/* <label className="animcheck">
								<input className="animinput" type="checkbox" />
								<div className="animlabel">
									<span className="animicon"></span>
									<span className="animtext font16 fw600 color1a1"> Select All </span>
								</div>
							</label> */}
                {this.props.TierCities &&
                  this.props.TierCities.data.map((val, index) => {
                    let isChecked = this.state.cityArr.includes(
                      val.City.toLowerCase()
                    )
                      ? true
                      : false;
                    return (
                      <label key={"filtertype_" + index} className="animcheck">
                        <input
                          className="animinput"
                          type="checkbox"
                          value="true"
                          checked={isChecked}
                          onChange={e => this.selectCity(e, val.City)}
                        />
                        <div className="animlabel">
                          <span className="animicon"></span>
                          <span className="animtext font16 fw600 color1a1">
                            {" "}
                            {val.City}{" "}
                          </span>
                        </div>
                      </label>
                    );
                  })}
              </div>
            </div>
          ) : (
            ""
          )}
          {this.state.isTier4 == true ? (
            <div className="pl-20 pr-20 mb-10">
              <div className="wrapper-block  searchinputBox">
                <i className="icon-common searchIcn"> </i>
                <input
                  className="inputBx color414 font15 fw600"
                  value={this.state.searchTier4Text}
                  onChange={e => this.searchTier4City(e)}
                  autoComplete="off"
                  placeholder="Search Tier 4"
                />
              </div>
            </div>
          ) : (
            ""
          )}
          {this.state.isTier4 == true ? (
            <div className="wrapper-block pl-20 pr-20 pb-10">
              <div className="animwrap">
                {/* <label className="animcheck">
								<input className="animinput" type="checkbox" />
								<div className="animlabel">
									<span className="animicon"></span>
									<span className="animtext font16 fw600 color1a1"> Select All </span>
								</div>
							</label> */}
                {this.props.TierCities &&
                  this.props.TierCities.data.map((val, index) => {
                    let isChecked = this.state.cityArr.includes(
                      val.City.toLowerCase()
                    )
                      ? true
                      : false;
                    return (
                      <label key={"filtertype_" + index} className="animcheck">
                        <input
                          className="animinput"
                          type="checkbox"
                          value="true"
                          checked={isChecked}
                          onChange={e => this.selectCity(e, val.City)}
                        />
                        <div className="animlabel">
                          <span className="animicon"></span>
                          <span className="animtext font16 fw600 color1a1">
                            {" "}
                            {val.City}{" "}
                          </span>
                        </div>
                      </label>
                    );
                  })}
              </div>
            </div>
          ) : (
            ""
          )}
        </div>

        {/* <Link to={"/select-campaign"}> */}
        <div className="btmFixBtn">
          <button
            className="ftrBlueBtn font16"
            onClick={() => this.proceedTo()}
          >
            {" "}
            Proceed{" "}
          </button>
        </div>
        {/* </Link> */}
      </div>
    );
  }
}
function mapStateToProps(state, props) {
  return {
    mains11Cities: state.jd_store.fetch11MainsCitiesData,
    RemoteCities: state.jd_store.fetchRemoteCitiesData,
    TierCities: state.jd_store.fetchTierCitiesData,
    RemoteForFilter: state.jd_store.fetchRemoteForFilter,
    selectCityArrDetails: state.jd_store.selectCityArrData
  };
}

const mapDispatchToProps = dispatch => {
  return {
    fetchMainCities: params => dispatch(fetchMainCities(params)),
    fetchRemoteCities: params => dispatch(fetchRemoteCities(params)),
    fetchTierCities: params => dispatch(fetchTierCities(params)),
    fetchALLCities: params => dispatch(fetchALLCities(params)),
    fetchRemoteCityForFilters: params =>
      dispatch(fetchRemoteCityForFilters(params)),
    selectCityArr: params => dispatch(selectCityArr(params))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(SelectCity);
