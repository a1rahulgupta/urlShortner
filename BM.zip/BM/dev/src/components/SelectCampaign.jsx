import React, { Component } from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import {
  fetchCampaignList,
  activeInactiveCampaign,
  fetchTempBudgetWindow,
  selectCamp
} from "./../redux/actions/userActions";

class SelectCampaign extends Component {
  constructor(props) {
    super(props);
    this.state = {
      actflag: true,
      resSqlQueryForAddOns: [],
      resSqlQueryForAll: [],
      resSqlQueryForNational: [],
      resSqlQueryForOthers: [],
      // isTempBudget: false,
      resInactiveCampaigns: []
    };
    this.activeInactiveCampaignHandler = this.activeInactiveCampaignHandler.bind(
      this
    );
  }
  componentDidMount() {
    this.fetchCampaignListHandler();
    console.log("---selelct city arrr", this.props.selectCityArrDetails);
    console.log("Temp budget--", this.props);
    if (
      this.props.tempBudgetWindow &&
      this.props.tempBudgetWindow.data.budget_timming.length > 0
    ) {
      this.setState({
        // isTempBudget: this.props.tempBudgetWindow.data.budget_timming.is_active
      });
    }
  }

  activeInactiveCampaignHandler(e, campaign_id) {
    let active_flag = e == 1 ? 0 : 1;

    if (this.state.resInactiveCampaigns.includes(campaign_id)) {
      active_flag = 1;
    }

    Promise.all([
      this.props.activeInactiveCampaign({
        active_flag: active_flag,
        campaign_id: campaign_id,
        empcode: EMPCODE,
        username: "",
        selectedCity: this.props.selectCityArrDetails
        // isTempBudget: localStorage.getItem('isTempBudget'),
      })
    ]).then(() => {
      this.fetchCampaignListHandler();
    });
  }

  fetchCampaignListHandler = () => {
    let params = {
      // isTempBudget: localStorage.getItem('isTempBudget'),
      selectedCity: this.props.selectCityArrDetails
    };
    Promise.all([this.props.fetchCampaignList(params)]).then(() => {
      if (this.props.CampaignList && this.props.CampaignList.data) {
        console.log(
          "console.log(this.state.resSqlQueryForAll)",
          this.props.CampaignList.data
        );
        this.setState({
          resSqlQueryForAddOns: this.props.CampaignList.data
            .resSqlQueryForAddOns,
          resSqlQueryForAll: this.props.CampaignList.data.resSqlQueryForAll,
          resSqlQueryForNational: this.props.CampaignList.data
            .resSqlQueryForNational,
          resSqlQueryForOthers: this.props.CampaignList.data
            .resSqlQueryForOthers
          // resInactiveCampaigns: this.props.CampaignList.data.resInactiveCampaigns.length > 0 ? this.props.CampaignList.data.resInactiveCampaigns : []
        });
      }
    });
  };

  fetchTempBudgetWindowHandler = () => {
    Promise.all([
      this.props.fetchTempBudgetWindow({
        data_city: this.state.dataCity
      })
    ]).then(() => {});
  };

  proceedToNext(newVal, type) {
    let params = {
      data: {
        campname: newVal.campname,
        campid: newVal.campid
      }
    };
    Promise.all([this.props.selectCamp(params)]).then(() => {
      console.log("this.props", this.props);
    });

    if (type == "add_on") {
      this.props.history.push({
        pathname: "/UpdateAddOn/" + newVal.campid,
        state: {
          campname: newVal.campname,
          campid: newVal.campid
        }
      });
    } else {
      if (newVal.campid == 54) {
        this.props.history.push({
          pathname: "/select-variant",
          state: {
            campname: newVal.campname,
            campid: newVal.campid
          }
        });
      }
      if (newVal.campid == 95) {
        this.props.history.push({
          pathname: "/planCampaign"
        });
      }

      if (newVal.campid == 2) {
        this.props.history.push({
          pathname: "/ChooseTop5Plan"
        });
      }
    }

    // this.props.history.push("/plan-budget/" + newVal.campid)
  }

  render() {
    console.log("console.log(this.props)", this.state);

    return (
      <div className=" wrapper-block pb-30">
        <div className="wrapper-block p-20">
          {this.props.CampaignList && this.props.CampaignList.data ? (
            <ul className="typeAWrp wrapper-block pb-10">
              {this.state.resSqlQueryForAll.map((newVal, newKey) => {
                console.log("camp", newVal);
                return (
                  <div key={newKey}>
                    {newVal.campid == "54" ? (
                      <li
                        className="selUserLi dtable  color1a1 pl-15  csrpntr"
                        onClick={() => this.proceedToNext(newVal)}
                      >
                        {" "}
                        <div className="dtable pb-20">
                          {/* <div className="dtablecell switchwidth">
                                                <label className="dtablecell switch">
                                                    <input type="checkbox" value="true" checked={(newVal.active_flag == 1) ? true : false} onChange={() => this.activeInactiveCampaignHandler(newVal.active_flag, newVal.campid)} />
                                                    <span className="slider"></span>
                                                </label>
                                            </div> */}
                          <div className="dtablecell">
                            <span className="font14 fw600">
                              {newVal.campname}{" "}
                            </span>
                          </div>
                          <div className="dtablecell rtArrowBx text-right ">
                            <i className="rightBlkarrow icon-common"> </i>
                          </div>
                        </div>
                      </li>
                    ) : newVal.campid == "2" ? (
                      <li
                        className="selUserLi dtable  color1a1 pl-15  csrpntr"
                        onClick={() => this.proceedToNext(newVal)}
                      >
                        {" "}
                        <div className="dtable pb-20">
                          {/* <div className="dtablecell switchwidth">
                                                <label className="dtablecell switch">
                                                    <input type="checkbox" value="true" checked={(newVal.active_flag == 1) ? true : false} onChange={() => this.activeInactiveCampaignHandler(newVal.active_flag, newVal.campid)} />
                                                    <span className="slider"></span>
                                                </label>
                                            </div> */}
                          <div className="dtablecell">
                            <span className="font14 fw600">
                              {newVal.campname}{" "}
                            </span>
                          </div>
                          <div className="dtablecell rtArrowBx text-right ">
                            <i className="rightBlkarrow icon-common"> </i>
                          </div>
                        </div>
                      </li>
                    ) : (
                      ""
                    )}
                  </div>
                );
              })}

              <div className="dtable font13 color788 pb-25">Addons </div>
              <li className="selUserLi dtable  color1a1 pl-15  csrpntr">
                {this.state.resSqlQueryForAddOns.map((childVal, newKey) => {
                  return (
                    <div key={newKey}>
                      {childVal.active_flag == 1 &&
                        childVal.campid != 7 &&
                        childVal.campid != 11 &&
                        childVal.campid != 26 &&
                        childVal.campid != 112 && (
                          <div
                            className="dtable pb-20"
                            onClick={() =>
                              this.proceedToNext(childVal, "add_on")
                            }
                          >
                            {/* <div className="dtablecell switchwidth">
                                                <label className="dtablecell switch">
                                                    <input type="checkbox" />
                                                    <span className="slider"></span>
                                                </label>
                                            </div> */}
                            <div className="dtablecell">
                              <span className="font14 fw600">
                                {" "}
                                {childVal.campname}{" "}
                              </span>
                            </div>
                            <div className="dtablecell rtArrowBx text-right ">
                              {" "}
                              <i className="rightBlkarrow icon-common">
                                {" "}
                              </i>{" "}
                            </div>
                          </div>
                        )}
                    </div>
                  );
                })}
              </li>

              {/* <div className="dtable font13 color788 pb-25">Addons </div>
                        <li className="selUserLi dtable  color1a1 pl-15  csrpntr">
                            {this.state.resSqlQueryForAddOns.map((childVal, newKey) => {
                                return (
                                    <div key={newKey} className="dtable pb-20">
                                        <div className="dtablecell switchwidth">
                                            <label className="dtablecell switch">
                                                <input type="checkbox" />
                                                <span className="slider"></span>
                                            </label>
                                        </div>
                                        <div className="dtablecell">
                                            <span className="font14 fw600"> {childVal.campname} </span>
                                        </div>
                                        <div className="dtablecell rtArrowBx text-right "> <i className="rightBlkarrow icon-common"> </i> </div>
                                    </div>
                                )
                            })}
                        </li>
                        <div className="dtable font13 color788 pb-25">National Listing </div>
                        <li className="selUserLi dtable  color1a1 pl-15  csrpntr">
                            {this.state.resSqlQueryForNational.map((childVal, newKey) => {
                                return (
                                    <div key={newKey} className="dtable pb-20">
                                        <div className="dtablecell switchwidth">
                                            <label className="dtablecell switch">
                                                <input type="checkbox" />
                                                <span className="slider"></span>
                                            </label>
                                        </div>
                                        <div className="dtablecell">
                                            <span className="font14 fw600"> {childVal.campname} </span>
                                        </div>
                                        <div className="dtablecell rtArrowBx text-right "> <i className="rightBlkarrow icon-common"> </i> </div>
                                    </div>
                                )
                            })}
                        </li>
                        <div className="dtable font13 color788 pb-25">Others </div>
                        <li className="selUserLi dtable  color1a1 pl-15  csrpntr">
                            {this.state.resSqlQueryForOthers.map((childVal, newKey) => {
                                return (
                                    <div key={newKey} className="dtable pb-20">
                                        <div className="dtablecell switchwidth">
                                            <label className="dtablecell switch">
                                                <input type="checkbox" />
                                                <span className="slider"></span>
                                            </label>
                                        </div>
                                        <div className="dtablecell">
                                            <span className="font14 fw600"> {childVal.campname} </span>
                                        </div>
                                        <div className="dtablecell rtArrowBx text-right "> <i className="rightBlkarrow icon-common"> </i> </div>
                                    </div>
                                )
                            })}
                        </li> */}
            </ul>
          ) : (
            ""
          )}
        </div>
      </div>
    );
  }
}
function mapStateToProps(state, props) {
  return {
    CampaignList: state.jd_store.fetchCampaignListData,
    selectCityArrDetails: state.jd_store.selectCityArrData,
    tempBudgetWindow: state.jd_store.tempBudgetWindow
  };
}

const mapDispatchToProps = dispatch => {
  return {
    fetchCampaignList: params => dispatch(fetchCampaignList(params)),
    activeInactiveCampaign: params => dispatch(activeInactiveCampaign(params)),
    fetchTempBudgetWindow: params => dispatch(fetchTempBudgetWindow(params)),
    selectCamp: params => dispatch(selectCamp(params))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(SelectCampaign);
// export default SelectCampaign;
