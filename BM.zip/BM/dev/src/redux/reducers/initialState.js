import {
  setLocalStorage,
  getLocalStorage
} from "./../../utilities/localStorage";

export default {
  jwt: "",
  empcode: EMPCODE,
  datacity: "",
  user: {},
  loading: false,
  dataLoaded: undefined,
  error: null,
  component_error: null,
  component_success: null,
  cityData: [],
  searchSuggestions: [],
  lhsMenu: false,
  recentSearch:
    localStorage.getItem("recentSearch") == undefined
      ? []
      : JSON.parse(localStorage.getItem("recentSearch")),
  filter: false,
  filterVal: [],
  userDetails: [],
  helpdeskForm: {
    email: "",
    mobile: "",
    city: "",
    subject: "",
    message: "",
    photo: false
  },
  menuLinks: {},

  dealsPendingData: [],
  dealsPendingPage: "0",

  dealsClosedData: [],
  dealsClosedPage: "0",

  todaysAppintmentData: [],
  todaysAppintmentPage: "0",

  appintmentData: [],
  appintmentPage: "0",

  newBusinessData: [],
  newBusinessPage: "0",

  feedbackReport: {},
  feedbackReportPage: "1",

  downsell_report: [],
  downsell_report_page: "0",

  ratings: [],
  ratingsPage: "0",

  dispositionReport: [],
  dispositionReport_type: 22,
  dispositionReport_page: "0",

  finance_ecs_hits: [],
  finance_ecs_hits_pid: [],
  finance_ecs_hits_page: 0,
  finance_ecs_hits_end: 0,
  finance_ecs_hits_total: 0,
  finance_ecs_hits_count: 0,
  finance_ecs_hits_end: 0,
  finance_show_payment: [],
  finance_ecs_si: [],
  finance_mandate_status: [],
  finance_sales_report: [],
  finance_sales_report_page: 0,
  finance_sales_report_end: 0,
  finance_sales_count: 0,
  finance_ecs_sales_count: 0,
  finance_ecs_sales_report: [],
  finance_bounce_report: [],
  generate_invoice_autosuggest: [],
  finance_invoice_details: [],
  finance_html_data: [],

  contract_filter: { filter_campaign: [], filter_type: [], filter_source: [] },
  sales_report_filter: {
    payment_type: ["digital"],
    instrument_type: ["debit card", "credit card", "cheque", "cash"],
    instrument_status: ["cleared"]
  },
  sales_ecs_report_filter: {
    status: ["paid"],
    mandate_type: ["ecs", "ccsi", "digitalmandate", "emandate"],
    date_type: ["clearance"]
  },
  ecs_report_filter: {
    status: ["all"],
    mandate_type: ["ecs"],
    date_type: "due_date"
  },

  clickCallMobileNumber: [],
  digital_payment_stats: [],
  digital_payment_filter: ["revenue", "team"],
  my_points_details: [],
  my_ratings: [],
  HotKeywordData: [],
  toggleHistory: false,
  whatsappMsg: {
    rdx_whatsappLangToggle: false,
    rdx_whatsappLangage: "English"
  },
  fetchAppointment: 0,
  pendingAppointments: [],
  fetchpaymentsummary: [],
  mustReadOpen: false
};
