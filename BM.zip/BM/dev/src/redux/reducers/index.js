import { combineReducers } from "redux";
import jd_store from "./userReducer";

const rootReducer = combineReducers({
  jd_store
});
export default rootReducer;
