import * as types from "../actions/actionTypes";
import initialState from "./initialState";
import { getLocalStorage, setLocalStorage } from "../../utilities/localStorage";

function userReducer(state = initialState, action) {
  // eslint-disable-next-line default-case
  //let backUrl = window.location.href;
  //console.log(backUrl.replace('sales_genio#','salse_genio/#'));
  //localStorage.setItem("new_genio_back", backUrl.replace("sales_genio#", "sales_genio/#"));
  //localStorage.setItem("currLink", backUrl.replace("sales_genio#", "sales_genio/#"));

  let mainCityArr = [
    "mumbai",
    "delhi",
    "kolkata",
    "chennai",
    "bangalore",
    "hyderabad",
    "pune",
    "ahmedabad"
  ];

  switch (action.type) {
    case types.CREATE_NEW_BUSINESS:
      return {
        ...state,
        newBusinessCreation: action.payload
      };
    case types.SET_AUTH_TOKEN:
      return {
        ...state,
        error: state.error,
        jwt: action.payload.jwt || "",
        component_success: null,
        component_error: null
      };
    case types.SET_USER:
      const { city, type_of_employee, department, team_type } = {
        ...action.payload.data
      };
      let localDatacity = getLocalStorage("datacity");
      let localRedirDatacity = getLocalStorage("redir_datacity");
      if (!(localDatacity != undefined && localDatacity != "")) {
        setLocalStorage("datacity", city.toLowerCase());
      }
      setLocalStorage("emp_department", department);
      setLocalStorage("sso_login_city", city);

      if (type_of_employee === "TME") {
        setLocalStorage("bypass", 1);
        setLocalStorage("user_type", "TME");
        setLocalStorage("Module", "TME");
        setLocalStorage("allocId", team_type);
        if (!(localRedirDatacity != undefined && localRedirDatacity != "")) {
          setLocalStorage("redir_datacity", city.toLowerCase());
          setLocalStorage(
            "tmeObj",
            JSON.stringify({
              city_type: mainCityArr.includes(city.toLowerCase())
                ? "main"
                : "remote",
              data_city: city.toLowerCase(),
              station_id: ""
            })
          );
          setLocalStorage("DialerAPICall", 1);
          setLocalStorage("filterParams", null);
          setLocalStorage("isFilterApplied", null);
          setLocalStorage("pageNum", null);
        }
        //console.log(getLocalStorage("tmeObj"));
      } else {
        setLocalStorage("bypass", 0);
        setLocalStorage("user_type", "ME");
        setLocalStorage("Module", "ME");
        if (!(localRedirDatacity != undefined && localRedirDatacity != "")) {
          if (mainCityArr.includes(city.toLowerCase())) {
            setLocalStorage("redir_datacity", city.toLowerCase());
          } else {
            setLocalStorage("redir_datacity", "remote");
          }
        }
      }
      setLocalStorage("PageState", "onClick");
      //setLocalStorage("currLink", "/allocation/newBusiness");
      //setLocalStorage("pageNum", 0);
      setLocalStorage("LeftLink", "newBusiness");
      //setLocalStorage("LandingPage", "/allocation/newBusiness");
      setLocalStorage(
        "typeofemployee",
        action.payload.data.type_of_employee || "ME"
      );
      setLocalStorage(
        "typeOfEmployee",
        action.payload.data.type_of_employee || "ME"
      );
      setLocalStorage("allowRec", 0);
      setLocalStorage("searchString");
      setLocalStorage("disposeonline", 0);
      setLocalStorage("onboarding", 0);
      setLocalStorage("localResetPageFlag", 0);
      setLocalStorage("trackFlag", 1);

      return {
        ...state,
        error: state.error,
        user: action.payload.data || {},
        typeofemployee: action.payload.data.type_of_employee || "ME",
        component_success: true,
        component_error: null
      };

    case types.SET_ERROR:
      return {
        ...state,
        error: action.payload.error
      };

    case types.SET_COMPONENT_ERROR:
      return {
        ...state,
        component_error: {
          ...state.component_error,
          [action.payload.store_component]: action.payload.component_error
        },
        error: state.error,
        component_success: null
      };

    case types.SET_COMPONENT_SUCCESS:
      return {
        ...state,
        component_success: {
          ...state.component_success,
          [action.payload.store_component]: action.payload.component_success
        },
        error: state.error,
        component_error: null
      };

    case types.CLEAR_ERROR:
      return {
        ...state,
        error: action.payload.error
      };
    case types.RESET_ERROR:
      return {
        ...state,
        component_error: ""
      };
    case types.CLEAR_COMPONENT_MSG:
      return {
        ...state,
        component_success: null,
        error: state.error,
        component_error: null
      };
    /**city selection */
    case types.FETCH_CITIES:
      return {
        ...state,
        error: state.error,
        cityData: action.payload.data || [],
        component_success: true
      };
    case types.CLEAR_CITIES:
      return {
        ...state,
        error: state.error,
        cityData: [],
        component_success: true
      };
    case types.SET_RECENT_CITIES:
      return {
        ...state,
        error: state.error,
        recentSearches: action.payload.data || "",
        component_success: true
      };
    case types.SET_DATACITY:
      return {
        ...state,
        error: state.error,
        datacity: action.payload.data || "",
        component_success: true
      };

    case types.GET_TODAYS_APPOINTMENTS:
      let todaysAppintmentData =
        state.todaysAppintmentPage != action.payload.pageShow
          ? [...state.todaysAppintmentData, ...action.payload.data]
          : action.payload.data;
      return {
        ...state,
        error: state.error,
        todaysAppintmentData: todaysAppintmentData,
        todaysAppintmentPage: action.payload.pageShow,
        todaysAppintmentTotal: action.payload.counttot,
        dataLoaded: todaysAppintmentData.length,
        component_success: true
      };

    /**get appointments */

    case types.GET_APPOINTMENTS:
      let appintmentData =
        state.appintmentPage != action.payload.pageShow
          ? [...state.appintmentData, ...action.payload.data]
          : action.payload.data;
      // console.log(state);
      return {
        ...state,
        error: state.error,
        appintmentData: appintmentData,
        appintmentPage: action.payload.pageShow,
        appintmentTotal: action.payload.counttot,
        dataLoaded: appintmentData.length,
        component_success: true
      };
    /**get last dispocition */
    case types.GET_LAST_DISPOSITION:
      // console.log(action.payload);
      return {
        ...state,
        error: state.error,
        lastDispositionData: action.payload.data || [],
        component_success: true
      };
    case types.GET_NEW_BUSINESS:
      //console.log(state.newBusinessData, action.payload);
      let newBusinessData =
        state.newBusinessPage != action.payload.pageShow
          ? [...state.newBusinessData, ...action.payload.data]
          : action.payload.data;
      return {
        ...state,
        error: state.error,
        newBusinessData: newBusinessData || [],
        newBusinessTotal: action.payload.counttot,
        appnewBusinessPage: action.payload.pageShow,
        dataLoaded: newBusinessData.length,
        component_success: true
      };

    case types.GET_ASSIGNMENTDATA:
      // console.log(action.payload);
      let assignmentType = action.payload.action;
      let assignmentInitPage = state[assignmentType + "Page"] || "0";
      let assignmentInitData = state[assignmentType] || [];
      let assignmentData =
        assignmentInitPage != action.payload.pageShow
          ? [...assignmentInitData, ...action.payload.data.data]
          : action.payload.data.data;

      //console.log(assignmentInitPage, assignmentInitData, assignmentData);

      return {
        ...state,
        error: state.error,
        [assignmentType]: assignmentData,
        [assignmentType + "Page"]: action.payload.pageShow,
        [assignmentType + "Total"]: action.payload.data.counttot,
        dataLoaded: assignmentData.length,
        component_success: true
      };

    case types.FETCH_GENIO_GRAPH:
      return {
        ...state,
        error: state.error,
        genioGraph: action.payload.data || [],
        component_success: true
      };
    case types.GET_FAQ_DETAILS:
      return {
        ...state,
        error: state.error,
        faq_details: action.payload.data || [],
        component_success: true
      };
    case types.SEARCH_SUGGESTION:
      return {
        ...state,
        error: state.error,
        searchSuggestions: action.payload.data.data || [],
        component_success: true
      };
    case types.CLEAR_SUGGESTION:
      return {
        ...state,
        error: state.error,
        searchSuggestions: [],
        component_success: true
      };
    case types.LHS_TOGGLE:
      //console.log(state);
      return {
        ...state,
        lhsMenu: !state.lhsMenu
      };
    case types.FILTER_TOGGLE:
      //console.log(state);
      return {
        ...state,
        filter: !state.filter
      };
    case types.APPLY_FILTERS:
      return {
        ...state,
        contract_filter: {
          filter_campaign: action.payload.filter_campaign,
          filter_type: action.payload.filter_type,
          filter_source: action.payload.filter_source
        },
        filter: false
      };
    case types.APPLY_SALES_FILTERS:
      return {
        ...state,
        sales_report_filter: {
          payment_type: action.payload.payment_type,
          instrument_type: action.payload.instrument_type,
          instrument_status: action.payload.instrument_status
        },
        finance_sales_report_page: 0,
        filter: false
      };
    case types.APPLY_SALES_ECS_FILTERS:
      return {
        ...state,
        sales_ecs_report_filter: {
          status: action.payload.status,
          mandate_type: action.payload.mandate_type,
          date_type: action.payload.date_type
        },
        finance_sales_report_page: 0,
        filter: false
      };
    case types.APPLY_ECS_FILTERS:
      return {
        ...state,
        ecs_report_filter: {
          status: action.payload.status,
          mandate_type: action.payload.mandate_type,
          date_type: action.payload.date_type
        },
        finance_ecs_hits_page: 0,
        filter: false
      };
    case types.RECENT_SEARCH:
      //console.log(state);
      return {
        ...state,
        recentSearch: JSON.parse(localStorage.getItem("recentSearch"))
      };
    case types.GET_DEALS_PENDING:
      let dealsPendingData =
        state.dealsPendingPage != action.payload.pageShow
          ? [...state.dealsPendingData, ...action.payload.data]
          : action.payload.data;
      return {
        ...state,
        error: state.error,
        dealsPendingData: dealsPendingData || [],
        dealsPendingPage: action.payload.pageShow,
        dealsPendingTotal: action.payload.counttot,
        dataLoaded: dealsPendingData.length,
        component_success: true
      };
    case types.GET_DEALS_CLOSED:
      let dealsClosedData =
        state.dealsClosedPage != action.payload.pageShow
          ? [...state.dealsClosedData, ...action.payload.data]
          : action.payload.data;
      return {
        ...state,
        error: state.error,
        dealsClosedData: dealsClosedData || [],
        dealsClosedPage: action.payload.pageShow,
        dealsClosedTotal: action.payload.counttot,
        dataLoaded: dealsClosedData.length,
        component_success: true
      };
    case types.FETCH_MENU_LINKS:
      return {
        ...state,
        menuLinks: action.payload.data,
        error: state.error,
        component_success: true
      };
    case types.GET_RATINGS:
      // console.log(action.payload);
      //let ratings = state.ratingsPage != action.payload.pageShow ? [...state.ratings, ...action.payload] : action.payload;

      return {
        ...state,
        error: state.error,
        ratings: action.payload || [],
        //	ratings: ratings || [],
        //	ratingsPage: action.payload.pageShow,
        component_success: true
      };
    case types.GET_FULLADDRESS:
      // console.log(action.payload);
      //let ratings = state.ratingsPage != action.payload.pageShow ? [...state.ratings, ...action.payload] : action.payload;
      let mobile_str = "";
      if (action.payload) {
        for (let [key, value] of Object.entries(action.payload)) {
          mobile_str += value["mobile"] + ",";
        }
      }
      return {
        ...state,
        error: state.error,
        full_addresses: action.payload || [],
        mobile_str: mobile_str.replace(/,\s*$/, "") || "", //remove last comma
        //	ratings: ratings || [],
        //	ratingsPage: action.payload.pageShow,
        component_success: true
      };
    case types.JD_APP_DOWNLOAD_STATUS:
      return {
        ...state,
        error: state.error,
        jd_app_download_status: action.payload.data || {},
        component_success: null,
        component_error: null
      };
    case types.JD_MART_DOWNLOAD_STATUS:
      return {
        ...state,
        error: state.error,
        jd_mart_download_status: action.payload.data || {},
        component_success: null,
        component_error: null
      };
    case types.GET_ACTIVE_CAPMS:
      //console.log(action.payload);
      return {
        ...state,
        error: state.error,
        campaignDetails: action.payload.data || [],
        component_success: true
      };
    case types.GET_DOWNSELL_REPORT:
      let downsell_report =
        state.downsell_report_page != action.payload.pageShow
          ? [...state.downsell_report, ...action.payload.data]
          : action.payload.data;
      return {
        ...state,
        error: state.error,
        downsell_report: downsell_report || [],
        downsell_report_page: action.payload.pageShow,
        downsellTotal: action.payload.counttot,
        dataLoaded: downsell_report.length,
        component_success: true
      };

    case types.FETCH_DISPOSITION_REPORT_LINKS:
      return {
        ...state,
        dispositionReportLinks: action.payload.data || [],
        error: state.error,
        component_success: true
      };
    case types.FETCH_DISPOSITION_REPORT:
      //console.log(state.dispositionReport, action.payload);
      let dispositionReport = [];
      let pageShow = 0;
      console.log(
        action.payload.dispositionReport_type +
          "!=" +
          state.dispositionReport_type
      );
      if (
        action.payload.dispositionReport_type != state.dispositionReport_type
      ) {
        dispositionReport = [];
        pageShow = 0;
        dispositionReport = action.payload.data.data;
      } else {
        dispositionReport =
          state.dispositionReport_page != action.payload.pageShow
            ? [...state.dispositionReport, ...action.payload.data.data]
            : action.payload.data.data;
        pageShow = action.payload.pageShow;
      }

      return {
        ...state,
        error: state.error,
        dispositionReport: dispositionReport || [],
        dispositionReport_page: pageShow || 0,
        dataLoaded: dispositionReport.length,
        dispositionTotal: action.payload.counttot,
        dispositionReport_type: action.payload.dispositionReport_type,
        component_success: true
      };

    case types.GET_MOBILE_NUMBER:
      console.log(action.payload);
      // let newBusinessData = state.newBusinessPage != action.payload.pageShow ? [...state.newBusinessData, ...action.payload.data] : action.payload.data;
      let landline = "";
      if (action.payload.data.landline.length > 0) {
        action.payload.data.landline.split(",").forEach(ele => {
          landline += action.payload.data.stdcode + ele + ",";
        });
      }
      return {
        ...state,
        error: state.error,
        // newBusinessData: newBusinessData || [],
        // appnewBusinessPage: action.payload.pageShow,
        clickCallMobileNumber:
          action.payload.data.mobile + "," + landline || [],
        error: state.error,
        component_success: true
      };
    case types.DIGITAL_PAYMENT_STATS:
      console.log(action.payload);
      // let newBusinessData = state.newBusinessPage != action.payload.pageShow ? [...state.newBusinessData, ...action.payload.data] : action.payload.data;
      return {
        ...state,
        error: state.error,
        // newBusinessData: newBusinessData || [],
        // appnewBusinessPage: action.payload.pageShow,
        digital_payment_stats: action.payload.data.result.data || [],
        error: state.error,
        component_success: true
      };
    case types.DIGITAL_PAYMENT_STATS_FILTER:
      console.log(action.payload);
      // let newBusinessData = state.newBusinessPage != action.payload.pageShow ? [...state.newBusinessData, ...action.payload.data] : action.payload.data;
      return {
        ...state,
        error: state.error,
        // newBusinessData: newBusinessData || [],
        // appnewBusinessPage: action.payload.pageShow,
        digital_payment_filter: action.payload || [],
        error: state.error,
        component_success: true
      };
    case types.GET_MY_POINTS:
      console.log(action.payload);
      // let newBusinessData = state.newBusinessPage != action.payload.pageShow ? [...state.newBusinessData, ...action.payload.data] : action.payload.data;
      return {
        ...state,
        error: state.error,
        // newBusinessData: newBusinessData || [],
        // appnewBusinessPage: action.payload.pageShow,
        my_points_details: action.payload.data.data || [],
        error: state.error,
        component_success: true
      };

    case types.MY_RATINGS:
      return {
        ...state,
        error: state.error,
        ratings_Data: action.payload.data || [],
        component_success: true
      };
    case types.HOT_KEYWORD_DATA:
      console.log("payload hot ", action.payload);
      return {
        ...state,
        error: state.error,
        HotKeywordData: action.payload.data || [],
        component_success: true
      };
    case types.GET_MY_RECORDINGS:
      console.log("payload", action.payload);

      return {
        ...state,
        error: state.error,
        recording_Data: action.payload.result.parentid.recording_data || [],
        component_success: true
      };

    case types.SHOW_RECORDING_HISTORY:
      return {
        ...state,
        toggleHistory: action.payload
          ? action.payload.toggle
          : !state.toggleHistory
      };
    case types.ECS_HITS:
      let finance_ecs_hits_data = [];
      let EOR = 0;
      if (action.payload.data.errorStatus == "success") {
        finance_ecs_hits_data =
          state.finance_ecs_hits_page != 0
            ? [...state.finance_ecs_hits, ...action.payload.data.data]
            : action.payload.data.data;
      } else {
        finance_ecs_hits_data =
          state.finance_ecs_hits_page != 0 ? state.finance_ecs_hits : [];
        EOR = 1;
      }

      let total = 0;
      let count = 0;
      if (
        action.payload.data != undefined &&
        action.payload.data.total != undefined
      ) {
        total = action.payload.data.total;
        count = action.payload.data.count;
      }
      return {
        ...state,
        error: state.error,
        finance_ecs_hits: finance_ecs_hits_data || [],
        finance_ecs_hits_total: total,
        finance_ecs_hits_count: count,
        finance_ecs_hits_page: parseInt(state.finance_ecs_hits_page + 1),
        finance_ecs_hits_end: EOR,
        component_success: true
      };
    case types.ECS_HITS_PID:
      let pidtotal = 0;
      let pidcount = 0;
      if (
        action.payload.data != undefined &&
        action.payload.data.total != undefined
      ) {
        pidtotal = action.payload.data.total;
        pidcount = action.payload.data.count;
      }
      return {
        ...state,
        error: state.error,
        finance_ecs_hits: action.payload.data.data || [],
        finance_ecs_hits_total: pidtotal,
        finance_ecs_hits_count: pidcount,
        component_success: true
      };
    case types.FINANCE_SHOW_PAYMENT:
      // let downsell_report = state.downsell_report_page != action.payload.pageShow ? [...state.downsell_report, ...action.payload.data] : action.payload.data;
      return {
        ...state,
        error: state.error,
        finance_show_payment: action.payload.data || [],
        // downsell_report_page: action.payload.pageShow,
        // dataLoaded: downsell_report.length,
        component_success: true
      };
    case types.FINANCE_ECS_SI:
      console.log(action.payload);

      // let downsell_report = state.downsell_report_page != action.payload.pageShow ? [...state.downsell_report, ...action.payload.data] : action.payload.data;
      return {
        ...state,
        error: state.error,
        finance_ecs_si: action.payload.data || [],
        // downsell_report_page: action.payload.pageShow,
        // dataLoaded: downsell_report.length,
        component_success: true
      };
    case types.FINANCE_MANDATE_STATUS:
      console.log(action.payload);

      // let downsell_report = state.downsell_report_page != action.payload.pageShow ? [...state.downsell_report, ...action.payload.data] : action.payload.data;
      return {
        ...state,
        error: state.error,
        finance_mandate_status: action.payload.data || [],
        // downsell_report_page: action.payload.pageShow,
        // dataLoaded: downsell_report.length,
        component_success: true
      };
    case types.FINANCE_SALES_REPORT:
      let finance_sales_report_data = [];
      let end_of_report = 0;
      if (action.payload.data.errorStatus == "Data found") {
        finance_sales_report_data =
          state.finance_sales_report_page != 0
            ? {
                ...state.finance_sales_report,
                ...action.payload.data.data[0].data
              }
            : action.payload.data.data[0].data;
      } else {
        finance_sales_report_data =
          state.finance_sales_report_page != 0
            ? state.finance_sales_report
            : [];
        end_of_report = 1;
      }
      return {
        ...state,
        error: state.error,
        finance_sales_report: finance_sales_report_data || [],
        finance_sales_report_page: parseInt(
          state.finance_sales_report_page + 1
        ),
        finance_sales_report_end: end_of_report,
        finance_sales_count:
          action.payload.data.errorStatus == "Data found"
            ? action.payload.data.data[0].totalInstrumentAmount
            : 0,
        component_success: true
      };
    case types.FINANCE_ECSSALES_REPORT:
      console.log(action);

      let sales_count = action.payload.data
        ? parseInt(
            action.payload.data.data.totalBillEcsAmount +
              action.payload.data.data.totalBillSiAmount
          )
        : 0;
      return {
        ...state,
        error: state.error,
        finance_ecs_sales_report: action.payload.data || [],
        finance_ecs_sales_count: sales_count,
        // downsell_report_page: action.payload.pageShow,
        // dataLoaded: downsell_report.length,
        component_success: true
      };
    case types.GET_BOUNCE_REPORT:
      console.log(action);

      // let downsell_report = state.downsell_report_page != action.payload.pageShow ? [...state.downsell_report, ...action.payload.data] : action.payload.data;
      return {
        ...state,
        error: state.error,
        finance_bounce_report: action.payload.data || [],
        finance_bounce_report_count: action.payload.Totalcnt || 0,
        finance_bounce_total_budget: action.payload.Total_amount || 0,
        // downsell_report_page: action.payload.pageShow,
        // dataLoaded: downsell_report.length,
        component_success: true
      };
    case types.GET_FEEDBACK_REPORT:
      var displayData = {};
      if (
        state.feedback_report != undefined &&
        state.feedback_report.result != undefined &&
        state.feedbackReportPage != action.payload.pageShow
      ) {
        displayData = state.feedback_report.result["countwise"];
        var lengthD = Object.keys(displayData).length;
        for (let idx in action.payload.result["countwise"]) {
          displayData[eval(lengthD) + eval(idx)] =
            action.payload["result"]["countwise"][idx];
        }
        action.payload.result["countwise"] = displayData;
      }
      let feedback_report =
        state.feedbackReportPage != action.payload.pageShow
          ? { ...state.feedback_report, ...action.payload }
          : action.payload;
      return {
        ...state,
        error: state.error,
        feedback_report: feedback_report || [],
        feedback_count: action.payload.result["Total Count"] || 0,
        feedback_unique_count: action.payload.result["Total Unique Count"] || 0,
        component_success: true
      };
    case types.SEND_FEEDBACK_REPORT:
      return {
        ...state,
        error: state.error,
        send_feedback_report: action.payload || [],
        // downsell_report_page: action.payload.pageShow,
        // dataLoaded: downsell_report.length,
        component_success: true
      };
    case types.FINANCE_GENERATE_INVOICE:
      return {
        ...state,
        error: state.error,
        finance_invoice_details: action.payload.result || [],
        component_success: true
      };
    case types.GENERATE_INVOICE_AUTOSUGGEST:
      console.log(action.payload);

      return {
        ...state,
        error: state.error,
        generate_invoice_autosuggest: action.payload.result
          ? action.payload.result.data
          : [],
        component_success: true
      };
    case types.FINANCE_FETCH_HTML_DATA:
      console.log(action.payload);

      return {
        ...state,
        error: state.error,
        finance_html_data: action.payload.result || [],
        component_success: true
      };
    case types.GET_APPOINTMENTS_INFO:
      console.log(action.payload);

      return {
        ...state,
        error: state.error,
        fetchAppointment: 1,
        pendingAppointments: action.payload.data || [],
        component_success: true
      };
    case types.UPDATE_DISPOSITION:
      console.log(action.payload);
      const pendingAppointments = state.pendingAppointments.slice(0, 1);
      return {
        ...state,
        error: state.error,
        pendingAppointments: pendingAppointments,
        component_success: true
      };
    case types.FETCH_PAYMENT_SUMMARY:
      return {
        ...state,
        error: state.error,
        fetchpaymentsummary: action.payload,
        component_success: true
      };
    case types.CLOSE_PAYMENT:
      return {
        ...state,
        error: state.error,
        fetchpaymentsummary: [],
        component_success: true
      };
    case types.MUST_READ_INSTRUCTIONS:
      return {
        ...state,
        error: state.error,
        mustReadOpen: !state.mustReadOpen,
        component_success: true
      };
    case types.FETCH_11MAINS:
      // console.log('action', action.payload)
      return {
        ...state,
        error: state.error,
        fetch11MainsCitiesData: action.payload.data,
        component_success: true
      };
    case types.FETCH_REMOTE_CITIES:
      // console.log('action', action.payload)
      return {
        ...state,
        error: state.error,
        fetchRemoteCitiesData: action.payload.data,
        component_success: true
      };
    case types.FETCH_CAMPAIGN_LIST:
      // console.log('action', action.payload)
      return {
        ...state,
        error: state.error,
        fetchCampaignListData: action.payload.data,
        component_success: true
      };
    case types.FETCH_PLAN_AND_BUDGET:
      // console.log('action', action.payload)
      return {
        ...state,
        error: state.error,
        fetPlanAndBudgetData: action.payload.data,
        component_success: true
      };
    case types.FETCH_CAMPAIGN_PRICE:
      // console.log('action', action.payload)
      return {
        ...state,
        error: state.error,
        campaignPriceData: action.payload.data,
        component_success: true
      };
    case types.FETCH_TIER_CITIES:
      // console.log('action-------', action.payload)
      return {
        ...state,
        error: state.error,
        fetchTierCitiesData: action.payload.data,
        component_success: true
      };
    case types.FETCH_REMOTE_FILTER:
      // console.log('action-------', action.payload)
      return {
        ...state,
        error: state.error,
        fetchRemoteForFilter: action.payload.data,
        component_success: true
      };
    case types.SELECT_CITY_ARR:
      // console.log('action---selectCityArrData----', action.payload)
      return {
        ...state,
        error: state.error,
        selectCityArrData: action.payload.data,
        component_success: true
      };
    case types.SELECT_CAMP:
      // console.log('action---selectCityArrData----', action.payload)
      return {
        ...state,
        error: state.error,
        selectCampData: action.payload.data,
        component_success: true
      };

    case types.FETCH_TOP5_PLANS:
      console.log("action", action.payload);
      return {
        ...state,
        error: state.error,
        fetchTop5Plans: action.payload.data,
        component_success: true
      };
    case types.UPDATE_TOP5_PLANS:
      console.log("action", action.payload);
      return {
        ...state,
        error: state.error,
        updateTop5Plans: action.payload.data,
        component_success: true
      };

    case types.CAMPAIGN_PRICE_PRODUCT:
      // console.log('action---selectCityArrData----', action.payload)
      return {
        ...state,
        error: state.error,
        campaignPriceDataForProduct: action.payload.data,
        component_success: true
      };
    case types.FETCH_TEMP_BUDGET_WINDOW:
      //console.log('action---tempbudget', action.payload)
      return {
        ...state,
        error: state.error,
        tempBudgetWindow: action.payload.data,
        component_success: true
      };
    // ecs allowed

    case types.FETCH_ECS_ALLOWED:
      //console.log('action---tempbudget', action.payload)
      return {
        ...state,
        error: state.error,
        ecsAllowedData: action.payload.data,
        component_success: true
      };
    //update ecs allowed

    case types.UPDATE_ECS_ALLOWED:
      //console.log('action---tempbudget', action.payload)
      return {
        ...state,
        error: state.error,
        ecsRes: action.payload.data,
        component_success: true
      };

    // fetc ecs premium

    case types.FETCH_ECS_PREMIUM_PACKAGE:
      return {
        ...state,
        error: state.error,
        ecsPremiumData: action.payload.data,
        component_success: true
      };
    // update ecs premium

    case types.UPDATE_ECS_PREMIUM_PACKAGE:
      return {
        ...state,
        error: state.error,
        ecsPremiumUpdateRes: action.payload.data,
        component_success: true
      };
    // fetch dp

    case types.FETCH_DP_COUNT:
      console.log("data", action.payload.data);
      return {
        ...state,
        error: state.error,
        dpData: action.payload.data,
        component_success: true
      };

    // update dp

    case types.UPDATE_DP_COUNT:
      return {
        ...state,
        error: state.error,
        dpUpdateRes: action.payload.data,
        component_success: true
      };
  }
  return state;
}
export default userReducer;
