import * as types from "./../actions/actionTypes";

export default class ActionUtility {
  static createAction(
    type,
    payload = undefined,
    error = false,
    message = null
  ) {
    return { type, payload, error, message };
  }

  static async thunkDispatch(dispatch, actionType, apiName, ...args) {
    try {
      const result = await apiName(...args);

      var component_error =
        typeof result.component_error != "undefined" &&
        result.component_error != "" &&
        result.component_error != null
          ? true
          : false;
      var component_success =
        typeof result.component_success != "undefined" &&
        result.component_success != "" &&
        result.component_success != null
          ? true
          : false;

      if (component_error) {
        dispatch(
          ActionUtility.createAction(types.SET_COMPONENT_ERROR, {
            store_component: `${actionType}_ERROR`,
            error: component_error
          })
        );
      } else if (component_success) {
        dispatch(
          ActionUtility.createAction(types.SET_COMPONENT_SUCCESS, {
            store_component: `${actionType}_SUCCESS`,
            error: component_error
          })
        );
      } else {
        dispatch(ActionUtility.createAction(actionType, result));
      }
      return result;
    } catch (error) {
      dispatch(ActionUtility.createAction(types.SET_ERROR, { error: error }));
      //throw error;
    }
  }

  static async thunkDispatchWithUrl(
    dispatch,
    actionType,
    apiName,
    apiUrl,
    ...args
  ) {
    try {
      console.log("utility", apiName);
      const result = await apiName(apiUrl, ...args);

      var component_error =
        typeof result.component_error != "undefined" &&
        result.component_error != "" &&
        result.component_error != null
          ? true
          : false;
      var component_success =
        typeof result.component_success != "undefined" &&
        result.component_success != "" &&
        result.component_success != null
          ? true
          : false;

      if (component_error) {
        dispatch(
          ActionUtility.createAction(types.SET_COMPONENT_ERROR, {
            store_component: `${actionType}_ERROR`,
            error: component_error
          })
        );
      } else if (component_success) {
        dispatch(
          ActionUtility.createAction(types.SET_COMPONENT_SUCCESS, {
            store_component: `${actionType}_SUCCESS`,
            error: component_error
          })
        );
      } else {
        dispatch(ActionUtility.createAction(actionType, result));
      }
      return result;
    } catch (error) {
      console.log(error);
      dispatch(ActionUtility.createAction(types.SET_ERROR, { error: error }));
      //throw error;
    }
  }

  static async normalDispatch(dispatch = undefined, actionType, params) {
    try {
      dispatch(ActionUtility.createAction(actionType, params));
    } catch (error) {
      dispatch(ActionUtility.createAction(types.SET_ERROR, { error: error }));
      //throw error;
    }
  }
  static async normalApiCall(apiName, ...args) {
    try {
      const result = await apiName(...args);
      const isError =
        result.errorCode != undefined && result.errorCode == 1 ? 1 : 0;
      const message =
        result.errorMsg != undefined && result.errorMsg != ""
          ? result.errorMsg
          : "";
      return { data: result };
    } catch (error) {
      console.log(error);
      //throw error;
    }
  }
}
