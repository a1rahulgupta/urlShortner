import * as types from "./../actions/actionTypes";

export function fetchUser(data) {
  return {
    type: types.SET_USER, // Action Type
    payload: { user: data }, // Optional
    error: false, // Optional
    message: null // Optional
  };
}

export function clearErrorStore() {
  return dispatch => {
    dispatch(clearError());
  };
}

export function clearError() {
  return {
    type: types.CLEAR_ERROR,
    payload: { error: null }
  };
}

export function setError(err) {
  return {
    type: types.SET_ERROR,
    payload: { error: err }
  };
}

export function setComponentError(err) {
  return {
    type: types.SET_COMPONENT_ERROR,
    payload: {
      store_component: err.store_component,
      component_error: err.error
    }
  };
}

export function setComponentSuccess(err) {
  return {
    type: types.SET_COMPONENT_SUCCESS,
    payload: {
      store_component: err.store_component,
      component_success: err.error
    }
  };
}

export function clearComponentError() {
  return {
    type: types.CLEAR_COMPONENT_MSG,
    payload: { error: null }
  };
}
