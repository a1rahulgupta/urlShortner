import GenioApi from "./../api/GenioApi";
//import * as dispatchActions from "./dispatchActions";
import ActionUtility from "./ActionUtility";
import * as types from "./../actions/actionTypes";
require("babel-polyfill");

const genioApi = new GenioApi();

export function fetchUser(userid) {
  return async dispatch => {
    //call Normal Action
    //await ActionUtility.normalDispatch(dispatch, types.SET_USER);

    //call Thunk Action
    await ActionUtility.thunkDispatch(
      dispatch,
      types.SET_USER,
      genioApi.getUserDeta,
      userid
    );

    //call Normal API
    //await ActionUtility.normalApiCall(dispatch, types.SET_USER);
  };
}

export function searchBusiness(params) {
  return async dispatch => {
    //call Normal Action
    //await ActionUtility.normalDispatch(dispatch, types.SET_USER);
    if (params["clearFlag"] == true) {
      await ActionUtility.normalDispatch(dispatch, "CLEAR_SUGGESTION");
    } else {
      //call Thunk Action
      await ActionUtility.thunkDispatch(
        dispatch,
        types.SEARCH_SUGGESTION,
        genioApi.searchBusiness,
        params
      );
    }

    //call Normal API
    //await ActionUtility.normalApiCall(dispatch, types.SET_USER);
  };
}
export function LHSToggle() {
  return async dispatch => {
    await ActionUtility.normalDispatch(dispatch, "LHS_TOGGLE");
  };
}
export function filterToggle() {
  return async dispatch => {
    await ActionUtility.normalDispatch(dispatch, "FILTER_TOGGLE");
  };
}
export function setRecentSearch() {
  return async dispatch => {
    await ActionUtility.normalDispatch(dispatch, "RECENT_SEARCH");
  };
}
export function applyFilters(params) {
  return async dispatch => {
    //await ActionUtility.thunkDispatch(dispatch, types.APPLY_FILTERS, GenioApi.applyFilters, params);
    await ActionUtility.normalDispatch(dispatch, types.APPLY_FILTERS, params);
  };
}
export function applySalesFilters(params) {
  return async dispatch => {
    //await ActionUtility.thunkDispatch(dispatch, types.APPLY_FILTERS, GenioApi.applyFilters, params);
    await ActionUtility.normalDispatch(
      dispatch,
      types.APPLY_SALES_FILTERS,
      params
    );
  };
}
export function applySalesEcsFilters(params) {
  return async dispatch => {
    //await ActionUtility.thunkDispatch(dispatch, types.APPLY_FILTERS, GenioApi.applyFilters, params);
    await ActionUtility.normalDispatch(
      dispatch,
      types.APPLY_SALES_ECS_FILTERS,
      params
    );
  };
}
export function applyEcsFilters(params) {
  return async dispatch => {
    //await ActionUtility.thunkDispatch(dispatch, types.APPLY_FILTERS, GenioApi.applyFilters, params);
    await ActionUtility.normalDispatch(
      dispatch,
      types.APPLY_ECS_FILTERS,
      params
    );
  };
}
export function applyDigiPaymentFilter(params) {
  return async dispatch => {
    //await ActionUtility.thunkDispatch(dispatch, types.APPLY_FILTERS, GenioApi.applyFilters, params);
    await ActionUtility.normalDispatch(
      dispatch,
      types.DIGITAL_PAYMENT_STATS_FILTER,
      params
    );
  };
}
export function resetError(params) {
  return async dispatch => {
    //await ActionUtility.thunkDispatch(dispatch, types.APPLY_FILTERS, GenioApi.applyFilters, params);
    await ActionUtility.normalDispatch(dispatch, types.RESET_ERROR);
  };
}

export function citySelection(params) {
  return async dispatch => {
    //call Normal Action
    //await ActionUtility.normalDispatch(dispatch, types.SET_USER);
    if (params["clearFlag"] == true) {
      await ActionUtility.normalDispatch(dispatch, "CLEAR_CITIES");
    } else {
      //call Thunk Action
      await ActionUtility.thunkDispatch(
        dispatch,
        types.FETCH_CITIES,
        genioApi.selectCity,
        params
      );
    }

    //call Normal API
    //await ActionUtility.normalApiCall(dispatch, types.SET_USER);
  };
}

export function setRecentSearches(params) {
  //alert(params,"")
  return async dispatch => {
    //call Normal Action
    //await ActionUtility.normalDispatch(dispatch, types.SET_USER);
    // if (params["clearFlag"] == true) {
    // 	await ActionUtility.normalDispatch(dispatch, "CLEAR");
    // } else {
    //call Thunk Action
    // console.log("params ",params,types)
    await ActionUtility.normalDispatch(
      dispatch,
      types.SET_RECENT_CITIES,
      params
    );
    // }

    //call Normal API
    //await ActionUtility.normalApiCall(dispatch, types.SET_USER);
  };
}
export function setDataCity(params) {
  return async dispatch => {
    //call Normal Action
    await ActionUtility.normalDispatch(dispatch, types.SET_DATACITY, params);
  };
}

export function getAppointments(params) {
  return async dispatch => {
    //call Normal Action
    //await ActionUtility.normalDispatch(dispatch, types.SET_USER);

    //call Thunk Action
    await ActionUtility.thunkDispatch(
      dispatch,
      types.GET_APPOINTMENTS,
      genioApi.getAppointments,
      params
    );
    //call Normal API
    //await ActionUtility.normalApiCall(dispatch, types.SET_USER);
  };
}
export function getTodaysAppointments(params) {
  return async dispatch => {
    //call Normal Action
    //await ActionUtility.normalDispatch(dispatch, types.SET_USER);

    //call Thunk Action
    await ActionUtility.thunkDispatch(
      dispatch,
      types.GET_TODAYS_APPOINTMENTS,
      genioApi.getTodaysAppointments,
      params
    );
    //call Normal API
    //await ActionUtility.normalApiCall(dispatch, types.SET_USER);
  };
}
export function getLastDisposition(params) {
  return async dispatch => {
    //call Normal Action
    //await ActionUtility.normalDispatch(dispatch, types.SET_USER);

    //call Thunk Action
    await ActionUtility.thunkDispatch(
      dispatch,
      types.GET_LAST_DISPOSITION,
      genioApi.getLastDisposition,
      params
    );
    //call Normal API
    //await ActionUtility.normalApiCall(dispatch, types.SET_USER);
  };
}

export function getNewBusiness(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatch(
      dispatch,
      types.GET_NEW_BUSINESS,
      genioApi.getNewBusiness,
      params
    );
    //call Normal API
    //await ActionUtility.normalApiCall(dispatch, types.SET_USER);
  };
}
export function getAssignmentData(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatch(
      dispatch,
      types.GET_ASSIGNMENTDATA,
      genioApi.getAssignmentData,
      params
    );
    //call Normal API
    //await ActionUtility.normalApiCall(dispatch, types.SET_USER);
  };
}
export function fetchGenioGraph(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatch(
      dispatch,
      types.FETCH_GENIO_GRAPH,
      genioApi.fetchGenioGraph,
      params
    );
    //call Normal API
    //await ActionUtility.normalApiCall(dispatch, types.SET_USER);
  };
}

export function getDealsPending(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatch(
      dispatch,
      types.GET_DEALS_PENDING,
      genioApi.getDealsPending,
      params
    );
    //call Normal API
    //await ActionUtility.normalApiCall(dispatch, types.SET_USER);
  };
}

export function getDealsClosed(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatch(
      dispatch,
      types.GET_DEALS_CLOSED,
      genioApi.getDealsClosed,
      params
    );
    //call Normal API
    //await ActionUtility.normalApiCall(dispatch, types.SET_USER);
  };
}

export function getFAQDetails(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatch(
      dispatch,
      types.GET_FAQ_DETAILS,
      genioApi.getFAQDetails,
      params
    );
    //call Normal API
    //await ActionUtility.normalApiCall(dispatch, types.SET_USER);
  };
}
export function fetchMenuLinks(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatch(
      dispatch,
      types.FETCH_MENU_LINKS,
      genioApi.fetchMenuLinks,
      params
    );
    //call Normal API
    //await ActionUtility.normalApiCall(dispatch, types.SET_USER);
  };
}

export const getMenuLinks = async params => {
  let res = await genioApi.fetchMenuLinks(params);
  return res.data;
};

export function getActionData(params, type, apiUrl) {
  //console.log("-apiUrlapiUrl----", apiUrl, type);
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      type,
      genioApi.getActionData,
      apiUrl,
      params
    );
  };
}
export function downsellReport(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.GET_DOWNSELL_REPORT,
      genioApi.downsellReport,
      params
    );
  };
}

export function getMobileNumber(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.GET_MOBILE_NUMBER,
      genioApi.getMobileNumber,
      params
    );
  };
}
export function getDigitalPaymentStats(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.DIGITAL_PAYMENT_STATS,
      genioApi.getDigitalPaymentStats,
      params
    );
  };
}
export function getMyPoints(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.GET_MY_POINTS,
      genioApi.getMyPoints,
      params
    );
  };
}
export function getMyRatings(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.MY_RATINGS,
      genioApi.getMyRatings,
      params
    );
  };
}
export function getHotKeywords(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.HOT_KEYWORD_DATA,
      genioApi.getHotDataKeyword,
      params
    );
  };
}
export function cancelDownsellRequest(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.CANCEL_DOWNSELL,
      genioApi.cancelDownsellRequest,
      params
    );
  };
}

export function getMyRecordings(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.GET_MY_RECORDINGS,
      genioApi.getMyRecordings,
      params
    );
  };
}
export function toggleHistory(params) {
  return async dispatch => {
    await ActionUtility.normalDispatch(
      dispatch,
      types.SHOW_RECORDING_HISTORY,
      params
    );
  };
}

export function toggleComponentLoader(params) {
  return async dispatch => {
    await ActionUtility.normalDispatch(
      dispatch,
      types.SHOW_COMPONENT_LOADER,
      params
    );
  };
}

export function getBounceReport(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.GET_BOUNCE_REPORT,
      genioApi.getBounceReport,
      params
    );
  };
}

export function getShadowData(shadowParams) {
  return genioApi.getShadowData(shadowParams);
}

export function fetchLiveData(liveParams) {
  return genioApi.fetchLiveData(liveParams);
}

export function getWebRedirectToken(params) {
  return genioApi.getWebRedirectToken(params);
}

export function chkContractEditAccess(params) {
  return genioApi.chkContractEditAccess(params);
}

export function bformValidation(params) {
  return genioApi.bformValidation(params);
}

export function checkDuplicateCont(params) {
  return genioApi.checkDuplicateCont(params);
}

export function submitNewBusiness(params) {
  return genioApi.submitNewBusiness(params);
}

export function newBusinessCreation(params) {
  return async dispatch => {
    await ActionUtility.normalDispatch(dispatch, "CREATE_NEW_BUSINESS", params);
  };
}

export function getAreaXhr(params) {
  return genioApi.getAreaXhr(params);
}

export function getPincodeXhr(params) {
  return genioApi.getPincodeXhr(params);
}

export function getPincodesBeta(params) {
  return genioApi.getPincodesBeta(params);
}
export function financeECSHits(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.ECS_HITS,
      genioApi.financeECSHits,
      params
    );
  };
}
export function financeECSWithPid(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.ECS_HITS_PID,
      genioApi.financeECSWithPid,
      params
    );
  };
}
export function financeShowPayment(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FINANCE_SHOW_PAYMENT,
      genioApi.financeShowPayment,
      params
    );
  };
}
export function financeEcsSi(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FINANCE_ECS_SI,
      genioApi.financeEcsSi,
      params
    );
  };
}
export function financeMandateStatus(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FINANCE_MANDATE_STATUS,
      genioApi.financeMandateStatus,
      params
    );
  };
}
export function financeSalesReport(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FINANCE_SALES_REPORT,
      genioApi.financeSalesReport,
      params
    );
  };
}
export function financeECSSalesReport(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FINANCE_ECSSALES_REPORT,
      genioApi.financeECSSalesReport,
      params
    );
  };
}
export function financeGenerateInvoice(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FINANCE_GENERATE_INVOICE,
      genioApi.financeGenerateInvoice,
      params
    );
  };
}
export function generateInvoiceAutosuggest(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.GENERATE_INVOICE_AUTOSUGGEST,
      genioApi.generateInvoiceAutosuggest,
      params
    );
  };
}
export function fetchReceipHTMLtDataBeta(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FINANCE_FETCH_HTML_DATA,
      genioApi.fetchReceipHTMLtDataBeta,
      params
    );
  };
}
export function JDAppdownloadstatus(params) {
  return async dispatch => {
    //call Normal Action
    //await ActionUtility.normalDispatch(dispatch, types.SET_USER);

    //call Thunk Action
    await ActionUtility.thunkDispatch(
      dispatch,
      types.JD_APP_DOWNLOAD_STATUS,
      genioApi.JDAppdownloadstatus,
      params
    );
    //call Normal API
    //await ActionUtility.normalApiCall(dispatch, types.SET_USER);
  };
}
export function JDMartdownloadstatus(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatch(
      dispatch,
      types.JD_MART_DOWNLOAD_STATUS,
      genioApi.JDMartdownloadstatus,
      params
    );
  };
}
export function fetchAppointmentInfo(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatch(
      dispatch,
      types.GET_APPOINTMENTS_INFO,
      genioApi.fetchAppointmentInfo,
      params
    );
  };
}
export function updateDisposition(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatch(
      dispatch,
      types.UPDATE_DISPOSITION,
      genioApi.updateDisposition,
      params
    );
  };
}
export function fetchPaymentSummary(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatch(
      dispatch,
      types.FETCH_PAYMENT_SUMMARY,
      genioApi.fetchPaymentSummary,
      params
    );
  };
}
export function closePaymentPopUp() {
  return async dispatch => {
    await ActionUtility.normalDispatch(dispatch, "CLOSE_PAYMENT");
  };
}
export function closeMustReadInstructions() {
  return async dispatch => {
    await ActionUtility.normalDispatch(dispatch, "MUST_READ_INSTRUCTIONS");
  };
}

export function getFeedbackReport(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.GET_FEEDBACK_REPORT,
      genioApi.getFeedbackReport,
      params
    );
  };
}
export function sendFeedbackReport(params) {
  return async dispatch => {
    console.log("in action....");
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.SEND_FEEDBACK_REPORT,
      genioApi.sendFeedbackReport,
      params
    );
  };
}
export function fetchMainCities(params) {
  return async dispatch => {
    // console.log("in action....");
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FETCH_11MAINS,
      genioApi.fetchMainCities,
      params
    );
  };
}
export function fetchRemoteCities(params) {
  return async dispatch => {
    // console.log("in action....");
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FETCH_REMOTE_CITIES,
      genioApi.fetchRemoteCities,
      params
    );
  };
}
export function fetchCampaignList(params) {
  return async dispatch => {
    // console.log("in action....");
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FETCH_CAMPAIGN_LIST,
      genioApi.fetchCampaignList,
      params
    );
  };
}
export function fetchPlanAndBudgetDetail(params) {
  return async dispatch => {
    // console.log("in action....");
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FETCH_PLAN_AND_BUDGET,
      genioApi.fetchPlanAndBudgetDetail,
      params
    );
  };
}
export function updatePlanAndBudget(params) {
  return async dispatch => {
    // console.log("in action....");
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.UPDATE_PLAN,
      genioApi.updatePlanAndBudget,
      params
    );
  };
}

export function updateDiscount(params) {
  return async dispatch => {
    // console.log("in action....");
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.UPDATE_DISCOUNT,
      genioApi.updateDiscount,
      params
    );
  };
}

export function updateAddOnPrice(params) {
  return async dispatch => {
    // console.log("in action....");
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.UPDATE_ADD_ON,
      genioApi.updateAddOnPrice,
      params
    );
  };
}
export function getCampaignPrice(params) {
  return async dispatch => {
    // console.log("in action....");
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FETCH_CAMPAIGN_PRICE,
      genioApi.getCampaignPrice,
      params
    );
  };
}

export function fetchTierCities(params) {
  return async dispatch => {
    // console.log("in action....");
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FETCH_TIER_CITIES,
      genioApi.fetchTierCities,
      params
    );
  };
}
export function activeInactiveCampaign(params) {
  return async dispatch => {
    // console.log("in action....");
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.ACTIVE_INACTIVE,
      genioApi.activeInactiveCampaign,
      params
    );
  };
}
export function fetchALLCities(params) {
  return async dispatch => {
    // console.log("in action....");
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FETCH_ALL_CITIES,
      genioApi.fetchALLCities,
      params
    );
  };
}

export function fetchRemoteCityForFilters(params) {
  return async dispatch => {
    // console.log("in action....");
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FETCH_REMOTE_FILTER,
      genioApi.fetchRemoteCityForFilters,
      params
    );
  };
}

export function selectCityArr(params) {
  return async dispatch => {
    await ActionUtility.normalDispatch(dispatch, "SELECT_CITY_ARR", params);
  };
}

export function selectCamp(params) {
  return async dispatch => {
    await ActionUtility.normalDispatch(dispatch, "SELECT_CAMP", params);
  };
}

export function updatePlanApi(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FETCH_REMOTE_FILTER,
      genioApi.updatePlanApi,
      params
    );
  };
}

export function getCampaignPriceForProduct(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.CAMPAIGN_PRICE_PRODUCT,
      genioApi.getCampaignPriceForProduct,
      params
    );
  };
}

export function fetchTempBudgetWindow(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FETCH_TEMP_BUDGET_WINDOW,
      genioApi.fetchTempBudgetWindow,
      params
    );
  };
}

export function updateTempBudgetWindow(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.UPDATE_TEMP_BUDGET_WINDOW,
      genioApi.updateTempBudgetWindow,
      params
    );
  };
}

export function fetchTop5Plans(params) {
  return async dispatch => {
    // console.log("in action....");
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FETCH_TOP5_PLANS,
      genioApi.fetchTop5Plans,
      params
    );
  };
}

export function updateTop5Plans(params) {
  return async dispatch => {
    // console.log("in action....");
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.UPDATE_TOP5_PLANS,
      genioApi.updateTop5Plans,
      params
    );
  };
}

// fetch ecs allowed

export function fetchEcsAllowed(params, type, apiUrl) {
  return async dispatch => {
    // console.log("in action....");
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FETCH_ECS_ALLOWED,
      genioApi.fetchEcsAllowed,
      params
    );
  };
}

// update ecs data

export function updateEcsData(params) {
  return async dispatch => {
    // console.log("in action....");
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.UPDATE_ECS_ALLOWED,
      genioApi.updateEcsData,
      params
    );
  };
}

// fetch ecs premium package

export function fetchEcsPremiumPackage(params) {
  return async dispatch => {
    // console.log("in action....");
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FETCH_ECS_PREMIUM_PACKAGE,
      genioApi.fetchEcsPremiumPackage,
      params
    );
  };
}

//  update ecs premium

export function updateEcsPremium(params) {
  return async dispatch => {
    // console.log("in action....");
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.UPDATE_ECS_PREMIUM_PACKAGE,
      genioApi.updateEcsPremium,
      params
    );
  };
}

// fetch dp data

export function fetchDp(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.FETCH_DP_COUNT,
      genioApi.fetchDpCount,
      params
    );
  };
}

//  update dp count

export function updateDpCount(params) {
  return async dispatch => {
    await ActionUtility.thunkDispatchWithUrl(
      dispatch,
      types.UPDATE_DP_COUNT,
      genioApi.updateDpCount,
      params
    );
  };
}

//  download bulk contracty
export async function downloadXlsx(params) {
  return await genioApi.downloadXlsx(params);
}

// get version

export function getVersion(parentid) {
  return genioApi.getVersion(parentid);
}

// bulk update

export function bulkUploadBudget(params) {
  return genioApi.bulkUploadBudget(params);
}

export function getCampTenure(camp_id) {
  return genioApi.getCampTenure(camp_id);
}
