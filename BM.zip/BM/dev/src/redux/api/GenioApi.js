import axios from "axios";
import {
  getLocalStorage,
  setLocalStorage
} from "./../../utilities/localStorage";

require("babel-polyfill");
//var CryptoJS = require("crypto-js");
//var API_PATH = "http://172.29.86.26:8789/jdboxNode";
//var API_PATH = "http://172.29.86.26:7201/jdboxNode";
const API_PATH = "/jdboxNode";
//var API_PATH = "http://192.168.8.121:8082";
//var API_PATH = "http://192.168.20.17:8082/jdboxNode";

export default class GenioApi {
  constructor() {
    let token = getLocalStorage("token") || "";
    if (token != "") {
      console.log(token);
      // axios.defaults.headers.common = {
      // 	Authorization: `Bearer ${token}`,
      // };
    }
  }

  static getAccessToken = async params => {
    try {
      //let res = await axios.post(API_PATH + "/geniosales/auth", params).then((response) => {
      //	let resp = response.data;
      // axios.defaults.headers.common = {
      // 	Authorization: `Bearer ${resp.data.token}`,
      // };
      //return resp.data.token;
      return 1;
      //});
      //return res;
    } catch (e) {
      return { error: e };
    }
  };

  resetAccessToken = async token => {
    try {
      axios.defaults.headers.common = {
        Authorization: `Bearer ${token}`
      };
      setLocalStorage("token", res);
      return token;
    } catch (e) {
      return { error: e };
    }
  };

  getUserDeta = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/geniosales/getUserDataBeta",
        params
      );
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return res.data;
      }
    } catch (e) {
      return { error: e };
    }
  };
  searchBusiness = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/geniosales/getActionDataBeta",
        params
      );
      console.log(res);
      res.errorCode = 0;
      res.errorMsg = "";
      res.successMsg = "success";
      res.status = "200";
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return res.data;
      }
    } catch (e) {
      return { error: e };
    }
  };
  selectCity = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/geniosales/getCitiesBeta",
        params
      );
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return res.data;
      }
    } catch (e) {
      return { error: e };
    }
  };

  getTodaysAppointments = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/geniosales/getActionDataBeta",
        params
      );
      // console.log("------getAppointments--res-----", res, params);
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return {
          data: res.data.data,
          pageShow: params.pageShow,
          counttot: res.data.counttot || "0"
        };
      }
    } catch (e) {
      return { error: e };
    }
  };

  getAppointments = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/geniosales/getActionDataBeta",
        params
      );
      // console.log("------getAppointments--res-----", res, params);
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return {
          data: res.data.data,
          pageShow: params.pageShow,
          counttot: res.data.counttot || "0"
        };
      }
    } catch (e) {
      return { error: e };
    }
  };

  getLastDisposition = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/geniosales/getLastDispositionBeta",
        params
      );
      // console.log("----getLastDisposition----res-----", res, params);
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return res.data;
      }
    } catch (e) {
      return { error: e };
    }
  };

  getNewBusiness = async params => {
    try {
      // let res = await axios.post(API_PATH + "/geniosales/getLastDispositionBeta", params);
      let res = await axios.post(
        API_PATH + "/geniosales/getActionDataBeta",
        params
      );
      // console.log("----getNewBusiness----res-----", res, params);
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return {
          data: res.data.data,
          pageShow: params.pageShow,
          counttot: res.data.counttot || "0"
        };
      }
    } catch (e) {
      return { error: e };
    }
  };

  getAssignmentData = async params => {
    try {
      var res = "";

      if (params.action != undefined && params.action == "newBusiness") {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (
        params.action != undefined &&
        params.action == "getDealClosed"
      ) {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (params.action != undefined && params.action == "cicData") {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (params.action != undefined && params.action == "groceryData") {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (
        params.action != undefined &&
        params.action == "recieveRecentPayments"
      ) {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (
        params.action != undefined &&
        params.action == "recieveRecentPaymentsECS"
      ) {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (
        params.action != undefined &&
        params.action == "recieveDealPending"
      ) {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (
        params.action != undefined &&
        params.action == "whatsappData"
      ) {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (
        params.action != undefined &&
        params.action == "catalogueData"
      ) {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (params.action != undefined && params.action == "CourierData") {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (
        params.action != undefined &&
        params.action == "getRejectedDet"
      ) {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (
        params.action != undefined &&
        params.action == "AllocContracts"
      ) {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (params.action != undefined && params.action == "ReportData") {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (
        params.action != undefined &&
        params.action == "ecsbouncedatanew"
      ) {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (
        params.action != undefined &&
        params.action == "hotcategories"
      ) {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (
        params.action != undefined &&
        params.action == "popularb2bdata"
      ) {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (
        params.action != undefined &&
        params.action == "digicatemailcampaign"
      ) {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (
        params.action != undefined &&
        params.action == "superHotData"
      ) {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (params.action != undefined && params.action == "ABadd") {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (
        params.action != undefined &&
        params.action == "leadComplaints"
      ) {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (
        params.action != undefined &&
        params.action == "prospectdata"
      ) {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (
        params.action != undefined &&
        params.action == "jdAppDownloaddata"
      ) {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else if (
        params.action != undefined &&
        params.action == "assignmentWithFilter"
      ) {
        res = await axios.post(
          API_PATH + "/geniosales/getActionDataBeta",
          params
        );
      } else {
        res = await axios.post(API_PATH + "/wrapper/getActionData", params);
      }

      // let res = await axios.post(API_PATH + "/geniosales/getLastDispositionBeta", params);
      //let res = await axios.post(API_PATH + "/geniosales/getActionDataBeta", params);
      // console.log("----getAssignmentData----res-----", res, params);
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: errorStatus };
      } else {
        return {
          data: res.data,
          action: params.action,
          pageShow: params.pageShow
        };
      }
    } catch (e) {
      return { error: e };
    }
  };

  fetchGenioGraph = async params => {
    try {
      // let res = await axios.post(API_PATH + "/geniosales/getLastDispositionBeta", params);
      let res = await axios.post(
        API_PATH + "/geniosales/fetchGenioGraphBeta",
        params
      );
      // console.log("----getAssignmentData----res-----", res, params);
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return res.data;
      }
    } catch (e) {
      return { error: e };
    }
  };

  getDealsPending = async params => {
    try {
      // let res = await axios.post(API_PATH + "/geniosales/getLastDispositionBeta", params);
      let res = await axios.post(
        API_PATH + "/geniosales/getActionDataBeta",
        params
      );
      // console.log("----getDealsPending----res-----", res, params);
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return {
          data: res.data.data,
          pageShow: params.pageNo,
          counttot: res.data.counttot || "0"
        };
      }
    } catch (e) {
      return { error: e };
    }
  };

  getDealsClosed = async params => {
    try {
      // let res = await axios.post(API_PATH + "/geniosales/getLastDispositionBeta", params);
      let res = await axios.post(
        API_PATH + "/geniosales/getActionDataBeta",
        params
      );
      // console.log("----getDealsClosed----res-----", res, params);
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return {
          data: res.data.data,
          pageShow: params.pageShow,
          counttot: res.data.counttot || "0"
        };
      }
    } catch (e) {
      return { error: e };
    }
  };

  applyFilters = async params => {
    try {
      // let res = await axios.post(API_PATH + "/geniosales/getLastDispositionBeta", params);
      let res = await axios.post(
        API_PATH_TWO + "/geniosales/getActionDataNewBeta",
        params
      );
      // console.log('----getNewBusiness----res-----', res, params)
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return res.data;
      }
    } catch (e) {
      return { error: e };
    }
  };
  getFAQDetails = async params => {
    try {
      let res = await axios.post(API_PATH + "/category/getFAQDetails", params);
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return res.data;
      }
    } catch (e) {
      return { error: e };
    }
  };
  fetchMenuLinks = async params => {
    try {
      //var params2 = { data_city:"Mumbai", user_type:"ME", level:"1"};
      // let res = await axios.post(API_PATH + "/geniosales/getLastDispositionBeta", params);
      let res = await axios.post(
        API_PATH + "/geniosales/fetchMenuLinksBeta",
        params
      );
      // console.log('----getNewBusiness----res-----', res, params)
      //let res = menuLinks;
      //console.log(menuLinks);
      let isError = false;
      let errorMsg = "";
      let successMsg = "";
      //res.status = 200;
      //console.log(res);

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return res.data;
      }
    } catch (e) {
      return { error: e };
    }
  };

  getActionData = async (apiUrl, params) => {
    try {
      // let res = await axios.post(API_PATH + "/contract/getRatingsAPI", params);
      let res = await axios.post(API_PATH + apiUrl, params);
      // console.log("----getActionData----apiUrl-----", apiUrl, params);
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        if (
          apiUrl == "/geniosales/getActionDataBeta" &&
          params.action == "ReportData"
        ) {
          return {
            data: res.data,
            pageShow: params.pageShow || 0,
            dispositionReport_type: params.status,
            counttot: res.data.counttot || "0"
          };
        } else return res.data;
        //return { data: res.data, pageShow: params.pageShow || 0 };
        //return { data: res.data.data, pageShow: params.pageShow };
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  downsellReport = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/geniosales/getDownsellReportBeta",
        params
      );
      //let res = await axios.post(API_PATH + apiUrl, params);
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        //return res.data;
        return {
          data: res.data.data,
          pageShow: params.pageShow,
          counttot: res.data.counttot || "0"
        };
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  getMobileNumber = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/generalInfo/getGeneralMobileData",
        params
      );
      //let res = await axios.post(API_PATH + apiUrl, params);
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        //return res.data;
        return {
          data: res.data.data,
          pageShow: params.pageShow
        };
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  getDigitalPaymentStats = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/geniosales/fetchDigitalPaymentStatsBeta",
        params
      );
      //let res = await axios.post(API_PATH + apiUrl, params);
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        //return res.data;
        return { data: res.data, pageShow: params.pageShow };
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  getMyPoints = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/geniosales/getJdaSalaryPayoutDetailsBeta",
        params
      );

      console.log(res.data);

      res.status = 200;
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        //return res.data;
        return { data: res.data, pageShow: params.pageShow };
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };

  getMyRatings = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/contract/getFeedbackRatings",
        params
      );
      //let res = await axios.post(API_PATH + apiUrl, params);
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";
      isError = false;
      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return res.data;
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  getHotDataKeyword = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/category/getHotKeywordsLHS",
        params
      );
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return res.data;
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };

  getBounceReport = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/geniosales/fetchBounceReportBeta",
        params
      );
      //let res = await axios.post(API_PATH + apiUrl, params);
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        console.log("inside api call", res.data);

        return res.data;
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  getFeedbackReport = async params => {
    try {
      console.log("===params===genioapi===", params);
      let res = await axios.post(
        API_PATH + "/geniosales/fetchFeedbackReportBeta",
        params
      );

      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        console.log("inside api call", res.data);

        return res.data;
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  sendFeedbackReport = async params => {
    try {
      console.log("===params===123genioapi===", params);
      let res = await axios.post(
        API_PATH + "/geniosales/sendFeedbackReportBeta",
        params
      );

      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        console.log("inside send", res.data);

        return res.data;
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  cancelDownsellRequest = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/geniosales/updateBudgetServiceBeta",
        params
      );
      //let res = await axios.post(API_PATH + apiUrl, params);
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return res.data;
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };

  getMyRecordings = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/geniosales/getAllRecordingsBeta",
        params
      );
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return res.data;
        console.log("in api call", res.data);
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };

  getShadowData = async shadowParams => {
    try {
      let response = await axios.post(
        "/jdboxNode/contract/getShadowTabData",
        shadowParams
      );
      return response.data;
    } catch (err) {
      console.log(err);
    }
  };

  fetchLiveData = async liveParams => {
    try {
      let response = await axios.post(
        "/jdboxNode/geniosales/fetchLiveDataBeta",
        liveParams
      );
      return response.data;
    } catch (err) {
      console.log(err);
    }
  };

  getWebRedirectToken = async params => {
    try {
      let response = await axios.post(
        "/jdboxNode/geniosales/getWebRedirectTokenBeta",
        params
      );
      if (response.data.errorCode == 0) {
        window.location.href = response.data.link;
      }
    } catch (err) {
      console.log(err);
    }
  };

  chkContractEditAccess = async params => {
    try {
      let response = await axios.post(
        "/jdboxNode/geniosales/chkContractEditAccessBeta",
        params
      );
      return response.data;
    } catch (err) {
      console.log(err);
    }
  };
  financeECSHits = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/geniosales/fetchEcsHitsReportBeta",
        params
      );

      //let res = await axios.post(API_PATH + apiUrl, params);
      //	res.status = 200;
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        //return res.data;
        return { data: res.data, pageShow: params.pageShow };
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  financeECSWithPid = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/ecsreport/fetchEcsHitsPidReport",
        params
      );

      //let res = await axios.post(API_PATH + apiUrl, params);
      //	res.status = 200;
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        //return res.data;
        return { data: res.data, pageShow: params.pageShow };
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  financeShowPayment = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/geniosales/fetchShowPaymentData",
        params
      );
      //let res = await axios.post(API_PATH + apiUrl, params);
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        //return res.data;
        return { data: res.data, pageShow: params.pageShow };
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  financeEcsSi = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/geniosales/fetchEcsSiReportBeta",
        params
      );
      //let res = await axios.post(API_PATH + apiUrl, params);
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        //return res.data;
        return { data: res.data, pageShow: params.pageShow };
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  financeMandateStatus = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/geniosales/fetchMandateStatusBeta",
        params
      );
      res.status = 200;
      res.data.errorCode = 0;
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        //return res.data;
        return { data: res, pageShow: params.pageShow };
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  financeSalesReport = async params => {
    try {
      let res = await axios.post(
        "/jdboxNode/geniosales/salesMonthInsReportBeta",
        params
      );
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        //return res.data;
        return { data: res.data, pageShow: params.pageShow };
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  financeECSSalesReport = async params => {
    try {
      let res = await axios.post(
        "/jdboxNode/geniosales/salesMonthEcsReportBeta",
        params
      );

      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        //return res.data;
        return { data: res.data, pageShow: params.pageShow };
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  financeGenerateInvoice = async params => {
    try {
      let res = await axios.post(
        "/jdboxNode/geniosales/generateInvoiceBeta",
        params
      );
      let isError =
        res.errorCode != undefined && res.errorCode != "" && res.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.errorStatus != undefined &&
        res.errorStatus != "" &&
        res.errorStatus != null
          ? res.errorStatus
          : "";
      let successMsg =
        res.successMsg != undefined &&
        res.successMsg != "" &&
        res.successMsg != null
          ? res.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return res.data;
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  bformValidation = async params => {
    try {
      let response = await axios.post(
        "/jdboxNode/geniosales/bformValidationBeta",
        params
      );
      return response.data;
    } catch (err) {
      console.log(err);
    }
  };

  checkDuplicateCont = async params => {
    try {
      let response = await axios.post(
        "/jdboxNode/geniosales/checkDuplicateContBeta",
        params
      );
      return response.data;
    } catch (err) {
      console.log(err);
    }
  };

  submitNewBusiness = async params => {
    try {
      let response = await axios.post(
        "/jdboxNode/geniosales/submitNewBusinessBeta",
        params
      );
      return response.data;
    } catch (err) {
      console.log(err);
    }
  };

  getAreaXhr = async params => {
    try {
      let response = await axios.post(
        "/jdboxNode/geniosales/getAreaXhrBeta",
        params
      );
      return response.data;
    } catch (err) {
      console.log(err);
    }
  };

  getPincodeXhr = async params => {
    try {
      let response = await axios.post(
        "/jdboxNode/geniosales/getPincodeXhrBeta",
        params
      );
      return response.data;
    } catch (err) {
      console.log(err);
    }
  };

  getPincodesBeta = async params => {
    try {
      let response = await axios.post(
        "/jdboxNode/geniosales/getPincodesBeta",
        params
      );
      return response.data;
    } catch (err) {
      console.log(err);
    }
  };
  generateInvoiceAutosuggest = async params => {
    try {
      let response = await axios.post(
        "/jdboxNode/geniosales/getCompanyAutosuggestBeta",
        params
      );
      return response.data;
    } catch (err) {
      console.log(err);
    }
  };
  fetchReceipHTMLtDataBeta = async params => {
    try {
      let response = await axios.post(
        "/jdboxNode/geniosales/fetchReceipHTMLtDataBeta",
        params
      );
      return response.data;
    } catch (err) {
      console.log(err);
    }
  };

  JDAppdownloadstatus = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/contract/getJdappDownloadStatus",
        params
      );
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return res.data;
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };

  JDMartdownloadstatus = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/contract/getJdMartDownloadStatus",
        params
      );
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return res.data;
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };

  fetchAppointmentInfo = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/geniosales/fetchAppointmentInfoBeta",
        params
      );
      return res.data;
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return res.data;
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  updateDisposition = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/geniosales/updateDispositionBeta",
        params
      );
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return res.data;
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  fetchPaymentSummary = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/geniosales/fetchPaymentSummaryBeta",
        params
      );
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";

      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return res.data;
      }
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };

  fetchMainCities = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/fetchMainCities",
        params
      );
      // console.log("res---",res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  fetchRemoteCities = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/fetchRemoteCities",
        params
      );
      // console.log("res---",res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  // fetchCampaignList = async (params) => {
  // let Params=
  // 			{
  // 			"data_city": "mumbai",
  // 			"empcode": "10074565",
  // 			"jdverified": 0,
  // 			"action": "minbudget",
  // 			"module": "ME",
  // 			"parentid":"P"

  // 			};
  // 	try {
  // 		let res = await axios.post(API_PATH +"/campaignBudget/getMinimumCampaignBudget",Params)

  // 		console.log("res--budget-",res)
  // 		return res;

  // 	} catch (e) {
  // 		//console.log(e);
  // 		return { error: e };
  // 	}
  // };
  fetchPlanAndBudgetDetail = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/fetchPlanAndBudgetDetails",
        params
      );

      // console.log("res-plan-budget", res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  updatePlanAndBudget = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/updatePlanAndBudget",
        params
      );

      // console.log("update---", res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  updateDiscount = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/updateDiscount",
        params
      );

      // console.log("update---", res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  updateAddOnPrice = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/updateAddOnPrice",
        params
      );

      // console.log("update---", res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  getCampaignPrice = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/getCampaignPrice",
        params
      );

      // console.log("update---", res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  fetchTierCities = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/fetchTierCities",
        params
      );

      // console.log("update---", res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  fetchCampaignList = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/getCampaignList",
        params
      );

      // console.log("res--budget-", res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  activeInactiveCampaign = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/activeInactiveCampaign",
        params
      );

      // console.log("res--budget-", res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  fetchALLCities = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/fetchALLCities",
        params
      );

      // console.log("res--budget-", res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  fetchRemoteCityForFilters = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/fetchRemoteCityForFilters",
        params
      );

      // console.log("res--budget-", res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  updatePlanApi = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/updatePlanApi",
        params
      );

      // console.log("res--budget-", res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  getCampaignPriceForProduct = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/getCampaignPriceForProduct",
        params
      );

      // console.log("res--budget-", res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  fetchTempBudgetWindow = async params => {
    try {
      let res = await axios.get(
        API_PATH + "/budgetAdmin/fetchBudgetTimeWindow",
        { params }
      );

      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  updateTempBudgetWindow = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/updateBudgetTimeWindow",
        params
      );

      return res;
    } catch (e) {
      return { error: e };
    }
  };
  fetchTop5Plans = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/getTop5Plans",
        params
      );
      // console.log("res---",res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  updateTop5Plans = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/updateTop5Plans",
        params
      );
      // console.log("res---",res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };
  // ecs allowed data

  fetchEcsAllowed = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/fetchEcsAllowed",
        params
      );
      // console.log("res---",res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };

  // update ecs data

  updateEcsData = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/updateEcsData",
        params
      );
      // console.log("res---",res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };

  // fetch ecs premium package

  fetchEcsPremiumPackage = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/getEcsPremiumPackage",
        params
      );
      // console.log("res---",res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };

  //  update ecs premium
  updateEcsPremium = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/updateEcsPremiumPackage",
        params
      );
      // console.log("res---",res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };

  // DP count data

  fetchDpCount = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/fetchDpCount",
        params
      );
      // console.log("res---",res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };

  // update DP count data

  updateDpCount = async params => {
    try {
      let res = await axios.post(
        API_PATH + "/budgetAdmin/updateDpCount",
        params
      );
      // console.log("res---",res)
      return res;
    } catch (e) {
      //console.log(e);
      return { error: e };
    }
  };

  getVersion = async parentid => {
    try {
      let module = localStorage.getItem("Module");
      let datacity = localStorage.getItem("datacity");
      let reqObj = {
        jwt_ucode: EMPCODE,
        data_city: datacity,
        module: module,
        parentid: parentid,
        empcode: EMPCODE
      };
      let response = await axios.post(
        API_PATH + "/geniosales/getVersion",
        reqObj
      );
      return response.data;
    } catch (err) {
      console.log(err);
    }
  };

  downloadXlsx = async params => {
    try {
      let module = localStorage.getItem("Module");
      let datacity = localStorage.getItem("datacity");
      const req = {
        jwt_ucode: EMPCODE,
        server_city: datacity,
        data_city: datacity,
        data: params,
        module: module
      };
      let res = await axios.post(API_PATH + "/genioapi/downloadXlsx", req, {
        responseType: "arraybuffer"
      });
      let isError =
        res.data.errorCode != undefined &&
        res.data.errorCode != "" &&
        res.data.errorCode == 1
          ? true
          : false;
      let errorStatus =
        res.data.errorStatus != undefined &&
        res.data.errorStatus != "" &&
        res.data.errorStatus != null
          ? res.data.errorStatus
          : "";
      let successMsg =
        res.data.successMsg != undefined &&
        res.data.successMsg != "" &&
        res.data.successMsg != null
          ? res.data.successMsg
          : "";
      if (res.status == "200" && isError && errorStatus != "") {
        return { component_error: errorStatus };
      } else if (res.status == "200" && !isError && successMsg != "") {
        return { component_success: successMsg };
      } else {
        return res.data;
      }
    } catch (err) {
      console.log(err);
    }
  };

  bulkUploadBudget = async params => {
    try {
      let module = localStorage.getItem("Module");
      let datacity = localStorage.getItem("datacity");
      let reqObj = {
        jwt_ucode: EMPCODE,
        data_city: datacity,
        module: module,
        empcode: EMPCODE,
        data: params
      };
      let response = await axios.post(
        API_PATH + "/budgetAdmin/bulkUploadBudget",
        reqObj
      );
      return response.data;
    } catch (err) {
      console.log(err);
    }
  };

  getCampTenure = async campaign_id => {
    try {
      let module = localStorage.getItem("Module");
      let datacity = localStorage.getItem("datacity");
      let reqObj = {
        jwt_ucode: EMPCODE,
        data_city: datacity,
        module: module,
        empcode: EMPCODE,
        campaign_id: campaign_id
      };
      let response = await axios.post(
        API_PATH + "/budgetAdmin/getCampTenure",
        reqObj
      );
      return response.data;
    } catch (err) {
      console.log(err);
    }
  };
}
